import Quickshell
import Quickshell.Wayland
import Quickshell.Hyprland
import QtQuick
import qs
import qs.settings
import qs.widgets
import qs.modules.Services

Variants {
    model: Config.cfg.dock.enabled ? Quickshell.screens : []

    delegate: PanelWindow {
        id: root
        required property ShellScreen modelData

        readonly property real base: Config.cfg.dock.iconSize
        readonly property real maxSize: base * Config.cfg.dock.magnification
        readonly property real spacing: 6
        readonly property real sepWidth: 14
        readonly property real padX: 14
        readonly property real padTop: 9
        readonly property real padBottom: 13
        readonly property real margin: 10
        readonly property real glassH: base + padTop + padBottom
        readonly property real zoneH: margin + glassH + (maxSize - base) + 48

        property real hover: 0
        property real mouseX: 0
        property real mouseY: 0
        property real slide: 0
        readonly property bool hovered: area.containsMouse

        /* right-click menu state */
        property string menuKey: ""
        property real menuX: 0
        property real menuY: 0

        readonly property var apps: {
            /* heuristicLookup() is a plain function, so QML can't tell this
             * binding depends on it. Read the entry list to make it re-run
             * once the desktop entry database has finished loading. */
            void DesktopEntries.applications.values;

            const wins = {};
            const tops = ToplevelManager.toplevels.values;
            for (let i = 0; i < tops.length; i++) {
                const id = tops[i].appId || "";
                if (id === "")
                    continue;
                const e = DesktopEntries.heuristicLookup(id);
                const key = e ? e.id : id.toLowerCase();
                if (!wins[key])
                    wins[key] = [];
                wins[key].push(tops[i]);
            }
            const out = [];
            const seen = {};
            let npinned = 0;

            if (Config.cfg.dock.showLauncher)
                out.push({
                    key: "-launcher",
                    special: "launcher",
                    glyph: "circles-four",
                    name: "Launchpad",
                    icon: "",
                    windows: []
                });

            const pinned = Config.cfg.dock.pinned;
            for (let i = 0; i < pinned.length; i++) {
                const e = DesktopEntries.heuristicLookup(pinned[i]);
                if (!e || seen[e.id])
                    continue;
                seen[e.id] = true;
                npinned++;
                out.push({
                    key: e.id,
                    entry: e,
                    name: e.name,
                    icon: e.icon,
                    windows: wins[e.id] || []
                });
            }
            const extra = Object.keys(wins).filter(k => !seen[k]);
            if (npinned > 0 && extra.length > 0)
                out.push({
                    key: "-sep-apps",
                    sep: true,
                    windows: []
                });
            for (let i = 0; i < extra.length; i++) {
                const e = DesktopEntries.heuristicLookup(extra[i]);
                out.push({
                    key: extra[i],
                    entry: e,
                    name: e ? e.name : extra[i],
                    icon: e ? e.icon : extra[i],
                    windows: wins[extra[i]]
                });
            }

            if (Config.cfg.dock.showTrash) {
                out.push({
                    key: "-sep-trash",
                    sep: true,
                    windows: []
                });
                out.push({
                    key: "-trash",
                    special: "trash",
                    name: "Trash",
                    icon: Trash.full ? "user-trash-full" : "user-trash",
                    windows: []
                });
            }
            return out;
        }

        readonly property var centers: {
            const out = [];
            let x = 0;
            for (let i = 0; i < apps.length; i++) {
                const w = apps[i].sep ? sepWidth : base;
                out.push(x + w / 2);
                x += w + spacing;
            }
            return out;
        }
        readonly property real restWidth: {
            let x = 0;
            for (let i = 0; i < apps.length; i++)
                x += (apps[i].sep ? sepWidth : base) + spacing;
            return Math.max(x - spacing, 0);
        }
        readonly property real left0: width / 2 - restWidth / 2

        readonly property bool crowded: {
            const mon = Hyprland.monitorFor(modelData);
            if (!mon)
                return false;
            const special = mon.lastIpcObject?.specialWorkspace?.id ?? 0;
            const wsId = mon.activeWorkspace?.id ?? -1;
            const half = glass.width / 2 + 12;
            const top = modelData.height - margin - glassH - 6;
            const cx = modelData.width / 2;
            for (const c of Clients.list) {
                if (!c.mapped || c.hidden)
                    continue;
                if (c.workspace.id !== wsId && c.workspace.id !== special)
                    continue;
                const wx = c.at[0] - mon.x;
                const wy = c.at[1] - mon.y;
                if (wx < cx + half && wx + c.size[0] > cx - half && wy + c.size[1] > top)
                    return true;
            }
            return false;
        }
        readonly property bool hidden: Config.cfg.dock.autoHide && crowded && !hovered && !grace.running && !menu.visible

        readonly property var menuApp: {
            for (let i = 0; i < apps.length; i++) {
                if (apps[i].key === menuKey)
                    return apps[i];
            }
            return null;
        }
        readonly property var menuItems: menuApp ? buildMenu(menuApp) : []

        function factor(i) {
            const d = Math.abs(mouseX - (left0 + centers[i])) / (base * 2.4);
            return d >= 1 ? 0 : (1 + Math.cos(Math.PI * d)) / 2;
        }

        function sizeAt(i) {
            return base * (1 + (Config.cfg.dock.magnification - 1) * factor(i) * hover);
        }

        function nearest() {
            let best = -1;
            let dist = Infinity;
            for (let i = 0; i < apps.length; i++) {
                if (apps[i].sep)
                    continue;
                const d = Math.abs(mouseX - (left0 + centers[i]));
                if (d < dist) {
                    dist = d;
                    best = i;
                }
            }
            return best;
        }

        function activate(app, fresh) {
            if (app.special === "launcher") {
                Island.togglePage("launcher", Compositor.focusedScreen);
            } else if (app.special === "trash") {
                Trash.open();
            } else if (app.windows.length > 0 && !fresh) {
                const w = app.windows.find(t => !t.activated) ?? app.windows[0];
                w.activate();
            } else if (app.entry) {
                Apps.launch(app.entry);
            }
        }

        function isPinned(key) {
            const pinned = Config.cfg.dock.pinned;
            for (let i = 0; i < pinned.length; i++) {
                const e = DesktopEntries.heuristicLookup(pinned[i]);
                if (e && e.id === key)
                    return true;
            }
            return false;
        }

        function setPinned(app, on) {
            const pinned = Config.cfg.dock.pinned;
            const next = [];
            for (let i = 0; i < pinned.length; i++) {
                const e = DesktopEntries.heuristicLookup(pinned[i]);
                if (e && e.id === app.key)
                    continue;
                next.push(pinned[i]);
            }
            if (on && app.entry)
                next.push(app.entry.id);
            Config.cfg.dock.pinned = next;
            Config.save();
        }

        /* Sections (windows / desktop actions / dock+open / quit) joined by separators. */
        function buildMenu(app) {
            if (app.special === "trash")
                return [
                    {
                        id: "t-open",
                        label: "Open",
                        act: "trash-open"
                    },
                    {
                        id: "t-empty",
                        label: "Empty Trash",
                        act: "trash-empty",
                        disabled: !Trash.full
                    }
                ];
            if (!app.entry && app.windows.length === 0)
                return [];

            const wins = app.windows;
            const winItems = [];
            for (let i = 0; i < wins.length; i++)
                winItems.push({
                    id: "w" + i,
                    label: wins[i].title || app.name,
                    act: "win",
                    win: wins[i],
                    check: wins[i].activated
                });

            const actItems = [];
            if (app.entry) {
                const acts = app.entry.actions;
                for (let i = 0; i < acts.length; i++)
                    actItems.push({
                        id: "a" + i,
                        label: acts[i].name,
                        act: "action",
                        action: acts[i]
                    });
            }

            const mainItems = [];
            if (app.entry) {
                mainItems.push({
                    id: "pin",
                    label: isPinned(app.key) ? "Remove from Dock" : "Keep in Dock",
                    act: "pin",
                    app: app
                });
                if (wins.length === 0)
                    mainItems.push({
                        id: "open",
                        label: "Open",
                        act: "open",
                        entry: app.entry
                    });
            }

            const quitItems = wins.length > 0 ? [
                {
                    id: "quit",
                    label: "Quit",
                    act: "quit",
                    windows: wins
                }
            ] : [];

            const sections = [winItems, actItems, mainItems, quitItems];
            const out = [];
            let n = 0;
            for (let i = 0; i < sections.length; i++) {
                if (sections[i].length === 0)
                    continue;
                if (out.length > 0)
                    out.push({
                        id: "sep" + n++,
                        sep: true
                    });
                for (let j = 0; j < sections[i].length; j++)
                    out.push(sections[i][j]);
            }
            return out;
        }

        function openMenu(app, x) {
            menu.visible = false;
            menuKey = app.key;
            if (menuItems.length === 0) {
                menuKey = "";
                return;
            }
            menuX = x;
            menuY = height - margin - glassH - 10;
            menu.visible = true;
        }

        function runMenu(item) {
            menu.visible = false;
            switch (item.act) {
            case "win":
                item.win.activate();
                break;
            case "action":
                item.action.execute();
                break;
            case "open":
                Apps.launch(item.entry);
                break;
            case "pin":
                setPinned(item.app, !isPinned(item.app.key));
                break;
            case "quit":
                for (let i = 0; i < item.windows.length; i++)
                    item.windows[i].close();
                break;
            case "trash-open":
                Trash.open();
                break;
            case "trash-empty":
                Trash.empty();
                break;
            }
        }

        onHiddenChanged: {
            slideAnim.stop();
            slideAnim.to = hidden ? glassH + margin + 40 : 0;
            slideAnim.duration = hidden ? 380 : 520;
            slideAnim.easing.bezierCurve = hidden ? Motion.exit : Motion.smooth;
            slideAnim.start();
        }

        onHoveredChanged: {
            if (hovered)
                grace.stop();
            else
                grace.restart();
            hoverAnim.to = hovered ? 1 : 0;
            hoverAnim.duration = hovered ? 200 : 300;
            hoverAnim.restart();
        }

        screen: modelData
        anchors {
            left: true
            right: true
            bottom: true
        }
        implicitHeight: zoneH
        exclusionMode: ExclusionMode.Ignore
        color: "transparent"
        WlrLayershell.namespace: "qs-dock"
        WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
        mask: Region {
            item: hit
        }

        Timer {
            id: grace
            interval: 450
        }

        NumberAnimation {
            id: hoverAnim
            target: root
            property: "hover"
            easing.type: Easing.OutCubic
        }

        NumberAnimation {
            id: slideAnim
            target: root
            property: "slide"
            easing.type: Easing.BezierSpline
        }

        /* click outside the menu closes it */
        HyprlandFocusGrab {
            windows: [menu]
            active: menu.visible
            onCleared: menu.visible = false
        }

        PopupWindow {
            id: menu
            visible: false
            anchor.window: root
            anchor.rect.x: root.menuX
            anchor.rect.y: root.menuY
            anchor.rect.width: 1
            anchor.rect.height: 1
            anchor.edges: Edges.Top
            anchor.gravity: Edges.Top
            implicitWidth: 230
            implicitHeight: col.implicitHeight + 12
            color: "transparent"

            onVisibleChanged: {
                if (!visible)
                    root.menuKey = "";
            }

            Rectangle {
                anchors.fill: parent
                radius: 12
                color: Colors.light ? Qt.rgba(1, 1, 1, 0.92) : Qt.rgba(0.16, 0.16, 0.18, 0.92)
                border.width: 1
                border.color: Colors.light ? Qt.rgba(0, 0, 0, 0.1) : Qt.rgba(1, 1, 1, 0.16)

                Column {
                    id: col
                    x: 6
                    y: 6
                    width: parent.width - 12
                    spacing: 0

                    Repeater {
                        model: ScriptModel {
                            values: root.menuItems
                            objectProp: "id"
                        }

                        delegate: Item {
                            id: mi
                            required property var modelData
                            readonly property bool sep: modelData.sep === true
                            readonly property bool live: !sep && modelData.disabled !== true
                            readonly property bool lit: live && ma.containsMouse

                            width: col.width
                            height: sep ? 9 : 26

                            Rectangle {
                                visible: mi.sep
                                anchors.verticalCenter: parent.verticalCenter
                                x: 8
                                width: parent.width - 16
                                height: 1
                                color: Colors.light ? Qt.rgba(0, 0, 0, 0.12) : Qt.rgba(1, 1, 1, 0.16)
                            }

                            Rectangle {
                                visible: !mi.sep
                                anchors.fill: parent
                                radius: 6
                                color: Colors.accent
                                opacity: mi.lit ? 1 : 0
                            }

                            StyledIcon {
                                visible: !mi.sep && mi.modelData.check === true
                                anchors.verticalCenter: parent.verticalCenter
                                x: 7
                                iconName: "check-fat"
                                width: 11
                                height: 11
                                tint: mi.lit ? "white" : (Colors.light ? Qt.rgba(0, 0, 0, 0.8) : Qt.rgba(1, 1, 1, 0.9))
                            }

                            StyledText {
                                visible: !mi.sep
                                anchors.verticalCenter: parent.verticalCenter
                                x: 24
                                width: parent.width - 34
                                elide: Text.ElideRight
                                text: mi.sep ? "" : mi.modelData.label
                                textSize: 13
                                color: mi.lit ? "white" : (!mi.live ? (Colors.light ? Qt.rgba(0, 0, 0, 0.35) : Qt.rgba(1, 1, 1, 0.35)) : (Colors.light ? Qt.rgba(0, 0, 0, 0.86) : Qt.rgba(1, 1, 1, 0.94)))
                            }

                            MouseArea {
                                id: ma
                                anchors.fill: parent
                                enabled: mi.live
                                hoverEnabled: true
                                onClicked: root.runMenu(mi.modelData)
                            }
                        }
                    }
                }
            }
        }

        Image {
            id: wall
            visible: false
            width: root.modelData.width
            height: root.modelData.height
            asynchronous: true
            fillMode: Image.PreserveAspectCrop
            sourceSize: Qt.size(width, height)
            source: Config.cfg.wallpaper.wallpaper !== "" ? Qt.resolvedUrl(Config.cfg.wallpaper.wallpaper) : ""
        }

        Item {
            id: hit
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.bottom: parent.bottom
            width: glass.width + 48
            height: root.hidden ? 4 : (root.hovered || root.hover > 0.01 ? root.zoneH : root.margin + root.glassH)

            MouseArea {
                id: area
                anchors.fill: parent
                hoverEnabled: true
                acceptedButtons: Qt.NoButton
                onPositionChanged: mouse => {
                    root.mouseX = mouse.x + hit.x;
                    root.mouseY = mouse.y;
                }
            }
        }

        Item {
            id: glass
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.bottom: parent.bottom
            anchors.bottomMargin: root.margin - root.slide
            visible: root.apps.length > 0
            width: row.width + 2 * root.padX
            height: root.glassH

            Rectangle {
                anchors.fill: parent
                radius: 24
                visible: !liquid.visible || liquid.failed
                color: Colors.light ? Qt.rgba(1, 1, 1, 0.75) : Qt.rgba(0.14, 0.14, 0.16, 0.8)
                border.width: 1
                border.color: Colors.light ? Qt.rgba(0, 0, 0, 0.08) : Qt.rgba(1, 1, 1, 0.14)
            }

            LiquidGlass {
                id: liquid
                anchors.fill: parent
                visible: wall.status === Image.Ready
                backdrop: wall
                bx: glass.x
                by: root.modelData.height - root.height + glass.y
                radius: 24
                dark: !Colors.light
                tint: Colors.light ? 0.4 : 0.3
                blur: 8
                thickness: 18
                shadowAmt: 0.6
                rim: 0.6
            }

            Row {
                id: row
                anchors.horizontalCenter: parent.horizontalCenter
                anchors.bottom: parent.bottom
                anchors.bottomMargin: root.padBottom
                spacing: root.spacing

                Repeater {
                    model: ScriptModel {
                        values: root.apps
                        objectProp: "key"
                    }

                    /* No Loader here: a Loader with its own width/height bindings fights the
                     * icon's width binding, and the icon collapses to 0 wide. Separators are
                     * just a DockIcon in "sep" mode. */
                    delegate: DockIcon {
                        id: cell
                        required property var modelData
                        required property int index

                        app: modelData
                        size: app.sep === true ? root.sepWidth : root.sizeAt(index)
                        maxSize: root.maxSize
                        lineHeight: root.base * 0.8
                        lit: !sep && root.hovered && root.nearest() === index && root.mouseY >= hit.height - root.margin - root.padBottom - size - 8

                        MouseArea {
                            enabled: !cell.sep
                            x: (parent.width - cell.size) / 2
                            y: parent.height - cell.size
                            width: cell.size
                            height: cell.size
                            cursorShape: Qt.PointingHandCursor
                            acceptedButtons: Qt.LeftButton | Qt.MiddleButton | Qt.RightButton
                            onPressedChanged: cell.pressed = pressed
                            onClicked: mouse => {
                                if (mouse.button === Qt.RightButton) {
                                    root.openMenu(cell.app, root.left0 + root.centers[cell.index]);
                                    return;
                                }
                                const fresh = mouse.button === Qt.MiddleButton;
                                if (cell.app.entry && (fresh || cell.app.windows.length === 0))
                                    cell.bounce();
                                root.activate(cell.app, fresh);
                            }
                        }
                    }
                }
            }
        }
    }
}
