import Quickshell
import Quickshell.Widgets
import QtQuick
import qs
import qs.widgets

Item {
    id: root
    required property var app
    required property real size
    required property real maxSize
    required property bool lit

    property real appear: 0
    property real hop: 0
    property bool pressed: false
    property bool launching: false
    property real lineHeight: 0
    readonly property bool sep: app.sep === true
    readonly property bool running: !sep && app.windows.length > 0
    readonly property bool isGlyph: (app.glyph ?? "") !== ""

    width: size * appear
    height: maxSize

    Component.onCompleted: appear = 1

    Behavior on appear {
        NumberAnimation {
            duration: 420
            easing.type: Easing.BezierSpline
            easing.bezierCurve: Motion.smooth
        }
    }

    /* macOS keeps bouncing until the app has a window; a second or so if it was already running */
    function bounce() {
        launching = true;
        settleAnim.stop();
        hopAnim.restart();
        launchTimer.interval = running ? 1100 : 10000;
        launchTimer.restart();
    }

    function settle() {
        launchTimer.stop();
        launching = false;
        hopAnim.stop();
        settleAnim.restart();
    }

    onRunningChanged: {
        if (running && launching)
            settle();
    }

    Timer {
        id: launchTimer
        onTriggered: root.settle()
    }

    NumberAnimation {
        id: settleAnim
        target: root
        property: "hop"
        to: 0
        duration: 160
        easing.type: Easing.InQuad
    }

    SequentialAnimation {
        id: hopAnim
        loops: Animation.Infinite
        NumberAnimation {
            target: root
            property: "hop"
            to: root.size * 0.38
            duration: 260
            easing.type: Easing.OutQuad
        }
        NumberAnimation {
            target: root
            property: "hop"
            to: 0
            duration: 260
            easing.type: Easing.InQuad
        }
    }

    Item {
        id: face
        anchors.horizontalCenter: parent.horizontalCenter
        y: root.height - height - root.hop
        width: root.size
        height: root.size
        scale: root.appear
        transformOrigin: Item.Bottom
        opacity: root.pressed ? 0.55 : 1
        visible: !root.sep

        Behavior on opacity {
            NumberAnimation {
                duration: 90
            }
        }

        IconImage {
            anchors.fill: parent
            visible: !root.isGlyph
            implicitSize: 128
            mipmap: true
            source: (root.isGlyph || root.sep) ? "" : Quickshell.iconPath(root.app.icon ?? "", "application-x-executable")
        }

        /* app-less tiles (Launchpad): a squircle with a glyph, in the theme accent */
        Rectangle {
            anchors.fill: parent
            visible: root.isGlyph
            radius: width * 0.225
            border.width: 1
            border.color: Qt.rgba(1, 1, 1, 0.2)
            gradient: Gradient {
                GradientStop {
                    position: 0
                    color: Qt.lighter(Colors.accent, 1.25)
                }
                GradientStop {
                    position: 1
                    color: Qt.darker(Colors.accent, 1.3)
                }
            }

            StyledIcon {
                anchors.centerIn: parent
                iconName: root.app.glyph ?? "circles-four"
                tint: "white"
                width: parent.width * 0.56
                height: width
            }
        }
    }

    Rectangle {
        visible: root.sep
        anchors.horizontalCenter: parent.horizontalCenter
        y: root.height - height
        width: 1
        height: root.lineHeight
        color: Colors.light ? Qt.rgba(0, 0, 0, 0.18) : Qt.rgba(1, 1, 1, 0.22)
    }

    Rectangle {
        anchors.horizontalCenter: parent.horizontalCenter
        y: root.height + 4
        width: 4
        height: 4
        radius: 2
        color: Colors.light ? Qt.rgba(0, 0, 0, 0.7) : Qt.rgba(1, 1, 1, 0.85)
        opacity: root.running ? root.appear : 0

        Behavior on opacity {
            NumberAnimation {
                duration: 200
            }
        }
    }

    Rectangle {
        id: tip
        anchors.horizontalCenter: parent.horizontalCenter
        y: face.y - height - 10
        width: label.implicitWidth + 22
        height: label.implicitHeight + 12
        radius: height / 2
        color: Colors.light ? Qt.rgba(1, 1, 1, 0.82) : Qt.rgba(0.12, 0.12, 0.14, 0.85)
        border.width: 1
        border.color: Colors.light ? Qt.rgba(0, 0, 0, 0.08) : Qt.rgba(1, 1, 1, 0.14)
        opacity: root.lit ? 1 : 0
        visible: opacity > 0.01

        Behavior on opacity {
            NumberAnimation {
                duration: 140
            }
        }

        StyledText {
            id: label
            anchors.centerIn: parent
            text: root.app.name ?? ""
            textSize: 12
            color: Colors.light ? Qt.rgba(0, 0, 0, 0.86) : Qt.rgba(1, 1, 1, 0.94)
        }
    }

    Timer {
        interval: 4000
        running: true
        onTriggered: console.log("DOCKDBG3 icon=" + root.app.key + " size=" + root.size + " w=" + root.width + " sep=" + root.sep)
    }
}
