import Quickshell
import Quickshell.Io
import qs.modules.Services
import qs.settings
import qs.modules.notifications

IpcHandler {
    id: handler
    target: "config"
    function reload() {
        Quickshell.reload(false);
    }
    function openPicker() {
        WidgetTracker.toggle("colors", Compositor.focusedScreen);
    }
    function toggleWallpapers() {
        WidgetTracker.toggle("wallpapers", Compositor.focusedScreen);
    }
    function toggleLauncher() {
        Island.togglePage("launcher", Compositor.focusedScreen);
    }
    function toggleControl() {
        Island.togglePage("main", Compositor.focusedScreen);
    }
    function toggleDnd() {
        NotiServer.dnd = !NotiServer.dnd;
    }
    function toggleClipboard() {
        Island.togglePage("clipboard", Compositor.focusedScreen);
    }
    function togglePower() {
        Island.togglePage("power", Compositor.focusedScreen);
    }
    function openPower() {
        Island.showPage("power", Compositor.focusedScreen);
    }
    function closePower() {
        if (Island.page === "power")
            Island.dismiss();
    }
    function osdBrightness() {
        Brightness.refresh();
        Island.showOsd("brightness");
    }
    function resetWidgets() {
        const layout = Config.cfg.widgets.layout;
        for (const key of ["clock", "calendar", "music", "weather", "system", "discord"]) {
            layout[key + "Screen"] = "";
            layout[key + "X"] = -1;
            layout[key + "Y"] = -1;
        }
    }
    function closeWidgets() {
        WidgetTracker.close();
    }
    function volumeUp() {
        Audio.adjust(0.05);
    }
    function volumeDown() {
        Audio.adjust(-0.05);
    }
    function toggleMute() {
        Audio.toggleMute();
    }
    function toggleMic() {
        Audio.toggleMic();
    }
    function brightnessUp() {
        Brightness.set(Math.min(1, Brightness.value + 0.05));
    }
    function brightnessDown() {
        Brightness.set(Math.max(0.01, Brightness.value - 0.05));
    }
    function playPause() {
        Media.toggle();
    }
    function nextTrack() {
        Media.next();
    }
    function prevTrack() {
        Media.previous();
    }
    function toggleCaffeine() {
        Toggles.caffeine = !Toggles.caffeine;
    }
    function toggleNightLight() {
        Toggles.nightLight = !Toggles.nightLight;
    }
    function toggleGameMode() {
        Toggles.gameMode = !Toggles.gameMode;
    }
    function toggleRecording() {
        Toggles.toggleRecording();
    }
    function screenshot() {
        Toggles.capture();
    }
    function lock() {
        Toggles.lock();
    }
}
