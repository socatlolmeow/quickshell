pragma Singleton
import Quickshell
import Quickshell.Services.Notifications
import QtQuick
import qs.modules.Services
import qs.settings

Singleton {
    id: root
    property list<Notification> notifications: server.trackedNotifications.values
    property var history: []
    property int unread: 0
    property bool dnd: false

    onDndChanged: Island.showToggle("moon", "Do Not Disturb", dnd)

    NotificationServer {
        id: server
        actionsSupported: true
        imageSupported: true
        bodyImagesSupported: true

        onNotification: notification => {
            const info = {
                appName: notification.appName,
                summary: notification.summary,
                body: notification.body,
                image: notification.image,
                appIcon: notification.appIcon,
                time: new Date()
            };
            if (!root.dnd) {
                notification.tracked = true;
                // drop it out of the island like an iOS banner (the card window stays as the fallback)
                if (Config.cfg.island.banners)
                    Island.pushBanner(notification);
            }
            root.history = [info].concat(root.history).slice(0, 20);
            if (!Island.open)
                root.unread++;
        }
    }
}
