import Quickshell
import Quickshell.Widgets
import Quickshell.Services.Notifications
import QtQuick.Layouts
import QtQuick
import qs
import qs.settings
import qs.widgets

Panel {
    id: root
    required property var notification
    required property ShellScreen nScreen
    property alias timerStart: dismissTimer
    property real dismissProgress: 1.0
    readonly property color tone: notification?.urgency === NotificationUrgency.Critical ? Colors.urgent : Colors.accent
    readonly property string iconSource: notification?.image ? notification.image : (notification?.appIcon ? Quickshell.iconPath(notification.appIcon, true) : "")

    implicitWidth: Math.max(360, (nScreen?.width ?? 0) / 6)
    implicitHeight: 84
    bgAlpha: 0.72
    dropShadow: false
    border.color: Colors.hairline
    color: hover.containsMouse ? Colors.alpha(Colors.pillCard2, 0.9) : Colors.alpha(Colors.pillBg, bgAlpha)

    Timer {
        id: dismissTimer
        interval: 5000
        running: true
        repeat: false
        onTriggered: if (root.notification?.tracked) root.notification.expire()
    }

    Timer {
        interval: 250
        running: dismissTimer.running
        repeat: true
        onTriggered: root.dismissProgress = Math.max(0, root.dismissProgress - interval / dismissTimer.interval)
    }

    MouseArea {
        id: hover
        anchors.fill: parent
        acceptedButtons: Qt.LeftButton
        cursorShape: Qt.PointingHandCursor
        hoverEnabled: true
        onClicked: if (root.notification?.tracked) root.notification.dismiss()
    }

    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: 18
        anchors.rightMargin: 18
        spacing: 14

        Rectangle {
            Layout.preferredWidth: 44
            Layout.preferredHeight: 44
            Layout.alignment: Qt.AlignVCenter
            radius: 12
            color: Colors.alpha(root.tone, 0.15)

            IconImage {
                anchors.centerIn: parent
                visible: root.iconSource !== ""
                implicitSize: 32
                source: root.iconSource
            }

            StyledIcon {
                anchors.centerIn: parent
                visible: root.iconSource === ""
                iconName: "bell"
                tint: root.tone
            }
        }

        ColumnLayout {
            Layout.alignment: Qt.AlignVCenter
            Layout.fillWidth: true
            Layout.preferredWidth: 0
            spacing: 2

            StyledText {
                Layout.fillWidth: true
                text: root.notification?.appName ?? ""
                color: root.tone
                textSize: Config.cfg.appearance.fontSize - 3
                wght: Typography.wEmph
                elide: Text.ElideRight
            }

            StyledText {
                Layout.fillWidth: true
                text: root.notification?.summary ?? ""
                wght: Typography.wEmph
                elide: Text.ElideRight
            }

            StyledText {
                Layout.fillWidth: true
                text: root.notification?.body ?? ""
                color: Colors.pillSubtle
                elide: Text.ElideRight
                maximumLineCount: 1
            }
        }
    }

    Rectangle {
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        anchors.leftMargin: root.radius
        anchors.rightMargin: root.radius
        anchors.bottomMargin: 4
        height: 2
        radius: 1
        color: Colors.alpha(Colors.pillMuted, 0.2)

        Rectangle {
            width: parent.width * root.dismissProgress
            height: parent.height
            radius: parent.radius
            color: Colors.alpha(root.tone, 0.6)
        }
    }
}
