import QtQuick
import qs
import qs.widgets
import qs.modules.Services

WidgetCard {
    id: root
    radius: 30

    readonly property color track: dark ? Qt.rgba(1, 1, 1, 0.14) : Qt.rgba(0, 0, 0, 0.1)

    function toneFor(v) {
        return v > 0.9 ? root.red : v > 0.75 ? root.orange : Colors.accent;
    }

    Timer {
        running: root.slot.onScreen
        interval: 2000
        repeat: true
        triggeredOnStart: true
        onTriggered: SysInfo.refresh()
    }

    Row {
        anchors.centerIn: parent
        spacing: 26

        SysRing {
            value: SysInfo.cpu
            label: "CPU"
            sub: SysInfo.temp >= 0 ? Math.round(SysInfo.temp) + "°C" : " "
            fg: root.fg
            fgSub: root.fgSub
            track: root.track
            tone: root.toneFor(SysInfo.cpu)
        }
        SysRing {
            value: SysInfo.ram
            label: "Memory"
            sub: SysInfo.ramUsed.toFixed(1) + " GB"
            fg: root.fg
            fgSub: root.fgSub
            track: root.track
            tone: root.toneFor(SysInfo.ram)
        }
        SysRing {
            value: SysInfo.disk
            label: "Disk"
            sub: Math.round(SysInfo.diskFree) + " GB free"
            fg: root.fg
            fgSub: root.fgSub
            track: root.track
            tone: root.toneFor(SysInfo.disk)
        }
    }
}
