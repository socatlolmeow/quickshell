import QtQuick
import qs
import qs.widgets
import qs.modules.Services

WidgetCard {
    id: root
    radius: 30

    readonly property bool sunny: Weather.icon === "sun" || Weather.icon === "moon"

    Column {
        anchors.fill: parent
        anchors.margins: 16
        spacing: 0

        StyledText {
            width: parent.width
            text: Weather.city !== "" ? Weather.city : "Weather"
            color: root.fg
            textSize: 15
            wght: Typography.wStrong
            elide: Text.ElideRight
        }

        StyledText {
            text: Weather.ready ? Weather.temp + "°" : "--°"
            color: root.fg
            textSize: 48
            wght: 320
            rond: 100
        }
    }

    Column {
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        anchors.margins: 16
        spacing: 1

        StyledIcon {
            width: 20
            height: 20
            iconName: Weather.icon
            tint: root.sunny ? "#FFD60A" : root.fg
        }

        StyledText {
            width: parent.width
            text: Weather.ready ? Weather.desc : "No data"
            color: root.fg
            textSize: 13
            wght: Typography.wStrong
            elide: Text.ElideRight
        }

        StyledText {
            visible: Weather.ready
            text: "H:" + Weather.high + "°  L:" + Weather.low + "°"
            color: root.fgSub
            textSize: 13
        }
    }
}
