import Quickshell.Widgets
import QtQuick
import qs
import qs.widgets
import qs.modules.Services

WidgetCard {
    id: root
    radius: 30

    readonly property var player: Media.player
    readonly property real length: player?.lengthSupported ? player.length : 0
    readonly property real position: player?.positionSupported ? player.position : 0
    readonly property real progress: length > 0 ? Math.min(Math.max(position / length, 0), 1) : 0
    readonly property bool canSeek: length > 0 && (player?.canSeek ?? false)

    function stamp(seconds) {
        const s = Math.max(0, Math.floor(seconds));
        return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0");
    }

    component Control: Item {
        id: ctl
        required property string iconName
        property real iconSize: 22
        property bool active: true
        signal clicked

        width: 44
        height: 44
        opacity: active ? 1 : 0.4
        scale: ctlArea.pressed ? 0.88 : 1

        Behavior on scale {
            NumberAnimation {
                duration: 90
            }
        }

        StyledIcon {
            anchors.centerIn: parent
            width: ctl.iconSize
            height: ctl.iconSize
            iconName: ctl.iconName
            tint: root.fg
        }
        MouseArea {
            id: ctlArea
            anchors.fill: parent
            enabled: ctl.active
            cursorShape: Qt.PointingHandCursor
            onClicked: ctl.clicked()
        }
    }

    Timer {
        interval: 1000
        repeat: true
        running: Media.playing && root.visible
        onTriggered: Media.player.positionChanged()
    }

    ClippingRectangle {
        x: 16
        y: 16
        width: root.height - 32
        height: width
        radius: 18
        color: Qt.rgba(root.fg.r, root.fg.g, root.fg.b, 0.12)

        Image {
            anchors.fill: parent
            source: Media.artUrl
            fillMode: Image.PreserveAspectCrop
            asynchronous: true
            opacity: status === Image.Ready ? 1 : 0

            Behavior on opacity {
                NumberAnimation {
                    duration: 300
                }
            }
        }
        StyledIcon {
            anchors.centerIn: parent
            width: 40
            height: 40
            visible: Media.artUrl === ""
            iconName: "music-notes"
            tint: root.fgSub
        }
    }

    Column {
        x: root.height
        y: 16
        width: root.width - x - 16
        height: root.height - 32
        spacing: 2

        StyledText {
            width: parent.width
            text: Media.title || "Not Playing"
            color: root.fg
            textSize: 15
            wght: Typography.wStrong
            elide: Text.ElideRight
        }
        StyledText {
            width: parent.width
            visible: text !== ""
            text: Media.artist
            color: root.fgSub
            textSize: 13
            elide: Text.ElideRight
        }

        Item {
            width: parent.width
            height: 14
        }

        Item {
            width: parent.width
            height: 14
            visible: root.length > 0

            Rectangle {
                anchors.verticalCenter: parent.verticalCenter
                width: parent.width
                height: 4
                radius: 2
                color: Qt.rgba(root.fg.r, root.fg.g, root.fg.b, 0.22)

                Rectangle {
                    width: Math.max(parent.height, parent.width * root.progress)
                    height: parent.height
                    radius: 2
                    color: root.fg
                }
            }
            MouseArea {
                anchors.fill: parent
                enabled: root.canSeek
                cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
                onClicked: mouse => root.player.position = Math.max(0, Math.min(1, mouse.x / width)) * root.length
            }
        }

        Item {
            width: parent.width
            height: 14
            visible: root.length > 0

            StyledText {
                text: root.stamp(root.position)
                color: root.fgSub
                textSize: 11
                tabular: true
            }
            StyledText {
                anchors.right: parent.right
                text: "-" + root.stamp(root.length - root.position)
                color: root.fgSub
                textSize: 11
                tabular: true
            }
        }
    }

    Row {
        x: root.height + (root.width - root.height - 16 - width) / 2
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 12
        spacing: 8

        Control {
            iconName: "skip-back"
            active: root.player?.canGoPrevious ?? false
            onClicked: root.player.previous()
        }
        Control {
            iconName: Media.playing ? "pause" : "play"
            iconSize: 28
            active: root.player?.canTogglePlaying ?? false
            onClicked: Media.toggle()
        }
        Control {
            iconName: "skip-forward"
            active: root.player?.canGoNext ?? false
            onClicked: root.player.next()
        }
    }
}
