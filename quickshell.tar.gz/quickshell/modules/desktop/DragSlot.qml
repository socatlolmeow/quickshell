import QtQuick
import qs.modules.Services

Item {
    id: root
    required property string key
    required property var win
    property bool shown: true

    readonly property Image wall: win.wall
    readonly property size cardSize: WidgetLayout.sizes[key]
    readonly property point spot: WidgetLayout.place(key)
    readonly property bool dragging: WidgetLayout.dragKey === key
    readonly property bool onScreen: shown && x < win.width + 24 && y < win.height + 24 && x + width > -24 && y + height > -24

    visible: shown
    width: shown ? cardSize.width : 0
    height: shown ? cardSize.height : 0
    x: spot.x - win.screen.x
    y: spot.y - win.screen.y
    z: dragging ? 10 : 0

    default property alias content: holder.data

    MouseArea {
        id: area
        anchors.fill: parent
        preventStealing: true
        cursorShape: root.dragging ? Qt.ClosedHandCursor : Qt.OpenHandCursor

        property real grabX: 0
        property real grabY: 0

        function pointer(mouse) {
            const p = area.mapToItem(null, mouse.x, mouse.y);
            return Qt.point(root.win.screen.x + p.x, root.win.screen.y + p.y);
        }

        onPressed: mouse => {
            const p = pointer(mouse);
            grabX = p.x - root.spot.x;
            grabY = p.y - root.spot.y;
            WidgetLayout.begin(root.key, root.spot.x, root.spot.y);
        }
        onPositionChanged: mouse => {
            if (pressed && root.dragging) {
                const p = pointer(mouse);
                WidgetLayout.move(p.x - grabX, p.y - grabY);
            }
        }
        onReleased: WidgetLayout.finish()
        onCanceled: WidgetLayout.finish()
    }

    Item {
        id: holder
        anchors.fill: parent
    }
}
