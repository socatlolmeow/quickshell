import Quickshell
import QtQuick
import qs
import qs.widgets

WidgetCard {
    id: root
    radius: 30

    SystemClock {
        id: clock
        precision: SystemClock.Seconds
    }

    readonly property int sec: clock.date.getSeconds()
    readonly property real daySecs: clock.date.getHours() * 3600 + clock.date.getMinutes() * 60 + sec
    property real secAngle: 0

    onSecChanged: {
        if (sec === 1) {
            secBehavior.enabled = false;
            secAngle = 0;
            secBehavior.enabled = true;
        }
        secAngle = sec === 0 ? 360 : sec * 6;
    }

    Behavior on secAngle {
        id: secBehavior
        NumberAnimation {
            duration: 320
            easing.type: Easing.OutBack
            easing.overshoot: 1.6
        }
    }

    Component.onCompleted: secAngle = sec === 0 ? 360 : sec * 6

    component Hand: Item {
        property real length: 50
        property real thickness: 4
        property color color: root.fg
        property real tail: 0
        anchors.centerIn: parent
        width: 0
        height: 0

        Rectangle {
            x: -parent.thickness / 2
            y: -parent.length
            width: parent.thickness
            height: parent.length + parent.tail
            radius: width / 2
            color: parent.color
        }
    }

    Repeater {
        model: 60

        delegate: Item {
            id: tick
            required property int index
            readonly property bool major: index % 5 === 0
            anchors.centerIn: parent
            width: 0
            height: 0
            rotation: index * 6

            Rectangle {
                x: tick.major ? -1 : -0.5
                y: -root.height / 2 + 9
                width: tick.major ? 2 : 1
                height: tick.major ? 7 : 4
                radius: width / 2
                color: tick.major ? root.fg : root.fgSub
            }
        }
    }

    Repeater {
        model: 12

        delegate: StyledText {
            id: num
            required property int index
            readonly property real angle: (index + 1) * Math.PI / 6
            x: root.width / 2 + 47 * Math.sin(angle) - width / 2
            y: root.height / 2 - 47 * Math.cos(angle) - height / 2
            text: index + 1
            color: root.fg
            textSize: 14
            wght: Typography.wStrong
            tabular: true
        }
    }

    Hand {
        length: 36
        thickness: 4.5
        rotation: (root.daySecs % 43200) / 120
    }

    Hand {
        length: 56
        thickness: 3
        rotation: (root.daySecs % 3600) / 10
    }

    Hand {
        length: 62
        thickness: 1.6
        tail: 14
        color: root.orange
        rotation: root.secAngle
    }

    Rectangle {
        anchors.centerIn: parent
        width: 9
        height: 9
        radius: 4.5
        color: root.orange
    }
}
