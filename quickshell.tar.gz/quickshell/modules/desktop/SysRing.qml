import QtQuick
import QtQuick.Shapes
import qs
import qs.widgets

Item {
    id: root
    property real value: 0
    property string label: ""
    property string sub: ""
    property color fg: "white"
    property color fgSub: "gray"
    property color track: Qt.rgba(1, 1, 1, 0.14)
    property color tone: Colors.accent
    readonly property real d: 78
    property real shown: Math.max(0, Math.min(1, value))

    implicitWidth: d
    implicitHeight: d + 36

    Behavior on shown {
        NumberAnimation {
            duration: 700
            easing.type: Easing.BezierSpline
            easing.bezierCurve: Motion.smooth
        }
    }

    Shape {
        id: ring
        width: root.d
        height: root.d
        anchors.horizontalCenter: parent.horizontalCenter
        preferredRendererType: Shape.CurveRenderer

        ShapePath {
            strokeColor: root.track
            strokeWidth: 9
            fillColor: "transparent"
            capStyle: ShapePath.RoundCap
            PathAngleArc {
                centerX: root.d / 2
                centerY: root.d / 2
                radiusX: root.d / 2 - 5
                radiusY: root.d / 2 - 5
                startAngle: -90
                sweepAngle: 359.9
            }
        }
        ShapePath {
            strokeColor: root.tone
            strokeWidth: 9
            fillColor: "transparent"
            capStyle: ShapePath.RoundCap
            PathAngleArc {
                centerX: root.d / 2
                centerY: root.d / 2
                radiusX: root.d / 2 - 5
                radiusY: root.d / 2 - 5
                startAngle: -90
                sweepAngle: Math.max(0.1, 359.9 * root.shown)
            }
        }
    }

    StyledText {
        anchors.centerIn: ring
        text: Math.round(root.value * 100)
        color: root.fg
        textSize: 22
        wght: 420
        rond: 100
        tabular: true
    }

    Column {
        anchors.top: ring.bottom
        anchors.topMargin: 6
        anchors.horizontalCenter: parent.horizontalCenter
        spacing: 0

        StyledText {
            anchors.horizontalCenter: parent.horizontalCenter
            text: root.label
            color: root.fg
            textSize: 12
            wght: Typography.wStrong
        }
        StyledText {
            anchors.horizontalCenter: parent.horizontalCenter
            text: root.sub
            color: root.fgSub
            textSize: 11
        }
    }
}
