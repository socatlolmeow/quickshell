import Quickshell.Widgets
import QtQuick
import qs
import qs.widgets
import qs.modules.Services

WidgetCard {
    id: root
    radius: 30

    readonly property color blurple: "#5865F2"

    Timer {
        running: root.slot.onScreen && Discord.hasToken
        interval: 60000
        repeat: true
        triggeredOnStart: true
        onTriggered: Discord.refresh()
    }

    Row {
        id: head
        x: 16
        y: 16
        spacing: 12
        visible: Discord.hasToken && Discord.me !== null

        ClippingRectangle {
            width: 40
            height: 40
            radius: 20
            color: root.blurple

            Image {
                anchors.fill: parent
                source: Discord.avatar
                fillMode: Image.PreserveAspectCrop
                asynchronous: true
                opacity: status === Image.Ready ? 1 : 0

                Behavior on opacity {
                    NumberAnimation {
                        duration: 300
                    }
                }
            }
            StyledText {
                anchors.centerIn: parent
                visible: Discord.avatar === ""
                text: Discord.name.charAt(0).toUpperCase()
                color: "white"
                textSize: 18
                wght: Typography.wStrong
            }
        }

        Column {
            anchors.verticalCenter: parent.verticalCenter
            width: root.width - 32 - 40 - 12 - 34 - 12
            spacing: 0

            StyledText {
                width: parent.width
                text: Discord.name
                color: root.fg
                textSize: 15
                wght: Typography.wStrong
                elide: Text.ElideRight
            }
            StyledText {
                width: parent.width
                text: Discord.handle + "  ·  " + Discord.guilds + (Discord.guilds === 1 ? " server" : " servers")
                color: root.fgSub
                textSize: 12
                elide: Text.ElideRight
            }
        }
    }

    Rectangle {
        visible: head.visible
        anchors.top: parent.top
        anchors.right: parent.right
        anchors.margins: 16
        anchors.topMargin: 25
        width: 34
        height: 22
        radius: 11
        color: Discord.unread > 0 ? root.blurple : Qt.rgba(root.fg.r, root.fg.g, root.fg.b, 0.12)

        StyledText {
            anchors.centerIn: parent
            text: Discord.unread > 9 ? "9+" : Discord.unread
            color: Discord.unread > 0 ? "white" : root.fgSub
            textSize: 12
            wght: Typography.wStrong
            tabular: true
        }
        MouseArea {
            anchors.fill: parent
            cursorShape: Qt.PointingHandCursor
            onClicked: Discord.markAllRead()
        }
    }

    Column {
        visible: head.visible
        x: 16
        y: 68
        width: root.width - 32
        spacing: 2

        Repeater {
            model: Discord.feed

            Item {
                id: row
                required property var modelData
                width: parent.width
                height: 38

                Rectangle {
                    anchors.fill: parent
                    radius: 12
                    color: Qt.rgba(root.fg.r, root.fg.g, root.fg.b, hit.containsMouse ? 0.1 : 0)
                }
                Rectangle {
                    x: 8
                    anchors.verticalCenter: parent.verticalCenter
                    width: 8
                    height: 8
                    radius: 4
                    color: row.modelData.unread ? root.blurple : "transparent"
                }
                Column {
                    x: 24
                    anchors.verticalCenter: parent.verticalCenter
                    width: parent.width - 32
                    spacing: 0

                    StyledText {
                        width: parent.width
                        text: row.modelData.title
                        color: root.fg
                        textSize: 13
                        wght: row.modelData.unread ? Typography.wStrong : Typography.wBody
                        elide: Text.ElideRight
                    }
                    StyledText {
                        width: parent.width
                        text: row.modelData.text
                        color: root.fgSub
                        textSize: 12
                        elide: Text.ElideRight
                    }
                }
                MouseArea {
                    id: hit
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: Discord.open(row.modelData)
                }
            }
        }
    }

    StyledText {
        visible: head.visible && Discord.feed.length === 0
        anchors.horizontalCenter: parent.horizontalCenter
        y: 104
        text: Discord.loading ? "Loading…" : "All caught up"
        color: root.fgSub
        textSize: 13
    }

    StyledText {
        visible: !head.visible
        anchors.centerIn: parent
        width: parent.width - 48
        horizontalAlignment: Text.AlignHCenter
        wrapMode: Text.WordWrap
        color: root.fgSub
        textSize: 13
        text: !Discord.hasToken ? "Put your token in\nsettings/discord.token" : Discord.error !== "" ? Discord.error : "Loading…"
    }
}
