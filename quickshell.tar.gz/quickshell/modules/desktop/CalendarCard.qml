import Quickshell
import QtQuick
import qs
import qs.widgets

WidgetCard {
    id: root
    radius: 30

    property date viewDate: new Date()
    readonly property var locale: Qt.locale()
    readonly property int firstDay: locale.firstDayOfWeek
    readonly property var today: clock.date
    readonly property var cells: {
        const y = viewDate.getFullYear();
        const m = viewDate.getMonth();
        const offset = (new Date(y, m, 1).getDay() - firstDay + 7) % 7;
        const total = Math.ceil((offset + new Date(y, m + 1, 0).getDate()) / 7) * 7;
        const out = [];
        for (let i = 0; i < total; i++) {
            const d = new Date(y, m, 1 - offset + i);
            out.push({
                day: d.getDate(),
                inMonth: d.getMonth() === m,
                today: d.getFullYear() === today.getFullYear() && d.getMonth() === today.getMonth() && d.getDate() === today.getDate()
            });
        }
        return out;
    }

    function shift(delta) {
        viewDate = new Date(viewDate.getFullYear(), viewDate.getMonth() + delta, 1);
    }

    SystemClock {
        id: clock
        precision: SystemClock.Hours
    }

    WheelHandler {
        onWheel: event => root.shift(event.angleDelta.y > 0 ? -1 : 1)
    }

    Column {
        x: 18
        anchors.verticalCenter: parent.verticalCenter
        width: 112
        spacing: -2

        StyledText {
            text: Qt.formatDate(clock.date, "dddd").toUpperCase()
            color: root.red
            textSize: 12
            wght: Typography.wStrong
        }
        StyledText {
            text: clock.date.getDate()
            color: root.fg
            textSize: 62
            wght: 460
            tabular: true
        }
        StyledText {
            width: parent.width
            text: root.locale.monthName(root.viewDate.getMonth(), Locale.LongFormat) + " " + root.viewDate.getFullYear()
            color: root.fgSub
            textSize: 13
            elide: Text.ElideRight

            MouseArea {
                anchors.fill: parent
                cursorShape: Qt.PointingHandCursor
                onClicked: root.viewDate = new Date()
            }
        }
    }

    Column {
        x: 150
        anchors.verticalCenter: parent.verticalCenter
        width: 190

        Row {
            Repeater {
                model: 7

                delegate: Item {
                    id: head
                    required property int index
                    width: 190 / 7
                    height: 20

                    StyledText {
                        anchors.centerIn: parent
                        text: root.locale.dayName((root.firstDay + head.index) % 7, Locale.NarrowFormat)
                        color: root.fgSub
                        textSize: 11
                        wght: Typography.wStrong
                    }
                }
            }
        }

        Grid {
            columns: 7

            Repeater {
                model: root.cells

                delegate: Item {
                    id: cell
                    required property var modelData
                    width: 190 / 7
                    height: 19

                    Rectangle {
                        anchors.centerIn: parent
                        width: 19
                        height: 19
                        radius: 9.5
                        visible: cell.modelData.today
                        color: root.red
                    }
                    StyledText {
                        anchors.centerIn: parent
                        text: cell.modelData.day
                        textSize: 11.5
                        wght: cell.modelData.today ? Typography.wStrong : Typography.wMedium
                        tabular: true
                        color: cell.modelData.today ? "white" : cell.modelData.inMonth ? root.fg : Qt.rgba(root.fgSub.r, root.fgSub.g, root.fgSub.b, 0.4)
                    }
                }
            }
        }
    }
}
