import Quickshell
import Quickshell.Wayland
import QtQuick
import qs.settings

Variants {
    model: Config.cfg.widgets.enabled ? Quickshell.screens : []

    delegate: PanelWindow {
        id: root
        required property ShellScreen modelData
        readonly property Image wall: wall

        screen: modelData
        anchors {
            top: true
            bottom: true
            left: true
            right: true
        }
        exclusionMode: ExclusionMode.Ignore
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Bottom
        WlrLayershell.namespace: "qs-widgets"
        WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
        mask: Region {
            regions: [
                Region {
                    item: clock
                },
                Region {
                    item: calendar
                },
                Region {
                    item: music
                },
                Region {
                    item: weather
                },
                Region {
                    item: sysSlot
                },
                Region {
                    item: discSlot
                }
            ]
        }

        Image {
            id: wall
            anchors.fill: parent
            visible: false
            asynchronous: true
            fillMode: Image.PreserveAspectCrop
            sourceSize: Qt.size(root.width, root.height)
            source: Config.cfg.wallpaper.wallpaper !== "" ? Qt.resolvedUrl(Config.cfg.wallpaper.wallpaper) : ""
        }

        DragSlot {
            id: music
            key: "music"
            win: root
            shown: Config.cfg.widgets.music

            MusicCard {
                anchors.fill: parent
                slot: music
            }
        }

        DragSlot {
            id: calendar
            key: "calendar"
            win: root
            shown: Config.cfg.widgets.calendar

            CalendarCard {
                anchors.fill: parent
                slot: calendar
            }
        }

        DragSlot {
            id: clock
            key: "clock"
            win: root
            shown: Config.cfg.widgets.clock

            ClockCard {
                anchors.fill: parent
                slot: clock
            }
        }

        DragSlot {
            id: weather
            key: "weather"
            win: root
            shown: Config.cfg.widgets.weather

            WeatherCard {
                anchors.fill: parent
                slot: weather
            }
        }

        DragSlot {
            id: sysSlot
            key: "system"
            win: root
            shown: Config.cfg.widgets.system

            SystemCard {
                anchors.fill: parent
                slot: sysSlot
            }
        }

        DragSlot {
            id: discSlot
            key: "discord"
            win: root
            shown: Config.cfg.widgets.discord

            DiscordCard {
                anchors.fill: parent
                slot: discSlot
            }
        }
    }
}
