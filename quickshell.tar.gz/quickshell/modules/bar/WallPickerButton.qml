import QtQuick
import qs
import qs.widgets
import qs.modules.Services
import Quickshell

BarComponent {
    id: root
    required property ShellScreen barScreen
    implicitWidth: implicitHeight
    active: clickHandler.containsMouse
    StyledIcon {
        iconName: "image"
        tint: root.active ? Colors.font : Colors.subtle
        anchors.centerIn: parent
    }
    MouseArea {
        id: clickHandler
        anchors.fill: parent
        hoverEnabled: true
        acceptedButtons: Qt.LeftButton
        cursorShape: Qt.PointingHandCursor
        onClicked: WidgetTracker.toggle("wallpapers", root.barScreen)
    }
}
