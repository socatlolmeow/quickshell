import Quickshell.Services.UPower
import QtQuick
import QtQuick.Layouts
import qs
import qs.widgets
import qs.settings

BarComponent {
    id: root
    visible: UPower.displayDevice.isLaptopBattery
    property double percent: UPower.displayDevice.percentage * 100
    property bool charging: UPower.displayDevice.state === UPowerDeviceState.Charging
    readonly property bool low: !charging && percent <= 15
    readonly property color tone: low ? Colors.urgent : (charging ? Colors.ok : Colors.font)
    implicitWidth: batLayout.implicitWidth + 16

    function batteryIcon(): string {
        if (root.charging)
            return "battery-charging";
        if (root.percent <= 25)
            return "battery-warning";
        if (root.percent <= 50)
            return "battery-medium";
        if (root.percent <= 75)
            return "battery-high";
        return "battery-full";
    }
    RowLayout {
        id: batLayout
        anchors.centerIn: root
        spacing: 6
        StyledIcon {
            iconName: root.batteryIcon()
            tint: root.tone
        }
        StyledText {
            text: Math.floor(root.percent) + "%"
            color: root.tone
        }
    }
}
