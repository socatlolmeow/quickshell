import QtQuick
import qs

/* One live-activity slot in the idle pill (iOS "compact" activity).
 * Springs open to fit its content plus an 8px leading gap, and folds back to
 * nothing when `on` is false, so the island grows and shrinks around it. */
Item {
    id: chip
    property bool on: false
    /* width of the content, without the leading gap */
    property real natural: 0
    default property alias content: holder.data

    width: on ? natural + 8 : 0
    height: 18
    clip: true
    visible: width > 0.5

    Behavior on width {
        NumberAnimation {
            duration: 300
            easing.type: Easing.BezierSpline
            easing.bezierCurve: Motion.smooth
        }
    }

    Item {
        id: holder
        x: 8
        width: chip.natural
        height: chip.height
        opacity: chip.on ? 1 : 0
        scale: chip.on ? 1 : 0.8
        transformOrigin: Item.Left

        Behavior on opacity {
            NumberAnimation {
                duration: 200
                easing.type: Easing.BezierSpline
                easing.bezierCurve: Motion.fade
            }
        }
        Behavior on scale {
            NumberAnimation {
                duration: 380
                easing.type: Easing.BezierSpline
                easing.bezierCurve: Motion.smooth
            }
        }
    }
}
