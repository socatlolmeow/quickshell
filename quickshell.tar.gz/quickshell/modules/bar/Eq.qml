import QtQuick
import qs
import qs.modules.Services

Item {
    implicitWidth: row.implicitWidth
    implicitHeight: 16

    Row {
        id: row
        spacing: 3
        anchors.verticalCenter: parent.verticalCenter

        Repeater {
            model: Cava.levels.length

            Rectangle {
                required property int index
                width: 3
                height: 4 + Math.min(Cava.levels[index] ?? 0, 1) * 12
                radius: 1.5
                anchors.verticalCenter: parent.verticalCenter
                color: Cava.active ? Colors.accent : Colors.alpha(Colors.accent, 0.45)

                Behavior on height {
                    NumberAnimation {
                        duration: 60
                    }
                }
                Behavior on color {
                    ColorAnimation {
                        duration: 200
                    }
                }
            }
        }
    }
}
