import Quickshell
import Quickshell.WindowManager
import QtQuick
import qs
import qs.settings

Item {
    id: root
    required property ShellScreen barScreen
    property real wheelAcc: 0

    /* Settled width used by Bar.qml for notch sizing. Updated every frame
     * while a dot animates (via onWidthChanged) so the notch tracks
     * the transition smoothly instead of snapping to the final value. */
    property real targetWidth: 0

    implicitWidth: row.implicitWidth
    implicitHeight: 16

    function recalc() {
        let w = 0;
        let n = 0;
        for (let i = 0; i < rep.count; i++) {
            const it = rep.itemAt(i);
            if (!it || !it.shown)
                continue;
            w += it.width;  // live animated width, not the target slot width
            n++;
        }
        targetWidth = n > 0 ? w + (n - 1) * row.spacing : 0;
    }

    function isShown(set) {
        return !!set.active || !!set.shouldDisplay || !!set.urgent || !Config.cfg.workspaces.hideEmpty;
    }

    function step(dir) {
        const all = WindowManager.screenProjection(root.barScreen).windowsets.values ?? [];
        const sets = all.filter(root.isShown);
        let cur = -1;
        for (let i = 0; i < sets.length; i++) {
            if (sets[i].active) {
                cur = i;
                break;
            }
        }
        const next = cur + dir;
        if (cur < 0 || next < 0 || next >= sets.length)
            return;
        sets[next].activate();
    }

    WheelHandler {
        enabled: Config.cfg.workspaces.scroll
        onWheel: event => {
            root.wheelAcc += event.angleDelta.y;
            if (Math.abs(root.wheelAcc) >= 120) {
                root.step(root.wheelAcc > 0 ? -1 : 1);
                root.wheelAcc = 0;
            }
        }
    }

    Row {
        id: row
        spacing: 5
        anchors.verticalCenter: parent.verticalCenter

        Repeater {
            id: rep
            model: WindowManager.screenProjection(root.barScreen).windowsets
            onItemAdded: Qt.callLater(root.recalc)
            onItemRemoved: Qt.callLater(root.recalc)

            delegate: Rectangle {
                id: dot
                required property var modelData
                readonly property bool isActive: !!modelData.active
                readonly property bool urgent: !!modelData.urgent

                readonly property bool shown: root.isShown(modelData)
                readonly property real slotWidth: isActive ? 12 : 9

                onShownChanged: root.recalc()
                onSlotWidthChanged: root.recalc()
                // fires every animation frame so the notch tracks the dot smoothly
                onWidthChanged: root.recalc()

                visible: shown
                width: slotWidth
                height: isActive ? 16 : 14
                radius: width / 2
                anchors.verticalCenter: parent.verticalCenter
                color: isActive ? Colors.accent
                    : urgent ? Colors.urgent
                    : ma.containsMouse ? Colors.alpha(Colors.accent, 0.5)
                    : Colors.pillDim

                Behavior on width {
                    NumberAnimation {
                        duration: 180
                        easing.type: Easing.OutCubic
                    }
                }
                Behavior on height {
                    NumberAnimation {
                        duration: 180
                        easing.type: Easing.OutCubic
                    }
                }
                Behavior on color {
                    ColorAnimation {
                        duration: 130
                    }
                }

                MouseArea {
                    id: ma
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: dot.modelData.activate()
                }
            }
        }
    }
}
