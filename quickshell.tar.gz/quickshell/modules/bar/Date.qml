import QtQuick
import Quickshell
import qs
import qs.widgets

StyledText {
    SystemClock {
        id: clock
        precision: SystemClock.Minutes
    }

    text: Qt.formatTime(clock.date, "HH:mm")
    color: Colors.pillFg
    wght: Typography.wEmph
    font.features: {
                            "tnum": 1,
                            "calt": 1,
                            "kern": 1
                        }
}
