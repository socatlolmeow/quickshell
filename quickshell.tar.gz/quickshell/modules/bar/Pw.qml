import Quickshell
import QtQuick
import QtQuick.Layouts
import qs
import qs.widgets
import qs.modules.Services

BarComponent {
    id: root
    required property ShellScreen barScreen
    active: clickHandler.containsMouse
    implicitWidth: pwLayout.implicitWidth + 16
    RowLayout {
        id: pwLayout
        anchors.centerIn: root
        spacing: 6
        StyledIcon {
            iconName: Audio.getVolumeIcon(Audio.defaultAudio)
            tint: Audio.muted ? Colors.muted : Colors.font
        }
        StyledText {
            text: Audio.percentage + "%"
            color: Audio.muted ? Colors.muted : Colors.font
        }
    }
    MouseArea {
        id: clickHandler
        hoverEnabled: true
        acceptedButtons: Qt.LeftButton | Qt.RightButton | Qt.MiddleButton
        cursorShape: Qt.PointingHandCursor
        anchors.fill: root
        onClicked: mouse => {
            if (mouse.button === Qt.LeftButton)
                WidgetTracker.toggle("volume", root.barScreen);
            else
                Audio.toggleMute();
        }
        onWheel: wheel => Audio.adjust(wheel.angleDelta.y / 120 * 0.03)
    }
}
