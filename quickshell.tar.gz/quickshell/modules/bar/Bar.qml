import Quickshell
import Quickshell.Wayland
import Quickshell.Widgets
import QtQuick
import QtQuick.Effects
import QtQuick.Layouts
import QtQuick.Shapes
import qs
import qs.settings
import qs.widgets
import qs.modules.Services
import qs.modules.notifications
import qs.modules.applets

Variants {
    model: Quickshell.screens
    delegate: PanelWindow {
        id: root
        required property ShellScreen modelData
        readonly property int hh: Config.cfg.bar.height
        // Floating pill like the iPhone's Dynamic Island. (Set to true for the old notch glued to the top edge;
        // this deliberately ignores bar.hang from settings.json so a stale setting can't bring the notch back.)
        readonly property bool hang: false
        readonly property int topGap: hang ? 0 : Config.cfg.bar.margin
        readonly property int pad: 14
        readonly property int gap: 14
        readonly property int eqInset: 10
        // gap between the clock and the equalizer (config: bar.eqOffset)
        readonly property int eqNudge: Config.cfg.bar.eqOffset
        readonly property bool mine: (Compositor.focusedScreen ?? modelData) === modelData
        readonly property bool expanded: Island.open && Island.screen === modelData && WidgetTracker.current === ""
        readonly property string mode: expanded ? "full" : (mine && Island.osdOn ? "osd" : (Island.popOn ? "pop" : "idle"))
        readonly property string wantPage: expanded ? Island.page : ""
        /* the launcher and the control panel take over the whole island: the bar row gets sucked up out of view */
        readonly property bool launching: expanded && (Island.page === "launcher" || Island.page === "main" || Island.page === "clipboard")
        property string livePage: ""

        onWantPageChanged: {
            if (wantPage === "") {
                unloadTimer.restart();
                return;
            }
            unloadTimer.stop();
            if (livePage === wantPage) {
                livePage = "";
                Qt.callLater(() => livePage = wantPage);
            } else {
                livePage = wantPage;
            }
        }

        Timer {
            id: unloadTimer
            interval: 400
            onTriggered: root.livePage = ""
        }

        readonly property int edge: 20
        readonly property int wsGap: ws.targetWidth > 0 ? 10 : 0
        readonly property real contentW: ws.targetWidth + wsGap + timeBox.targetWidth + artChip.width + eqNudge + eq.implicitWidth + acts.totalW
        readonly property real idleW: Math.round(contentW + edge * 2)
        readonly property real targetW: mode === "full" ? (Island.page === "launcher" ? (launcher.item ? launcher.item.implicitWidth : 560) : Island.page === "clipboard" ? (clip.item ? clip.item.implicitWidth : 560) : Island.page === "main" ? panel.implicitWidth : 516) : mode === "osd" ? 280 : mode === "pop" ? popW : idleW
        readonly property int popH: Island.popKind === "notif" ? 84 : 72
        readonly property int popW: Island.popKind === "notif" ? 392 : 340
        readonly property int themesH: 440
        readonly property int wallsH: 215
        readonly property int powerH: 160
        readonly property real launcherH: launcher.item ? launcher.item.implicitHeight : 68 + Config.cfg.launcher.maxRows * 40
        readonly property real clipH: clip.item ? clip.item.implicitHeight : 480
        readonly property real targetH: mode === "full" ? (Island.page === "launcher" ? launcherH : Island.page === "clipboard" ? clipH : Island.page === "main" ? panel.implicitHeight : hh + (Island.page === "themes" ? themesH : Island.page === "walls" ? wallsH : Island.page === "power" ? powerH : panel.implicitHeight)) : mode === "pop" ? popH : hh

        readonly property real osdValue: Island.osdKind === "volume" ? (Audio.muted ? 0 : Math.min(1, Audio.defaultAudio?.audio.volume ?? 0)) : Brightness.value
        readonly property string osdIcon: Island.osdKind === "volume" ? (Audio.defaultAudio ? Audio.getVolumeIcon(Audio.defaultAudio) : "speaker-none") : "sun-dim"

        screen: modelData
        anchors.top: true
        margins.top: root.topGap
        color: "transparent"
        WlrLayershell.namespace: "qs-bar"
        WlrLayershell.keyboardFocus: expanded && (Island.page === "power" || Island.page === "launcher" || Island.page === "clipboard") ? WlrKeyboardFocus.Exclusive : expanded && (Island.page === "themes" || Island.page === "walls") ? WlrKeyboardFocus.OnDemand : WlrKeyboardFocus.None
        implicitWidth: 660
        implicitHeight: Math.min(modelData.height - root.topGap, 1000)
        exclusiveZone: hh + topGap
        mask: Region {
            item: isl
        }

        /* wallpaper in screen coordinates (this window is centred at the top of the screen):
         * the control panel's liquid glass refracts and blurs this */
        Image {
            id: wall
            visible: false
            asynchronous: true
            fillMode: Image.PreserveAspectCrop
            x: -Math.round((root.modelData.width - root.width) / 2)
            y: -root.topGap
            width: root.modelData.width
            height: root.modelData.height
            sourceSize: Qt.size(width, height)
            source: Config.cfg.wallpaper.wallpaper !== "" ? Qt.resolvedUrl(Config.cfg.wallpaper.wallpaper) : ""
        }

        IdleInhibitor {
            window: root
            enabled: Toggles.caffeine || Toggles.gameMode
        }

        Item {
            id: isl
            anchors.top: parent.top
            x: Math.round((parent.width - width) / 2)
            property real animW: tw
            property real animH: th
            // spring state + constants per axis (k = w^2, c = 2*zeta*w, see tune())
            property real vW: 0
            property real vH: 0
            property real kW: 400
            property real cW: 40
            property real kH: 400
            property real cH: 40
            property string modeW
            property string modeH
            readonly property real tw: root.targetW
            readonly property real th: root.targetH
            /* corner radii: tight when idle (notch / capsule), generous when expanded like Apple's island.
             * Idle floating island is a perfect capsule (radius = height / 2). */
            property real rBase: root.mode === "full" ? (Island.page === "main" && panel.mac ? 26 : (root.hang ? 28 : 36)) : root.mode === "pop" ? 34 : (root.hang ? 16 : root.hh / 2)
            readonly property real r: Math.min(height / 2, rBase)
            // radius of the concave "ears" where the notch flows into the screen edge; grows when expanded
            property real ear: root.mode === "full" ? 18 : 10
            readonly property real topR: root.hang ? 0 : r

            Behavior on rBase {
                NumberAnimation {
                    duration: 380
                    easing.type: Easing.BezierSpline
                    easing.bezierCurve: Motion.smooth
                }
            }
            Behavior on ear {
                NumberAnimation {
                    duration: 380
                    easing.type: Easing.BezierSpline
                    easing.bezierCurve: Motion.smooth
                }
            }

            /* whole pixels only, and an even width so the island stays exactly centered */
            width: Math.max(40, Math.round(animW / 2) * 2)
            height: Math.max(root.hh, Math.round(animH))

            /* Size is driven by a real damped spring instead of a fixed-length easing, tuned the macOS way
             * (SwiftUI .smooth / .snappy): near-critical damping, so it glides and settles without wobbling.
             *  - opening is a confident spring with only a whisper of overshoot in width,
             *  - closing is quick and clean (no bounce),
             *  - small target changes (workspace dots growing) track tightly,
             *  - retargeting mid-flight keeps the velocity, so hovering in and out never snaps or restarts. */
            function tune(axis, delta, modeChanged) {
                let response, zeta;
                if (modeChanged) {
                    if (delta > 0) {
                        response = axis === "w" ? 0.36 : 0.40;
                        zeta = axis === "w" ? 0.88 : 0.96;
                    } else {
                        response = 0.26;
                        zeta = 1.0;
                    }
                } else if (Math.abs(delta) > 30) {
                    response = 0.32;
                    zeta = 0.96;
                } else {
                    response = 0.2;
                    zeta = 1.0;
                }
                const w = 2 * Math.PI / response;
                if (axis === "w") {
                    kW = w * w;
                    cW = 2 * zeta * w;
                } else {
                    kH = w * w;
                    cH = 2 * zeta * w;
                }
            }

            function stepSpring(dt) {
                if (dt <= 0)
                    return;
                dt = Math.min(dt, 0.05);
                const n = Math.max(1, Math.ceil(dt / 0.004));
                const h = dt / n;
                for (let i = 0; i < n; i++) {
                    vW += (-kW * (animW - tw) - cW * vW) * h;
                    animW += vW * h;
                    vH += (-kH * (animH - th) - cH * vH) * h;
                    animH += vH * h;
                }
                if (Math.abs(animW - tw) < 0.05 && Math.abs(vW) < 0.5 && Math.abs(animH - th) < 0.05 && Math.abs(vH) < 0.5) {
                    animW = tw;
                    animH = th;
                    vW = 0;
                    vH = 0;
                    driver.running = false;
                }
            }

            FrameAnimation {
                id: driver
                onTriggered: isl.stepSpring(frameTime)
            }

            onTwChanged: {
                tune("w", tw - animW, root.mode !== modeW);
                modeW = root.mode;
                driver.running = true;
            }
            onThChanged: {
                tune("h", th - animH, root.mode !== modeH);
                modeH = root.mode;
                driver.running = true;
            }

            HoverHandler {
                onHoveredChanged: Island.hoverBar(hovered, root.modelData)
            }

            /* press feedback: a quick, slight dip that eases back out (no rubber-band) */
            transformOrigin: Item.Top
            scale: tapMain.pressed && root.mode !== "full" ? 0.97 : 1
            Behavior on scale {
                NumberAnimation {
                    duration: tapMain.pressed ? 110 : 260
                    easing.type: Easing.BezierSpline
                    easing.bezierCurve: tapMain.pressed ? Motion.standard : Motion.smooth
                }
            }

            TapHandler {
                id: tapMain
                acceptedButtons: Qt.LeftButton
                onTapped: {
                    if (Island.clickMode && root.mode !== "full" && !(Island.popOn && Island.popKind === "notif"))
                        Island.clickOpen(root.modelData);
                }
            }

            /* click mode: right-click = Do Not Disturb (Focus), like the macOS menu bar */
            TapHandler {
                acceptedButtons: Qt.RightButton
                enabled: Island.clickMode && root.mode !== "full" && !(Island.popOn && Island.popKind === "notif")
                onTapped: NotiServer.dnd = !NotiServer.dnd
            }

            /* click mode: scroll over the island to change the volume */
            WheelHandler {
                enabled: Island.clickMode && root.mode !== "full"
                acceptedDevices: PointerDevice.Mouse | PointerDevice.TouchPad
                onWheel: event => {
                    const a = Audio.defaultAudio?.audio;
                    if (a)
                        a.volume = Math.max(0, Math.min(1, a.volume + event.angleDelta.y / 120 * 0.03));
                }
            }

            Rectangle {
                anchors.fill: parent
                radius: isl.r
                topLeftRadius: isl.topR
                topRightRadius: isl.topR
                color: Colors.alpha(Colors.pillBg, Config.cfg.bar.opacity)
                opacity: root.expanded && Island.page === "main" && panel.mac ? 0 : 1
                Behavior on opacity {
                    NumberAnimation {
                        duration: 220
                        easing.type: Easing.BezierSpline
                        easing.bezierCurve: Motion.fade
                    }
                }
                border.width: (root.hang || Config.cfg.bar.pureBlack) ? 0 : 1
                border.color: Colors.alpha(Colors.pillFg, 0.08)
                layer.enabled: true
                layer.effect: MultiEffect {
                    shadowEnabled: true
                    shadowColor: "black"
                    shadowOpacity: root.mode === "full" ? 0.55 : root.mode === "pop" ? 0.4 : 0.0
                    shadowBlur: 1
                    shadowVerticalOffset: 10

                    Behavior on shadowOpacity {
                        NumberAnimation {
                            duration: 300
                        }
                    }
                }
            }

            /* inverted corners: make the notch melt into the top edge of the screen.
             * Fixed-size shapes pinned to the island edges, so the paths are never rebuilt while it animates. */
            Shape {
                visible: root.hang
                x: -isl.ear
                y: 0
                width: isl.ear + 1
                height: isl.ear
                preferredRendererType: Shape.CurveRenderer

                ShapePath {
                    strokeWidth: -1
                    fillColor: Colors.alpha(Colors.pillBg, Config.cfg.bar.opacity)
                    startX: 0
                    startY: 0
                    PathLine { x: isl.ear + 1; y: 0 }
                    PathLine { x: isl.ear + 1; y: isl.ear }
                    PathLine { x: isl.ear; y: isl.ear }
                    PathArc {
                        x: 0
                        y: 0
                        radiusX: isl.ear
                        radiusY: isl.ear
                        direction: PathArc.Counterclockwise
                    }
                }
            }

            Shape {
                visible: root.hang
                x: isl.width - 1
                y: 0
                width: isl.ear + 1
                height: isl.ear
                preferredRendererType: Shape.CurveRenderer

                ShapePath {
                    strokeWidth: -1
                    fillColor: Colors.alpha(Colors.pillBg, Config.cfg.bar.opacity)
                    startX: isl.ear + 1
                    startY: 0
                    PathLine { x: 0; y: 0 }
                    PathLine { x: 0; y: isl.ear }
                    PathLine { x: 1; y: isl.ear }
                    PathArc {
                        x: isl.ear + 1
                        y: 0
                        radiusX: isl.ear
                        radiusY: isl.ear
                        direction: PathArc.Clockwise
                    }
                }
            }

            ClippingRectangle {
                anchors.fill: parent
                radius: isl.r
                topLeftRadius: isl.topR
                topRightRadius: isl.topR
                color: "transparent"

                Item {
                    id: header
                    width: isl.width
                    height: root.hh
                    y: root.launching ? -root.hh : 0
                    opacity: root.launching ? 0 : 1
                    visible: opacity > 0

                    Behavior on y {
                        SequentialAnimation {
                            PauseAnimation { duration: root.launching ? 0 : 100 }
                            NumberAnimation {
                                duration: root.launching ? 300 : 380
                                easing.type: Easing.BezierSpline
                                easing.bezierCurve: root.launching ? Motion.exit : Motion.smooth
                            }
                        }
                    }
                    Behavior on opacity {
                        SequentialAnimation {
                            PauseAnimation { duration: root.launching ? 0 : 120 }
                            NumberAnimation {
                                duration: root.launching ? 170 : 240
                                easing.type: Easing.BezierSpline
                                easing.bezierCurve: Motion.fade
                            }
                        }
                    }

                    MouseArea {
                        anchors.fill: parent
                        acceptedButtons: Qt.MiddleButton
                        onClicked: if (Audio.defaultAudio) Audio.defaultAudio.audio.muted = !Audio.defaultAudio.audio.muted
                    }

                    Item {
                        id: normal
                        anchors.fill: parent
                        opacity: root.mode === "osd" || root.mode === "pop" ? 0 : 1
                        visible: opacity > 0

                        Behavior on opacity {
                            NumberAnimation {
                                duration: 180
                            }
                        }

                        Row {
                            id: leftRow
                            x: Math.round((isl.width - root.contentW) / 2)
                            anchors.verticalCenter: parent.verticalCenter
                            spacing: 10

                            Ws {
                                id: ws
                                barScreen: root.modelData
                                anchors.verticalCenter: parent.verticalCenter
                            }
                        }

                        Item {
                            id: timeBox
                            readonly property real targetM: Math.max(Toggles.gameMode ? 18 : 0, NotiServer.unread > 0 ? 11 : 0)
                            readonly property real targetWidth: Math.ceil(clock.implicitWidth) + targetM * 2
                            property real m: targetM
                            width: Math.ceil(clock.implicitWidth) + m * 2

                            Behavior on m {
                                NumberAnimation {
                                    duration: 180
                                    easing.type: Easing.BezierSpline
                                    easing.bezierCurve: Motion.smooth
                                }
                            }

                            height: clock.implicitHeight
                            anchors.verticalCenter: parent.verticalCenter
                            x: leftRow.x + ws.targetWidth + root.wsGap

                            Date {
                                id: clock
                                x: timeBox.m
                                anchors.verticalCenter: parent.verticalCenter
                            }
                            StyledIcon {
                                visible: Toggles.gameMode
                                anchors.right: clock.left
                                anchors.rightMargin: 6
                                anchors.verticalCenter: parent.verticalCenter
                                width: 12
                                height: 12
                                iconName: "game-controller"
                                tint: Colors.accent
                            }
                            Rectangle {
                                visible: NotiServer.unread > 0
                                anchors.left: clock.right
                                anchors.leftMargin: 6
                                anchors.verticalCenter: parent.verticalCenter
                                width: 5
                                height: 5
                                radius: 2.5
                                color: Colors.accent
                            }
                        }

                        Row {
                            anchors.right: parent.right
                            anchors.rightMargin: root.pad + root.eqInset
                            anchors.verticalCenter: parent.verticalCenter
                            spacing: 6
                            opacity: root.mode === "full" && Island.page !== "main" && Island.page !== "launcher" ? 1 : 0
                            visible: opacity > 0

                            Behavior on opacity {
                                NumberAnimation {
                                    duration: 180
                                }
                            }

                            Repeater {
                                model: [
                                    {
                                        page: "main",
                                        icon: "caret-left"
                                    }
                                ]

                                delegate: Rectangle {
                                    id: pbtn
                                    required property var modelData
                                    readonly property bool on: Island.page === modelData.page
                                    width: 26
                                    height: 26
                                    radius: 13
                                    color: on ? Colors.accent : (pm.containsMouse ? Colors.pillCircle : Colors.pillCard2)

                                    Behavior on color {
                                        ColorAnimation {
                                            duration: 120
                                        }
                                    }

                                    StyledIcon {
                                        anchors.centerIn: parent
                                        width: 14
                                        height: 14
                                        iconName: pbtn.modelData.icon
                                        fill: pbtn.on
                                        tint: pbtn.on ? Colors.pillBg : Colors.pillFg
                                    }
                                    MouseArea {
                                        id: pm
                                        anchors.fill: parent
                                        hoverEnabled: true
                                        cursorShape: Qt.PointingHandCursor
                                        onClicked: Island.page = "main"
                                    }
                                }
                            }
                        }

                        /* live activity: album art while something plays (iOS compact music activity) */
                        ActChip {
                            id: artChip
                            x: timeBox.x + timeBox.width
                            anchors.verticalCenter: parent.verticalCenter
                            on: Config.cfg.island.activities && Media.playing && Media.title !== ""
                            natural: 18

                            ClippingRectangle {
                                anchors.verticalCenter: parent.verticalCenter
                                width: 18
                                height: 18
                                radius: 5
                                color: Colors.pillCircle

                                Image {
                                    anchors.fill: parent
                                    source: Media.artUrl
                                    fillMode: Image.PreserveAspectCrop
                                    asynchronous: true
                                    sourceSize: Qt.size(36, 36)
                                }
                                StyledIcon {
                                    anchors.centerIn: parent
                                    visible: Media.artUrl === ""
                                    width: 10
                                    height: 10
                                    iconName: "music-notes"
                                    tint: Colors.pillMuted
                                }
                            }
                        }

                        Eq {
                            id: eq
                            x: artChip.x + artChip.width + root.eqNudge
                            anchors.verticalCenter: parent.verticalCenter
                        }

                        /* live activities that trail the equalizer: timer, recording, Do Not Disturb */
                        Row {
                            id: acts
                            x: eq.x + eq.implicitWidth
                            anchors.verticalCenter: parent.verticalCenter
                            readonly property real totalW: timerChip.width + recChip.width + dndChip.width

                            ActChip {
                                id: timerChip
                                on: Config.cfg.island.activities && Toggles.timerLeft > 0
                                natural: timerRow.implicitWidth

                                Row {
                                    id: timerRow
                                    anchors.verticalCenter: parent.verticalCenter
                                    spacing: 4

                                    StyledIcon {
                                        anchors.verticalCenter: parent.verticalCenter
                                        width: 12
                                        height: 12
                                        iconName: "timer"
                                        tint: Toggles.timerLeft <= 10 ? Colors.urgent : "#FF9F0A"
                                    }
                                    StyledText {
                                        anchors.verticalCenter: parent.verticalCenter
                                        text: Toggles.timerText
                                        tabular: true
                                        wght: Typography.wEmph
                                        textSize: Config.cfg.appearance.fontSize - 2
                                        color: Toggles.timerLeft <= 10 ? Colors.urgent : "#FF9F0A"
                                    }
                                }
                            }

                            ActChip {
                                id: recChip
                                on: Config.cfg.island.activities && Toggles.recording
                                natural: 8

                                Rectangle {
                                    id: recDot
                                    anchors.verticalCenter: parent.verticalCenter
                                    width: 8
                                    height: 8
                                    radius: 4
                                    color: "#FF453A"

                                    SequentialAnimation on opacity {
                                        running: recChip.on
                                        loops: Animation.Infinite
                                        NumberAnimation { to: 0.35; duration: 700; easing.type: Easing.InOutSine }
                                        NumberAnimation { to: 1; duration: 700; easing.type: Easing.InOutSine }
                                    }
                                }
                            }

                            ActChip {
                                id: dndChip
                                on: Config.cfg.island.activities && NotiServer.dnd
                                natural: 12

                                StyledIcon {
                                    anchors.verticalCenter: parent.verticalCenter
                                    width: 12
                                    height: 12
                                    iconName: "moon"
                                    tint: "#7D7AFF"
                                }
                            }
                        }

                    }

                    RowLayout {
                        anchors.fill: parent
                        anchors.leftMargin: 16
                        anchors.rightMargin: 16
                        spacing: 10
                        opacity: root.mode === "osd" ? 1 : 0
                        visible: opacity > 0

                        Behavior on opacity {
                            NumberAnimation {
                                duration: 180
                            }
                        }

                        StyledIcon {
                            iconName: root.osdIcon
                            tint: Colors.accent
                        }
                        Rectangle {
                            Layout.fillWidth: true
                            implicitHeight: 8
                            radius: 4
                            color: Colors.pillTrack

                            Rectangle {
                                width: Math.max(parent.height, parent.width * root.osdValue)
                                height: parent.height
                                radius: 4
                                color: Colors.accent

                                Behavior on width {
                                    NumberAnimation {
                                        duration: 80
                                    }
                                }
                            }
                        }
                        StyledText {
                            Layout.preferredWidth: 34
                            horizontalAlignment: Text.AlignRight
                            text: Math.round(root.osdValue * 100) + "%"
                            color: Colors.pillFg
                            textSize: Config.cfg.appearance.fontSize - 1
                            font.features: {
                            "tnum": 1,
                            "calt": 1,
                            "kern": 1
                        }
                        }
                    }
                }

                Item {
                    id: popView
                    width: isl.width
                    height: root.popH
                    opacity: root.mode === "pop" ? 1 : 0
                    visible: opacity > 0

                    Behavior on opacity {
                        SequentialAnimation {
                            PauseAnimation { duration: root.mode === "pop" ? 140 : 0 }
                            NumberAnimation {
                                duration: root.mode === "pop" ? 260 : 140
                                easing.type: Easing.BezierSpline
                                easing.bezierCurve: Motion.fade
                            }
                        }
                    }

                    Item {
                        id: popBody
                        x: Math.round((parent.width - width) / 2)
                        width: root.popW
                        height: parent.height

                        ClippingRectangle {
                            id: popArt
                            x: 12
                            anchors.verticalCenter: parent.verticalCenter
                            width: 48
                            height: 48
                            radius: 12
                            color: Island.popKind === "event" ? Colors.alpha(Island.eventUrgent ? Colors.urgent : Colors.accent, 0.2) : (Island.popKind === "notif" ? Colors.alpha(Island.bannerUrgent ? Colors.urgent : Colors.accent, 0.16) : Colors.pillCircle)
                            scale: root.mode === "pop" ? 1 : 0.78

                            Behavior on scale {
                                NumberAnimation {
                                    duration: 480
                                    easing.type: Easing.BezierSpline
                                    easing.bezierCurve: Motion.smooth
                                }
                            }

                            Image {
                                id: popImg
                                anchors.fill: parent
                                anchors.margins: Island.popKind === "notif" ? 6 : 0
                                source: Island.popKind === "track" ? Media.artUrl : (Island.popKind === "notif" ? Island.bannerIcon : "")
                                fillMode: Island.popKind === "notif" ? Image.PreserveAspectFit : Image.PreserveAspectCrop
                                asynchronous: true
                                opacity: status === Image.Ready ? 1 : 0

                                Behavior on opacity {
                                    NumberAnimation {
                                        duration: 250
                                    }
                                }
                            }
                            StyledIcon {
                                anchors.centerIn: parent
                                width: 22
                                height: 22
                                visible: popImg.status !== Image.Ready
                                iconName: Island.popKind === "event" ? Island.eventIcon : (Island.popKind === "notif" ? "bell" : "music-notes")
                                tint: Island.popKind === "event" ? (Island.eventUrgent ? Colors.urgent : Colors.accent) : (Island.popKind === "notif" ? (Island.bannerUrgent ? Colors.urgent : Colors.accent) : Colors.pillMuted)
                            }
                        }

                        Column {
                            id: popText
                            x: popArt.x + popArt.width + 12 + (root.mode === "pop" ? 0 : 16)
                            width: popEq.x - popArt.x - popArt.width - 24
                            anchors.verticalCenter: parent.verticalCenter
                            spacing: 1
                            opacity: root.mode === "pop" ? 1 : 0

                            Behavior on x {
                                SequentialAnimation {
                                    PauseAnimation { duration: root.mode === "pop" ? 90 : 0 }
                                    NumberAnimation {
                                        duration: 480
                                        easing.type: Easing.BezierSpline
                                        easing.bezierCurve: Motion.smooth
                                    }
                                }
                            }
                            Behavior on opacity {
                                SequentialAnimation {
                                    PauseAnimation { duration: root.mode === "pop" ? 180 : 0 }
                                    NumberAnimation {
                                        duration: 280
                                        easing.type: Easing.BezierSpline
                                        easing.bezierCurve: Motion.fade
                                    }
                                }
                            }

                            StyledText {
                                width: parent.width
                                visible: Island.popKind === "notif" && Island.bannerApp !== ""
                                text: Island.bannerApp
                                wght: Typography.wEmph
                                textSize: Config.cfg.appearance.fontSize - 3
                                color: Island.bannerUrgent ? Colors.urgent : Colors.accent
                                elide: Text.ElideRight
                            }
                            StyledText {
                                width: parent.width
                                text: Island.popKind === "event" ? Island.eventTitle : (Island.popKind === "notif" ? Island.bannerTitle : Media.title)
                                wght: Typography.wEmph
                                textSize: Config.cfg.appearance.fontSize + 1
                                color: Colors.pillFg
                                elide: Text.ElideRight
                            }
                            StyledText {
                                width: parent.width
                                visible: text !== ""
                                text: Island.popKind === "event" ? Island.eventSub : (Island.popKind === "notif" ? Island.bannerBody : Media.artist)
                                color: Colors.pillSubtle
                                textSize: Config.cfg.appearance.fontSize - 1
                                elide: Text.ElideRight
                            }
                        }

                        Eq {
                            id: popEq
                            x: parent.width - width - 18
                            anchors.verticalCenter: parent.verticalCenter
                            visible: Island.popKind === "track"
                            scale: root.mode === "pop" ? 1 : 0.7
                            opacity: root.mode === "pop" ? 1 : 0

                            Behavior on scale {
                                SequentialAnimation {
                                    PauseAnimation { duration: root.mode === "pop" ? 200 : 0 }
                                    NumberAnimation {
                                        duration: 420
                                        easing.type: Easing.BezierSpline
                                        easing.bezierCurve: Motion.smooth
                                    }
                                }
                            }
                            Behavior on opacity {
                                SequentialAnimation {
                                    PauseAnimation { duration: root.mode === "pop" ? 220 : 0 }
                                    NumberAnimation {
                                        duration: 240
                                    }
                                }
                            }
                        }
                    }
                }

                /* banner gestures (iOS): tap opens the app, swipe up or right-click dismisses */
                MouseArea {
                    width: isl.width
                    height: root.popH
                    enabled: root.mode === "pop" && Island.popKind === "notif"
                    acceptedButtons: Qt.LeftButton | Qt.RightButton
                    cursorShape: Qt.PointingHandCursor
                    property real startY: 0
                    onPressed: mouse => startY = mouse.y
                    onReleased: mouse => {
                        if (mouse.button === Qt.RightButton || startY - mouse.y > 14)
                            Island.dismissBanner();
                        else if (Math.abs(mouse.y - startY) < 8)
                            Island.activateBanner();
                    }
                }

                IslandPanel {
                    id: panel
                    // the panel owns the whole island, so it sits at the very top and stays there while it fades out
                    readonly property bool takeIn: root.expanded && Island.page === "main"
                    y: takeIn || opacity > 0.01 ? 0 : root.hh
                    x: Math.round((parent.width - width) / 2)
                    shown: root.expanded
                    backdrop: wall
                    bx: Math.round((root.modelData.width - panel.width) / 2)
                    by: root.topGap
                    opacity: takeIn ? 1 : 0
                    visible: opacity > 0
                    transformOrigin: Item.Top
                    scale: takeIn ? 1 : 0.94

                    Behavior on y {
                        NumberAnimation {
                            duration: 440
                            easing.type: Easing.BezierSpline
                            easing.bezierCurve: Motion.smooth
                        }
                    }
                    Behavior on scale {
                        SequentialAnimation {
                            PauseAnimation { duration: panel.takeIn ? 40 : 0 }
                            NumberAnimation {
                                duration: panel.takeIn ? 480 : 150
                                easing.type: Easing.BezierSpline
                                easing.bezierCurve: panel.takeIn ? Motion.smooth : Motion.exit
                            }
                        }
                    }
                    Behavior on opacity {
                        SequentialAnimation {
                            PauseAnimation { duration: panel.takeIn ? 90 : 0 }
                            NumberAnimation {
                                duration: panel.takeIn ? 240 : 100
                                easing.type: Easing.BezierSpline
                                easing.bezierCurve: Motion.fade
                            }
                        }
                    }
                }

                Loader {
                    y: root.hh
                    x: Math.round((parent.width - width) / 2)
                    active: root.livePage === "themes"
                    opacity: root.wantPage === "themes" ? 1 : 0
                    transformOrigin: Item.Top
                    scale: root.wantPage === "themes" ? 1 : 0.94

                    Behavior on scale {
                        NumberAnimation {
                            duration: 380
                            easing.type: Easing.BezierSpline
                            easing.bezierCurve: Motion.smooth
                        }
                    }

                    Behavior on opacity {
                        SequentialAnimation {
                            PauseAnimation { duration: root.wantPage === "themes" ? 110 : 0 }
                            NumberAnimation {
                                duration: root.wantPage === "themes" ? 220 : 100
                                easing.type: Easing.BezierSpline
                                easing.bezierCurve: Motion.fade
                            }
                        }
                    }

                    sourceComponent: IslandThemes {
                        Component.onCompleted: focusSearch()
                    }
                }

                Loader {
                    y: root.hh
                    x: Math.round((parent.width - width) / 2)
                    active: root.livePage === "walls"
                    opacity: root.wantPage === "walls" ? 1 : 0
                    transformOrigin: Item.Top
                    scale: root.wantPage === "walls" ? 1 : 0.94

                    Behavior on scale {
                        NumberAnimation {
                            duration: 380
                            easing.type: Easing.BezierSpline
                            easing.bezierCurve: Motion.smooth
                        }
                    }

                    Behavior on opacity {
                        SequentialAnimation {
                            PauseAnimation { duration: root.wantPage === "walls" ? 110 : 0 }
                            NumberAnimation {
                                duration: root.wantPage === "walls" ? 220 : 100
                                easing.type: Easing.BezierSpline
                                easing.bezierCurve: Motion.fade
                            }
                        }
                    }

                    sourceComponent: IslandWalls {}
                }

                Loader {
                    y: root.hh
                    x: Math.round((parent.width - width) / 2)
                    active: root.livePage === "power"
                    opacity: root.wantPage === "power" ? 1 : 0
                    transformOrigin: Item.Top
                    scale: root.wantPage === "power" ? 1 : 0.94

                    Behavior on scale {
                        NumberAnimation {
                            duration: 380
                            easing.type: Easing.BezierSpline
                            easing.bezierCurve: Motion.smooth
                        }
                    }

                    Behavior on opacity {
                        SequentialAnimation {
                            PauseAnimation { duration: root.wantPage === "power" ? 110 : 0 }
                            NumberAnimation {
                                duration: root.wantPage === "power" ? 220 : 100
                                easing.type: Easing.BezierSpline
                                easing.bezierCurve: Motion.fade
                            }
                        }
                    }

                    sourceComponent: IslandPower {}
                }

                Loader {
                    id: clip
                    y: root.wantPage === "clipboard" || opacity > 0.01 ? 0 : root.hh
                    x: Math.round((parent.width - width) / 2)
                    active: root.livePage === "clipboard"
                    opacity: root.wantPage === "clipboard" ? 1 : 0
                    transformOrigin: Item.Top
                    scale: root.wantPage === "clipboard" ? 1 : 0.96

                    Behavior on y {
                        NumberAnimation {
                            duration: 440
                            easing.type: Easing.BezierSpline
                            easing.bezierCurve: Motion.smooth
                        }
                    }
                    Behavior on scale {
                        NumberAnimation {
                            duration: 420
                            easing.type: Easing.BezierSpline
                            easing.bezierCurve: Motion.smooth
                        }
                    }
                    Behavior on opacity {
                        SequentialAnimation {
                            PauseAnimation { duration: root.wantPage === "clipboard" ? 80 : 0 }
                            NumberAnimation {
                                duration: root.wantPage === "clipboard" ? 200 : 100
                                easing.type: Easing.BezierSpline
                                easing.bezierCurve: Motion.fade
                            }
                        }
                    }

                    sourceComponent: IslandClipboard {
                        Component.onCompleted: focusInput()
                    }
                }

                Loader {
                    id: launcher
                    y: root.wantPage === "launcher" || opacity > 0.01 ? 0 : root.hh
                    x: Math.round((parent.width - width) / 2)
                    active: root.livePage === "launcher"
                    opacity: root.wantPage === "launcher" ? 1 : 0
                    transformOrigin: Item.Top
                    scale: root.wantPage === "launcher" ? 1 : 0.96

                    Behavior on y {
                        NumberAnimation {
                            duration: 440
                            easing.type: Easing.BezierSpline
                            easing.bezierCurve: Motion.smooth
                        }
                    }
                    Behavior on scale {
                        NumberAnimation {
                            duration: 420
                            easing.type: Easing.BezierSpline
                            easing.bezierCurve: Motion.smooth
                        }
                    }
                    Behavior on opacity {
                        SequentialAnimation {
                            PauseAnimation { duration: root.wantPage === "launcher" ? 80 : 0 }
                            NumberAnimation {
                                duration: root.wantPage === "launcher" ? 200 : 100
                                easing.type: Easing.BezierSpline
                                easing.bezierCurve: Motion.fade
                            }
                        }
                    }

                    sourceComponent: IslandLauncher {
                        Component.onCompleted: focusInput()
                    }
                }
            }
        }
    }
}
