import qs
import qs.widgets
import QtQuick
import Quickshell
import qs.modules.Services

BarComponent {
    id: root
    required property ShellScreen barScreen
    implicitWidth: implicitHeight
    active: clickHandler.containsMouse
    StyledIcon {
        iconName: "palette"
        tint: root.active ? Colors.font : Colors.subtle
        anchors.centerIn: parent
    }
    MouseArea {
        id: clickHandler
        acceptedButtons: Qt.LeftButton
        cursorShape: Qt.PointingHandCursor
        hoverEnabled: true
        anchors.fill: parent
        onClicked: WidgetTracker.toggle("colors", root.barScreen)
    }
}
