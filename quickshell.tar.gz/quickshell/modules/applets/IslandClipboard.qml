pragma ComponentBehavior: Bound
import Quickshell
import QtQuick
import QtQuick.Layouts

import qs
import qs.settings
import qs.widgets
import qs.modules.Services

Item {
    id: root
    implicitWidth: 560
    implicitHeight: column.implicitHeight + 28

    readonly property int rowHeight: 56
    readonly property int rowSpacing: 2
    readonly property int rows: 6
    readonly property int smallFont: Config.cfg.appearance.fontSize - 2

    property bool pinnedOnly: false
    property int pick: 0
    property bool armedClear: false

    readonly property string query: input.text.trim().toLowerCase()
    readonly property var results: {
        const all = Clipboard.items.filter(i => (!pinnedOnly || i.pinned) && (query === "" || i.text.toLowerCase().includes(query)));
        return all.filter(i => i.pinned).concat(all.filter(i => !i.pinned));
    }
    readonly property int pinnedCount: Clipboard.items.filter(i => i.pinned).length
    readonly property var current: results[pick] ?? null

    function focusInput() {
        input.forceActiveFocus();
    }

    function move(delta) {
        if (results.length === 0)
            return;
        pick = (pick + delta + results.length) % results.length;
    }

    function preview(text) {
        const line = text.split("\n").find(l => l.trim() !== "") ?? "";
        return line.trim().replace(/\s+/g, " ").slice(0, 160);
    }

    function colorOf(text) {
        const t = text.trim();
        return /^#([0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i.test(t) ? t : "";
    }

    function iconOf(text) {
        if (/^https?:\/\/\S+$/.test(text.trim()))
            return "link";
        return text.includes("\n") ? "text-align-left" : "text-t";
    }

    function meta(entry, now) {
        const lines = entry.text.split("\n").length;
        const size = lines > 1 ? lines + " lines" : entry.text.length + (entry.text.length === 1 ? " character" : " characters");
        const s = Math.floor((now.getTime() - entry.time) / 1000);
        const age = s < 60 ? "just now" : s < 3600 ? Math.floor(s / 60) + "m ago" : s < 86400 ? Math.floor(s / 3600) + "h ago" : Math.floor(s / 86400) + "d ago";
        return size + " · " + age;
    }

    function choose(entry) {
        if (!entry)
            return;
        const shown = preview(entry.text).slice(0, 48);
        Island.dismiss();
        Clipboard.copy(entry);
        Island.showEvent("clipboard-text", "Copied", shown, false);
    }

    function clearAll() {
        if (!armedClear) {
            armedClear = true;
            clearTimer.restart();
            return;
        }
        armedClear = false;
        Clipboard.clear();
        pick = 0;
    }

    onPinnedOnlyChanged: pick = 0

    NumberAnimation on opacity {
        from: 0
        to: 1
        duration: 200
    }

    Component.onCompleted: Island.pinned = true
    Component.onDestruction: Island.pinned = false

    SystemClock {
        id: clock
        precision: SystemClock.Minutes
    }

    Timer {
        id: clearTimer
        interval: 3000
        onTriggered: root.armedClear = false
    }

    component Pill: Rectangle {
        id: pill
        property string icon
        property string label
        property bool active: false
        property bool danger: false
        signal clicked

        height: 36
        width: pillRow.implicitWidth + 22
        radius: height / 2
        color: active ? Colors.accent : (pillArea.containsMouse ? Colors.pillCircle : (danger ? Colors.alpha(Colors.urgent, 0.2) : Colors.pillCard2))

        Behavior on width {
            NumberAnimation {
                duration: 160
                easing.type: Easing.OutCubic
            }
        }
        Behavior on color {
            ColorAnimation {
                duration: 120
            }
        }

        RowLayout {
            id: pillRow
            anchors.centerIn: parent
            spacing: 6

            StyledIcon {
                Layout.preferredWidth: 16
                Layout.preferredHeight: 16
                width: 16
                height: 16
                iconName: pill.icon
                fill: false
                tint: pill.active ? Colors.pillBg : (pill.danger ? Colors.urgent : Colors.pillSubtle)
            }
            StyledText {
                visible: pill.label !== ""
                text: pill.label
                wght: Typography.wEmph
                textSize: root.smallFont
                color: pill.active ? Colors.pillBg : (pill.danger ? Colors.urgent : Colors.pillSubtle)
            }
        }

        MouseArea {
            id: pillArea
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: pill.clicked()
        }
    }

    component RoundButton: Rectangle {
        id: btn
        property string icon
        property bool on: false
        property bool danger: false
        signal clicked

        width: 30
        height: 30
        radius: 15
        color: area.containsMouse ? Colors.alpha(danger ? Colors.urgent : Colors.accent, 0.25) : Colors.pillCard2

        Behavior on color {
            ColorAnimation {
                duration: 100
            }
        }

        StyledIcon {
            anchors.centerIn: parent
            width: 15
            height: 15
            iconName: btn.icon
            fill: btn.on
            tint: btn.danger ? Colors.urgent : (btn.on ? Colors.accent : Colors.pillSubtle)
        }

        MouseArea {
            id: area
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: btn.clicked()
        }
    }

    ColumnLayout {
        id: column
        anchors.fill: parent
        anchors.margins: 14
        spacing: 10

        RowLayout {
            Layout.fillWidth: true
            Layout.preferredHeight: 36
            spacing: 10

            Rectangle {
                Layout.preferredWidth: 36
                Layout.preferredHeight: 36
                radius: 18
                color: Colors.accent

                StyledIcon {
                    anchors.centerIn: parent
                    width: 18
                    height: 18
                    iconName: "clipboard-text"
                    tint: Colors.pillBg
                }
            }

            Row {
                spacing: 4

                Pill {
                    icon: "clock-counter-clockwise"
                    label: "Recent"
                    active: !root.pinnedOnly
                    onClicked: root.pinnedOnly = false
                }
                Pill {
                    icon: "push-pin"
                    label: root.pinnedCount > 0 ? "Pinned · " + root.pinnedCount : "Pinned"
                    active: root.pinnedOnly
                    onClicked: root.pinnedOnly = true
                }
            }

            Item {
                Layout.fillWidth: true
            }

            Pill {
                visible: Clipboard.items.length > root.pinnedCount
                icon: "trash"
                label: root.armedClear ? "Sure?" : ""
                danger: true
                onClicked: root.clearAll()
            }
        }

        Rectangle {
            Layout.fillWidth: true
            implicitHeight: 48
            radius: height / 2
            color: Colors.pillCard2
            border.width: 1
            border.color: input.activeFocus ? Colors.alpha(Colors.accent, 0.7) : Colors.pillLine

            Behavior on border.color {
                ColorAnimation {
                    duration: 120
                }
            }

            RowLayout {
                anchors.fill: parent
                anchors.leftMargin: 18
                anchors.rightMargin: 18
                spacing: 12

                StyledIcon {
                    Layout.preferredWidth: 18
                    Layout.preferredHeight: 18
                    width: 18
                    height: 18
                    iconName: "magnifying-glass"
                    fill: false
                    tint: input.activeFocus ? Colors.accent : Colors.pillMuted
                }

                TextInput {
                    id: input
                    Layout.fillWidth: true
                    Layout.alignment: Qt.AlignVCenter
                    color: Colors.pillFg
                    selectionColor: Colors.accent
                    selectedTextColor: Colors.pillBg
                    font.family: Typography.family
                    font.pixelSize: Typography.fs(Config.cfg.appearance.fontSize + 1)
                    font.weight: Typography.weightEnum(Typography.wBody)
                    font.variableAxes: Typography.axes(Typography.fs(Config.cfg.appearance.fontSize + 1), Typography.wBody, 0)
                    clip: true
                    renderType: Text.NativeRendering

                    onTextChanged: root.pick = 0

                    StyledText {
                        anchors.verticalCenter: parent.verticalCenter
                        visible: input.text === "" && input.preeditText === ""
                        text: "Search clipboard history…"
                        color: Colors.pillMuted
                        textSize: Config.cfg.appearance.fontSize + 1
                    }

                    Keys.onPressed: event => {
                        const ctrl = (event.modifiers & Qt.ControlModifier) !== 0;
                        const k = event.key;
                        if (k === Qt.Key_Tab || k === Qt.Key_Backtab) {
                            root.pinnedOnly = !root.pinnedOnly;
                        } else if (k === Qt.Key_Down || (ctrl && (k === Qt.Key_N || k === Qt.Key_J))) {
                            root.move(1);
                        } else if (k === Qt.Key_Up || (ctrl && (k === Qt.Key_P || k === Qt.Key_K))) {
                            root.move(-1);
                        } else if (k === Qt.Key_PageDown) {
                            root.move(root.rows);
                        } else if (k === Qt.Key_PageUp) {
                            root.move(-root.rows);
                        } else if (k === Qt.Key_Return || k === Qt.Key_Enter) {
                            root.choose(root.current);
                        } else if (k === Qt.Key_Delete || (ctrl && k === Qt.Key_D)) {
                            if (root.current)
                                Clipboard.remove(root.current);
                        } else if (ctrl && k === Qt.Key_S) {
                            if (root.current)
                                Clipboard.togglePin(root.current);
                        } else if (k === Qt.Key_Escape) {
                            Island.dismiss();
                        } else {
                            return;
                        }
                        event.accepted = true;
                    }
                }
            }
        }

        Item {
            Layout.fillWidth: true
            Layout.preferredHeight: root.rows * root.rowHeight + (root.rows - 1) * root.rowSpacing

            ListView {
                id: list
                anchors.fill: parent
                clip: true
                spacing: root.rowSpacing
                model: root.results
                currentIndex: root.pick
                boundsBehavior: Flickable.StopAtBounds
                onCurrentIndexChanged: {
                    if (currentIndex >= 0)
                        positionViewAtIndex(currentIndex, ListView.Contain);
                }

                delegate: Rectangle {
                    id: row
                    required property var modelData
                    required property int index
                    readonly property bool current: index === root.pick
                    readonly property string swatch: root.colorOf(modelData.text)

                    width: list.width
                    height: root.rowHeight
                    radius: 20
                    color: current ? Colors.alpha(Colors.accent, 0.16) : "transparent"

                    Behavior on color {
                        ColorAnimation {
                            duration: 100
                        }
                    }

                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        hoverEnabled: true
                        onPositionChanged: root.pick = row.index
                        onClicked: root.choose(row.modelData)
                    }

                    RowLayout {
                        anchors.fill: parent
                        anchors.leftMargin: 9
                        anchors.rightMargin: 12
                        spacing: 12

                        Rectangle {
                            Layout.preferredWidth: 38
                            Layout.preferredHeight: 38
                            radius: 14
                            color: row.swatch !== "" ? row.swatch : (row.current ? Colors.alpha(Colors.accent, 0.18) : Colors.pillCard2)
                            border.width: row.swatch !== "" ? 1 : 0
                            border.color: Colors.alpha(Colors.pillFg, 0.2)

                            StyledIcon {
                                anchors.centerIn: parent
                                width: 20
                                height: 20
                                visible: row.swatch === ""
                                iconName: root.iconOf(row.modelData.text)
                                fill: false
                                tint: row.current ? Colors.accent : Colors.pillSubtle
                            }
                        }

                        ColumnLayout {
                            Layout.fillWidth: true
                            Layout.preferredWidth: 0
                            spacing: 0

                            RowLayout {
                                Layout.fillWidth: true
                                spacing: 6

                                StyledIcon {
                                    visible: row.modelData.pinned
                                    width: 12
                                    height: 12
                                    iconName: "push-pin"
                                    tint: Colors.accent
                                }
                                StyledText {
                                    Layout.fillWidth: true
                                    text: root.preview(row.modelData.text)
                                    color: row.current ? Colors.accent : Colors.pillFg
                                    wght: row.current ? Typography.wEmph : Typography.wBody
                                    elide: Text.ElideRight
                                }
                            }

                            StyledText {
                                Layout.fillWidth: true
                                text: root.meta(row.modelData, clock.date)
                                color: Colors.pillSubtle
                                textSize: root.smallFont
                                elide: Text.ElideRight
                            }
                        }

                        Row {
                            visible: row.current
                            spacing: 6

                            RoundButton {
                                icon: "push-pin"
                                on: row.modelData.pinned
                                onClicked: Clipboard.togglePin(row.modelData)
                            }
                            RoundButton {
                                icon: "trash"
                                danger: true
                                onClicked: Clipboard.remove(row.modelData)
                            }
                        }
                    }
                }
            }

            ColumnLayout {
                anchors.centerIn: parent
                visible: root.results.length === 0
                spacing: 8

                StyledIcon {
                    Layout.alignment: Qt.AlignHCenter
                    width: 28
                    height: 28
                    iconName: "clipboard-text"
                    fill: false
                    tint: Colors.pillMuted
                }
                StyledText {
                    Layout.alignment: Qt.AlignHCenter
                    text: Clipboard.items.length === 0 ? "Nothing copied yet" : root.pinnedOnly && root.query === "" ? "Nothing pinned" : "No matches"
                    wght: Typography.wEmph
                    color: Colors.pillFg
                }
                StyledText {
                    Layout.alignment: Qt.AlignHCenter
                    text: Clipboard.items.length === 0 ? "Copy some text and it will show up here" : root.pinnedOnly && root.query === "" ? "Pin an entry to keep it around" : "Try another word"
                    color: Colors.pillMuted
                    textSize: root.smallFont
                }
            }
        }

        StyledText {
            Layout.alignment: Qt.AlignHCenter
            text: "↵ copy   ⌃S pin   ⌃D delete   ⇥ switch"
            color: Colors.pillMuted
            textSize: root.smallFont - 1
        }
    }
}
