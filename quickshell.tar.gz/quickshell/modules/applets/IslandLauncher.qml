pragma ComponentBehavior: Bound
import Quickshell
import Quickshell.Widgets
import Quickshell.Wayland
import QtQuick
import QtQuick.Layouts

import qs
import qs.settings
import qs.widgets
import qs.modules.Services

/*
 * Launcher, restyled after Lucid (github.com/Sn3akyy1/lucid):
 *   head   : mark + mode pills + what the results add up to
 *   field  : one big pill, the mode's icon in front
 *   rows   : tonal icon tile, name + subtitle, running dot,
 *            and on the selected row a pill saying what Return will do
 *   extras : calculator card, system actions from 3 letters (the
 *            destructive ones ask for a second Return), open windows,
 *            web row, empty-state chips for the prefixes
 *
 * Modes   : Apps · Commands (>) · Web (?) · Run ($) · Themes · Wallpapers
 * Keys    : Tab / Shift+Tab cycles modes, Ctrl+1..6 picks one, Up/Down
 *           (or Ctrl+N/P/J/K) moves, Return runs, Shift+Return runs in a
 *           terminal (Run mode), Backspace on an empty field goes back to Apps.
 */
Item {
    id: root
    implicitWidth: 560
    implicitHeight: column.implicitHeight + 28

    /* ---- easy knobs ---- */
    readonly property string searchUrl: "https://duckduckgo.com/?q="
    readonly property string searchName: "DuckDuckGo"

    readonly property int rowHeight: 52
    readonly property int rowSpacing: 2
    readonly property int maxRows: Config.cfg.launcher.maxRows
    readonly property int smallFont: Config.cfg.appearance.fontSize - 2

    readonly property var modes: [
        {
            id: "apps",
            label: "Apps",
            icon: "squares-four",
            placeholder: "Search apps, windows, or calculate…"
        },
        {
            id: "cmd",
            label: "Commands",
            icon: "command",
            prefix: ">",
            placeholder: "Filter commands…"
        },
        {
            id: "web",
            label: "Web",
            icon: "globe",
            prefix: "?",
            placeholder: "Search the web or enter an address…"
        },
        {
            id: "run",
            label: "Run",
            icon: "terminal-window",
            prefix: "$",
            placeholder: "Type a command line…"
        },
        {
            id: "themes",
            label: "Themes",
            icon: "palette",
            page: "themes"
        },
        {
            id: "walls",
            label: "Wallpapers",
            icon: "image",
            page: "walls"
        },
        {
            id: "clipboard",
            label: "Clipboard",
            icon: "clipboard-text",
            page: "clipboard"
        }
    ]
    readonly property var prefixes: ({
            ">": "cmd",
            "?": "web",
            "$": "run"
        })

    /* Edit the commands here. `system` ones also show up in Apps mode once you
     * have typed three letters of their name. Logout is Hyprland-specific. */
    readonly property var commands: [
        {
            title: "Lock",
            sub: "Lock the screen",
            icon: "lock",
            fn: "lock",
            system: true
        },
        {
            title: "Sleep",
            sub: "Suspend the machine",
            icon: "moon",
            cmd: ["loginctl", "suspend"],
            system: true
        },
        {
            title: "Log out",
            sub: "End this session",
            icon: "sign-out",
            cmd: ["hyprctl", "dispatch", "exit"],
            system: true,
            danger: true
        },
        {
            title: "Restart",
            sub: "Reboot the machine",
            icon: "arrow-clockwise",
            cmd: ["loginctl", "reboot"],
            system: true,
            danger: true
        },
        {
            title: "Shut down",
            sub: "Power off",
            icon: "power",
            cmd: ["loginctl", "poweroff"],
            system: true,
            danger: true
        },
        {
            title: "Themes",
            sub: "Switch the colour scheme",
            icon: "palette",
            page: "themes"
        },
        {
            title: "Wallpapers",
            sub: "Pick a wallpaper",
            icon: "image",
            page: "walls"
        },
        {
            title: "Clipboard history",
            sub: "Recently copied text",
            icon: "clipboard-text",
            page: "clipboard"
        },
        {
            title: "Power menu",
            sub: "Lock, sleep, restart, shut down",
            icon: "power",
            page: "power"
        }
    ]

    /* ---- state ---- */
    property string mode: "apps"
    property int pick: 0
    property string armedKey: ""

    readonly property var modeInfo: modes.find(m => m.id === mode) ?? modes[0]
    readonly property string query: input.text.trim()
    readonly property var calcResult: mode === "apps" ? calcOf(query) : null
    readonly property bool hasCalc: calcResult !== null
    readonly property var runningApps: {
        const o = {};
        const t = ToplevelManager.toplevels.values;
        for (let i = 0; i < t.length; i++) {
            const a = (t[i].appId || "").toLowerCase();
            if (a !== "")
                o[a] = true;
        }
        return o;
    }
    readonly property var results: mode === "apps" ? buildApps(query) : mode === "cmd" ? buildCmds(query) : mode === "web" ? buildWeb(query) : buildRun(input.text)
    readonly property int total: results.length + (hasCalc ? 1 : 0)
    readonly property int selIndex: hasCalc ? pick - 1 : pick
    readonly property int rows: Config.cfg.launcher.fixedHeight ? maxRows : (results.length === 0 ? 2 : Math.min(results.length, maxRows))
    readonly property string countText: {
        if (total === 0)
            return "";
        if (mode === "apps" && query === "")
            return total + " apps";
        return total + (total === 1 ? " result" : " results");
    }
    readonly property string emptyTitle: mode === "cmd" ? "No matching commands" : mode === "web" ? "Search the web" : mode === "run" ? "Run a command" : "Nothing found"
    readonly property string emptySub: mode === "web" ? "Type a query, or enter an address" : mode === "run" ? "Return runs it in the background, Shift+Return in a terminal" : "Try another word, or jump to a mode"

    onModeChanged: {
        pick = 0;
        armedKey = "";
    }

    NumberAnimation on opacity {
        from: 0
        to: 1
        duration: 200
    }

    Component.onCompleted: Island.pinned = true
    Component.onDestruction: Island.pinned = false

    Timer {
        id: armTimer
        interval: 4000
        onTriggered: root.armedKey = ""
    }

    /* ---- helpers ---- */
    function focusInput() {
        input.forceActiveFocus();
    }

    function pickOf(listIndex) {
        return hasCalc ? listIndex + 1 : listIndex;
    }

    function move(delta) {
        if (total === 0)
            return;
        armedKey = "";
        pick = (pick + delta + total) % total;
    }

    function chooseMode(m) {
        if (m.page) {
            Island.showPage(m.page, Island.screen);
            return;
        }
        mode = m.id;
        input.forceActiveFocus();
    }

    function cycleMode(dir) {
        const real = modes.filter(m => !m.page);
        let i = real.findIndex(m => m.id === mode);
        i = (i + dir + real.length) % real.length;
        mode = real[i].id;
    }

    function isRunning(entry) {
        const id = (entry.id || "").toLowerCase();
        const sc = (entry.startupClass || "").toLowerCase();
        return runningApps[id] === true || (sc !== "" && runningApps[sc] === true);
    }

    function fmtNum(v) {
        return String(parseFloat(v.toPrecision(12)));
    }

    /* "2^3^2", "3,5*2", "(1+2)*4" … only digits and operators ever reach eval. */
    function calcOf(q) {
        const s = q.replace(/\s+/g, "");
        if (s.length < 3 || !/^[0-9+\-*\/().^%x×÷,]+$/.test(s))
            return null;
        if (!/[0-9]/.test(s) || !/[+\-*\/^%x×÷]/.test(s.replace(/^[-+]/, "")))
            return null;
        const e = s.replace(/[x×]/g, "*").replace(/÷/g, "/").replace(/\^/g, "**").replace(/,/g, ".");
        let v;
        try {
            v = eval("(" + e + ")");
        } catch (err) {
            return null;
        }
        if (typeof v !== "number" || !isFinite(v))
            return null;
        return {
            expr: q.trim(),
            value: fmtNum(v)
        };
    }

    function addressLike(q) {
        return /^https?:\/\/\S+$/.test(q) || /^[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}(\/\S*)?$/.test(q);
    }

    function cmdItem(c) {
        return {
            kind: "cmd",
            title: c.title,
            sub: c.sub,
            iconName: c.icon,
            c: c,
            danger: c.danger === true
        };
    }

    function webItem(q) {
        const addr = addressLike(q);
        return {
            kind: "web",
            title: addr ? q : "Search " + searchName + " for “" + q + "”",
            sub: addr ? "Open this address" : "Opens in your browser",
            iconName: "globe",
            address: addr,
            url: addr ? (/^https?:\/\//.test(q) ? q : "https://" + q) : searchUrl + encodeURIComponent(q)
        };
    }

    function buildApps(q) {
        const out = [];
        const lq = q.toLowerCase();
        if (lq.length >= 3) {
            for (let i = 0; i < commands.length; i++) {
                const c = commands[i];
                if (c.system && c.title.toLowerCase().startsWith(lq))
                    out.push(cmdItem(c));
            }
        }
        const apps = Apps.search(q);
        for (let i = 0; i < apps.length; i++) {
            const e = apps[i];
            out.push({
                kind: "app",
                title: e.name,
                sub: e.genericName || e.comment || "",
                icon: e.icon,
                entry: e,
                running: isRunning(e)
            });
        }
        if (q !== "") {
            const t = ToplevelManager.toplevels.values;
            let n = 0;
            for (let i = 0; i < t.length && n < 3; i++) {
                const w = t[i];
                const appId = w.appId || "";
                if (!(w.title || "").toLowerCase().includes(lq) && !appId.toLowerCase().includes(lq))
                    continue;
                const de = appId !== "" ? DesktopEntries.heuristicLookup(appId) : null;
                out.push({
                    kind: "window",
                    title: w.title || appId,
                    sub: "Window · " + appId,
                    icon: de ? de.icon : appId.toLowerCase(),
                    toplevel: w
                });
                n++;
            }
            out.push(webItem(q));
        }
        return out;
    }

    function buildCmds(q) {
        const lq = q.toLowerCase();
        const out = [];
        for (let i = 0; i < commands.length; i++) {
            const c = commands[i];
            if (lq === "" || c.title.toLowerCase().includes(lq) || c.sub.toLowerCase().includes(lq))
                out.push(cmdItem(c));
        }
        return out;
    }

    function buildWeb(q) {
        return q === "" ? [] : [webItem(q)];
    }

    function buildRun(text) {
        const t = text.trim();
        return t === "" ? [] : [
            {
                kind: "run",
                title: t,
                sub: "Runs in the background · Shift+Return opens a terminal",
                iconName: "terminal-window",
                text: t
            }
        ];
    }

    function hintFor(it, armed) {
        switch (it.kind) {
        case "app":
            return "Open";
        case "window":
            return "Switch";
        case "cmd":
            return armed ? "Confirm" : (it.c.page ? "Open" : "Run");
        case "web":
            return it.address ? "Open" : "Search";
        case "run":
            return "Run";
        }
        return "Open";
    }

    function copyCalc() {
        Quickshell.execDetached(["wl-copy", calcResult.value]);
        Island.dismiss();
    }

    function runLine(text, inTerminal) {
        if (inTerminal) {
            const term = Config.cfg.launcher.terminal !== "" ? Config.cfg.launcher.terminal : (Quickshell.env("TERMINAL") || "foot");
            Quickshell.execDetached([term, "-e", "sh", "-c", text + "; echo; echo '[done, press Enter]'; read _"]);
        } else {
            Quickshell.execDetached(["sh", "-c", text]);
        }
    }

    function activateItem(shift) {
        if (hasCalc && pick === 0) {
            copyCalc();
            return;
        }
        const it = results[selIndex];
        if (!it)
            return;
        if (it.danger && armedKey !== it.title) {
            armedKey = it.title;
            armTimer.restart();
            return;
        }
        switch (it.kind) {
        case "app":
            Island.dismiss();
            Apps.launch(it.entry);
            break;
        case "window":
            Island.dismiss();
            it.toplevel.activate();
            break;
        case "cmd":
            if (it.c.page) {
                Island.showPage(it.c.page, Island.screen);
            } else if (it.c.fn === "lock") {
                Island.dismiss();
                Toggles.lock();
            } else {
                Island.dismiss();
                Quickshell.execDetached(it.c.cmd);
            }
            break;
        case "web":
            Island.dismiss();
            Quickshell.execDetached(["xdg-open", it.url]);
            break;
        case "run":
            Island.dismiss();
            runLine(it.text, shift);
            break;
        }
    }

    /* ---- small building blocks ---- */
    component ModePill: Rectangle {
        id: pill
        required property var modelData
        required property int index
        readonly property bool active: modelData.page === undefined && root.mode === modelData.id

        height: 36
        width: content.implicitWidth + 22
        radius: height / 2
        color: active ? Colors.accent : (area.containsMouse ? Colors.pillCircle : Colors.pillCard2)

        Behavior on width {
            NumberAnimation {
                duration: 160
                easing.type: Easing.OutCubic
            }
        }
        Behavior on color {
            ColorAnimation {
                duration: 120
            }
        }

        RowLayout {
            id: content
            anchors.centerIn: parent
            spacing: 6

            StyledIcon {
                Layout.preferredWidth: 16
                Layout.preferredHeight: 16
                width: 16
                height: 16
                iconName: pill.modelData.icon
                fill: false
                tint: pill.active ? Colors.pillBg : (area.containsMouse ? Colors.pillFg : Colors.pillSubtle)
            }
            StyledText {
                visible: pill.active
                text: pill.modelData.label
                wght: Typography.wEmph
                textSize: root.smallFont
                color: Colors.pillBg
            }
        }

        MouseArea {
            id: area
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: root.chooseMode(pill.modelData)
        }
    }

    component HintPill: Rectangle {
        id: hint
        property string text
        property bool danger: false
        readonly property color tone: danger ? Colors.urgent : Colors.accent

        implicitHeight: 26
        implicitWidth: hintRow.implicitWidth + 20
        radius: height / 2
        color: Colors.alpha(tone, 0.2)

        RowLayout {
            id: hintRow
            anchors.centerIn: parent
            spacing: 5

            StyledIcon {
                Layout.preferredWidth: 12
                Layout.preferredHeight: 12
                width: 12
                height: 12
                iconName: "arrow-elbow-down-left"
                fill: false
                tint: hint.tone
            }
            StyledText {
                text: hint.text
                wght: Typography.wEmph
                textSize: root.smallFont
                color: hint.tone
            }
        }
    }

    /* ---- layout ---- */
    ColumnLayout {
        id: column
        anchors.fill: parent
        anchors.margins: 14
        spacing: 10

        /* head: mark, modes, count */
        RowLayout {
            Layout.fillWidth: true
            Layout.preferredHeight: 36
            spacing: 10

            Rectangle {
                Layout.preferredWidth: 36
                Layout.preferredHeight: 36
                radius: 18
                color: Colors.accent

                StyledIcon {
                    anchors.centerIn: parent
                    width: 18
                    height: 18
                    iconName: "sparkle"
                    tint: Colors.pillBg
                }
            }

            Row {
                spacing: 4

                Repeater {
                    model: root.modes
                    delegate: ModePill {}
                }
            }

            Item {
                Layout.fillWidth: true
            }

            StyledText {
                text: root.countText
                color: Colors.pillMuted
                textSize: root.smallFont
                font.features: {
                    "tnum": 1
                }
            }
        }

        /* search field */
        Rectangle {
            Layout.fillWidth: true
            implicitHeight: 48
            radius: height / 2
            color: Colors.pillCard2
            border.width: 1
            border.color: input.activeFocus ? Colors.alpha(Colors.accent, 0.7) : Colors.pillLine

            Behavior on border.color {
                ColorAnimation {
                    duration: 120
                }
            }

            RowLayout {
                anchors.fill: parent
                anchors.leftMargin: 18
                anchors.rightMargin: 18
                spacing: 12

                StyledIcon {
                    Layout.preferredWidth: 18
                    Layout.preferredHeight: 18
                    width: 18
                    height: 18
                    iconName: root.mode === "apps" ? "magnifying-glass" : root.modeInfo.icon
                    fill: false
                    tint: input.activeFocus ? Colors.accent : Colors.pillMuted
                }

                TextInput {
                    id: input
                    Layout.fillWidth: true
                    Layout.alignment: Qt.AlignVCenter
                    color: Colors.pillFg
                    selectionColor: Colors.accent
                    selectedTextColor: Colors.pillBg
                    font.family: Typography.family
                    font.pixelSize: Typography.fs(Config.cfg.appearance.fontSize + 1)
                    font.weight: Typography.weightEnum(Typography.wBody)
                    font.variableAxes: Typography.axes(Typography.fs(Config.cfg.appearance.fontSize + 1), Typography.wBody, 0)
                    clip: true
                    renderType: Text.NativeRendering

                    onTextChanged: {
                        root.pick = 0;
                        root.armedKey = "";
                        if (root.mode === "apps" && text.length > 0) {
                            const m = root.prefixes[text.charAt(0)];
                            if (m !== undefined) {
                                root.mode = m;
                                text = text.slice(1);
                            }
                        }
                    }

                    StyledText {
                        anchors.verticalCenter: parent.verticalCenter
                        visible: input.text === "" && input.preeditText === ""
                        text: root.modeInfo.placeholder ?? ""
                        color: Colors.pillMuted
                        textSize: Config.cfg.appearance.fontSize + 1
                    }

                    Keys.onPressed: event => {
                        const ctrl = (event.modifiers & Qt.ControlModifier) !== 0;
                        const shift = (event.modifiers & Qt.ShiftModifier) !== 0;
                        const k = event.key;
                        if (ctrl && k >= Qt.Key_1 && k <= Qt.Key_9) {
                            const m = root.modes[k - Qt.Key_1];
                            if (m)
                                root.chooseMode(m);
                            event.accepted = true;
                        } else if (k === Qt.Key_Tab) {
                            root.cycleMode(1);
                            event.accepted = true;
                        } else if (k === Qt.Key_Backtab) {
                            root.cycleMode(-1);
                            event.accepted = true;
                        } else if (k === Qt.Key_Down || (ctrl && (k === Qt.Key_N || k === Qt.Key_J))) {
                            root.move(1);
                            event.accepted = true;
                        } else if (k === Qt.Key_Up || (ctrl && (k === Qt.Key_P || k === Qt.Key_K))) {
                            root.move(-1);
                            event.accepted = true;
                        } else if (k === Qt.Key_PageDown) {
                            root.move(root.rows);
                            event.accepted = true;
                        } else if (k === Qt.Key_PageUp) {
                            root.move(-root.rows);
                            event.accepted = true;
                        } else if (k === Qt.Key_Return || k === Qt.Key_Enter) {
                            root.activateItem(shift);
                            event.accepted = true;
                        } else if (k === Qt.Key_Backspace && input.text === "" && root.mode !== "apps") {
                            root.mode = "apps";
                            event.accepted = true;
                        } else if (k === Qt.Key_Escape) {
                            Island.dismiss();
                            event.accepted = true;
                        }
                    }
                }
            }
        }

        /* calculator card: Return copies the answer */
        Rectangle {
            id: calcCard
            visible: root.hasCalc
            Layout.fillWidth: true
            implicitHeight: 84
            radius: 26
            color: Colors.alpha(Colors.accent, root.pick === 0 ? 0.2 : 0.12)
            border.width: root.pick === 0 ? 1 : 0
            border.color: Colors.alpha(Colors.accent, 0.6)

            Behavior on color {
                ColorAnimation {
                    duration: 100
                }
            }

            RowLayout {
                anchors.fill: parent
                anchors.leftMargin: 20
                anchors.rightMargin: 16
                spacing: 12

                ColumnLayout {
                    Layout.fillWidth: true
                    Layout.preferredWidth: 0
                    spacing: 0

                    StyledText {
                        Layout.fillWidth: true
                        text: root.calcResult ? root.calcResult.expr + " =" : ""
                        color: Colors.pillSubtle
                        textSize: root.smallFont
                        elide: Text.ElideRight
                    }
                    StyledText {
                        Layout.fillWidth: true
                        text: root.calcResult ? root.calcResult.value : ""
                        color: Colors.accent
                        wght: Typography.wEmph
                        textSize: 32
                        elide: Text.ElideRight
                        font.features: {
                            "tnum": 1
                        }
                    }
                }

                HintPill {
                    visible: root.pick === 0
                    text: "Copy"
                }
            }

            MouseArea {
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onPositionChanged: root.pick = 0
                onClicked: root.copyCalc()
            }
        }

        /* results */
        Item {
            Layout.fillWidth: true
            Layout.preferredHeight: root.rows * root.rowHeight + (root.rows - 1) * root.rowSpacing

            ListView {
                id: list
                anchors.fill: parent
                clip: true
                spacing: root.rowSpacing
                model: root.results
                currentIndex: root.selIndex
                boundsBehavior: Flickable.StopAtBounds
                onCurrentIndexChanged: {
                    if (currentIndex >= 0)
                        positionViewAtIndex(currentIndex, ListView.Contain);
                }

                delegate: Rectangle {
                    id: row
                    required property var modelData
                    required property int index
                    readonly property bool current: root.pickOf(index) === root.pick
                    readonly property bool armed: modelData.danger === true && root.armedKey === modelData.title
                    readonly property bool isImage: modelData.kind === "app" || modelData.kind === "window"

                    width: list.width
                    height: root.rowHeight
                    radius: 20
                    color: current ? Colors.alpha(armed ? Colors.urgent : Colors.accent, 0.16) : "transparent"

                    Behavior on color {
                        ColorAnimation {
                            duration: 100
                        }
                    }

                    RowLayout {
                        anchors.fill: parent
                        anchors.leftMargin: 8
                        anchors.rightMargin: 12
                        spacing: 12

                        Rectangle {
                            Layout.preferredWidth: 38
                            Layout.preferredHeight: 38
                            radius: 14
                            color: row.isImage ? "transparent" : (row.current ? Colors.alpha(Colors.accent, 0.18) : Colors.pillCard2)

                            IconImage {
                                anchors.centerIn: parent
                                implicitSize: 32
                                visible: row.isImage
                                source: row.isImage ? Quickshell.iconPath(row.modelData.icon, "application-x-executable") : ""
                            }
                            StyledIcon {
                                anchors.centerIn: parent
                                width: 20
                                height: 20
                                visible: !row.isImage
                                iconName: row.isImage ? "squares-four" : row.modelData.iconName
                                fill: false
                                tint: row.armed ? Colors.urgent : (row.current ? Colors.accent : Colors.pillSubtle)
                            }
                        }

                        ColumnLayout {
                            id: textCol
                            Layout.fillWidth: true
                            Layout.preferredWidth: 0
                            spacing: 0

                            RowLayout {
                                Layout.fillWidth: true
                                spacing: 7

                                StyledText {
                                    text: row.modelData.title
                                    color: row.armed ? Colors.urgent : (row.current ? Colors.accent : Colors.pillFg)
                                    wght: row.current ? Typography.wEmph : Typography.wBody
                                    elide: Text.ElideRight
                                }
                                Rectangle {
                                    visible: row.modelData.running === true
                                    Layout.preferredWidth: 6
                                    Layout.preferredHeight: 6
                                    radius: 3
                                    color: Colors.accent
                                }
                                Item {
                                    Layout.fillWidth: true
                                }
                            }

                            StyledText {
                                Layout.fillWidth: true
                                visible: text !== ""
                                text: row.armed ? "Press Return again to confirm" : (row.modelData.sub ?? "")
                                color: row.armed ? Colors.urgent : Colors.pillSubtle
                                textSize: root.smallFont
                                elide: Text.ElideRight
                            }
                        }

                        HintPill {
                            visible: row.current
                            text: root.hintFor(row.modelData, row.armed)
                            danger: row.armed
                        }
                    }

                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        acceptedButtons: Qt.LeftButton
                        hoverEnabled: true
                        onPositionChanged: root.pick = root.pickOf(row.index)
                        onClicked: {
                            root.pick = root.pickOf(row.index);
                            root.activateItem(false);
                        }
                    }
                }
            }

            /* empty state: say so, and offer the prefixes as chips */
            ColumnLayout {
                anchors.centerIn: parent
                visible: root.results.length === 0 && !root.hasCalc
                spacing: 8

                StyledText {
                    Layout.alignment: Qt.AlignHCenter
                    text: root.emptyTitle
                    wght: Typography.wEmph
                    color: Colors.pillFg
                }
                StyledText {
                    Layout.alignment: Qt.AlignHCenter
                    text: root.emptySub
                    color: Colors.pillMuted
                    textSize: root.smallFont
                }
                Row {
                    Layout.alignment: Qt.AlignHCenter
                    Layout.topMargin: 4
                    spacing: 8

                    Repeater {
                        model: root.modes.filter(m => m.prefix !== undefined && m.id !== root.mode)
                        delegate: Rectangle {
                            id: chip
                            required property var modelData
                            height: 30
                            width: chipRow.implicitWidth + 24
                            radius: height / 2
                            color: chipArea.containsMouse ? Colors.pillCircle : Colors.pillCard2

                            RowLayout {
                                id: chipRow
                                anchors.centerIn: parent
                                spacing: 7

                                StyledText {
                                    text: chip.modelData.prefix
                                    color: Colors.accent
                                    wght: Typography.wEmph
                                    textSize: root.smallFont
                                }
                                StyledText {
                                    text: chip.modelData.label
                                    color: Colors.pillSubtle
                                    textSize: root.smallFont
                                }
                            }
                            MouseArea {
                                id: chipArea
                                anchors.fill: parent
                                hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor
                                onClicked: root.chooseMode(chip.modelData)
                            }
                        }
                    }
                }
            }
        }
    }
}
