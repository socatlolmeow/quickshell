pragma ComponentBehavior: Bound
import Quickshell.Widgets
import QtQuick
import QtQuick.Layouts

import qs
import qs.settings
import qs.widgets
import qs.modules.Services

Item {
    id: root
    implicitWidth: 516
    implicitHeight: 215
    property bool creating: false

    NumberAnimation on opacity {
        from: 0
        to: 1
        duration: 200
    }

    onCreatingChanged: {
        Island.pinned = creating;
        if (creating) {
            nameInput.text = "";
            nameInput.forceActiveFocus();
        } else {
            nameInput.focus = false;
        }
    }
    Component.onDestruction: Island.pinned = false

    WallFolders {
        id: folders
    }

    Connections {
        target: folders
        function onDirChanged() {
            strip.contentX = 0;
        }
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 15
        spacing: 10

        RowLayout {
            Layout.fillWidth: true
            Layout.preferredHeight: 30
            spacing: 8

            Rectangle {
                visible: !folders.atRoot
                Layout.preferredWidth: 30
                Layout.preferredHeight: 30
                radius: 15
                color: backArea.containsMouse ? Colors.pillCircle : Colors.pillCard2

                StyledIcon {
                    anchors.centerIn: parent
                    width: 16
                    height: 16
                    iconName: "arrow-left"
                    fill: false
                    tint: Colors.pillFg
                }
                MouseArea {
                    id: backArea
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: folders.up()
                }
            }

            StyledText {
                visible: !root.creating
                Layout.fillWidth: true
                Layout.leftMargin: folders.atRoot ? 4 : 0
                text: folders.title
                color: Colors.pillFg
                wght: Typography.wEmph
                textSize: Config.cfg.appearance.fontSize + 2
                elide: Text.ElideRight
            }

            Rectangle {
                visible: root.creating
                Layout.fillWidth: true
                Layout.preferredHeight: 30
                radius: 15
                color: Colors.pillCard
                border.width: 1
                border.color: Colors.alpha(Colors.accent, 0.7)

                TextInput {
                    id: nameInput
                    anchors.fill: parent
                    anchors.leftMargin: 14
                    anchors.rightMargin: 14
                    verticalAlignment: TextInput.AlignVCenter
                    clip: true
                    color: Colors.pillFg
                    selectionColor: Colors.accent
                    selectedTextColor: Colors.pillBg
                    font.family: Typography.family
                    font.pixelSize: Typography.fs(Config.cfg.appearance.fontSize)
                    onAccepted: {
                        folders.createFolder(text);
                        root.creating = false;
                    }
                    Keys.onEscapePressed: root.creating = false
                }
                StyledText {
                    visible: nameInput.text === ""
                    anchors.left: parent.left
                    anchors.leftMargin: 14
                    anchors.verticalCenter: parent.verticalCenter
                    text: "Folder name…"
                    color: Colors.pillMuted
                }
            }

            Rectangle {
                Layout.preferredWidth: 30
                Layout.preferredHeight: 30
                radius: 15
                color: root.creating ? Colors.accent : (addArea.containsMouse ? Colors.pillCircle : Colors.pillCard2)

                StyledIcon {
                    anchors.centerIn: parent
                    width: 16
                    height: 16
                    iconName: "folder-plus"
                    fill: false
                    tint: root.creating ? Colors.pillBg : Colors.pillFg
                }
                MouseArea {
                    id: addArea
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: root.creating = !root.creating
                }
            }
        }

        ListView {
            id: strip
            Layout.fillWidth: true
            Layout.fillHeight: true
            orientation: ListView.Horizontal
            spacing: 10
            clip: true
            boundsBehavior: Flickable.StopAtBounds
            model: folders.model

            WheelHandler {
                onWheel: event => {
                    const max = Math.max(0, strip.contentWidth - strip.width);
                    strip.contentX = Math.max(0, Math.min(max, strip.contentX - event.angleDelta.y));
                }
            }

            StyledText {
                visible: strip.count === 0
                anchors.centerIn: parent
                text: "Empty folder"
                color: Colors.pillMuted
            }

            delegate: ClippingRectangle {
                id: tile
                required property var modelData
                readonly property bool isDir: modelData.fileIsDir
                readonly property bool current: !isDir && modelData.filePath === Config.cfg.wallpaper.wallpaper

                width: isDir ? 140 : 200
                height: strip.height
                radius: 18
                color: isDir ? (tileMouse.containsMouse ? Colors.pillCircle : Colors.pillCard2) : Colors.pillCard
                border.width: current ? 2 : 0
                border.color: Colors.accent

                Image {
                    visible: !tile.isDir
                    anchors.fill: parent
                    source: tile.isDir ? "" : tile.modelData.filePath
                    sourceSize.width: 400
                    sourceSize.height: 280
                    fillMode: Image.PreserveAspectCrop
                    asynchronous: true
                    opacity: tileMouse.containsMouse || tile.current ? 1.0 : 0.72
                    scale: tileMouse.containsMouse ? 1.04 : 1.0

                    Behavior on opacity {
                        NumberAnimation {
                            duration: 150
                        }
                    }
                    Behavior on scale {
                        NumberAnimation {
                            duration: 180
                            easing.type: Easing.OutCubic
                        }
                    }
                }

                ColumnLayout {
                    visible: tile.isDir
                    anchors.centerIn: parent
                    width: parent.width - 20
                    spacing: 6

                    StyledIcon {
                        Layout.alignment: Qt.AlignHCenter
                        width: 40
                        height: 40
                        iconName: "folder"
                        tint: Colors.accent
                    }
                    StyledText {
                        Layout.fillWidth: true
                        text: tile.modelData.fileName
                        color: Colors.pillFg
                        horizontalAlignment: Text.AlignHCenter
                        elide: Text.ElideRight
                    }
                }

                Rectangle {
                    visible: tile.current
                    anchors.top: parent.top
                    anchors.right: parent.right
                    anchors.margins: 8
                    width: 22
                    height: 22
                    radius: 11
                    color: Colors.accent

                    StyledIcon {
                        anchors.centerIn: parent
                        width: 14
                        height: 14
                        iconName: "check"
                        fill: false
                        tint: Colors.pillBg
                    }
                }

                MouseArea {
                    id: tileMouse
                    anchors.fill: parent
                    cursorShape: Qt.PointingHandCursor
                    acceptedButtons: Qt.LeftButton
                    hoverEnabled: true
                    onClicked: {
                        if (tile.isDir) {
                            folders.dir = tile.modelData.filePath;
                        } else {
                            Config.cfg.wallpaper.wallpaper = tile.modelData.filePath;
                            Config.save();
                        }
                    }
                }
            }
        }
    }
}
