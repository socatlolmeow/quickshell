import QtQuick
import qs.settings

/* Control menu host: switches between the macOS design and the classic one
 * (appearance.controlStyle = "macos" | "classic", toggled by the button at the top of each). */
Item {
    id: root
    property bool shown: false
    property Image backdrop: null
    property real bx: 0
    property real by: 0
    readonly property bool mac: Config.cfg.appearance.controlStyle !== "classic"

    implicitWidth: loader.item ? loader.item.implicitWidth : 348
    implicitHeight: loader.item ? loader.item.implicitHeight : 0
    width: implicitWidth
    height: implicitHeight

    Loader {
        id: loader
        anchors.fill: parent
        sourceComponent: root.mac ? macPanel : classicPanel
    }

    Component {
        id: macPanel
        IslandPanelMac {
            shown: root.shown
            backdrop: root.backdrop
            bx: root.bx
            by: root.by
        }
    }

    Component {
        id: classicPanel
        IslandPanelClassic {
            shown: root.shown
        }
    }
}
