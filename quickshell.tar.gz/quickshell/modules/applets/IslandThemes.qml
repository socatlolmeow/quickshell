pragma ComponentBehavior: Bound
import Quickshell
import Quickshell.Io
import QtQuick
import QtQuick.Layouts
import QtQuick.Controls.Basic
import Qt.labs.folderlistmodel 2.11

import qs
import qs.settings
import qs.widgets
import qs.modules.Services

Item {
    id: root
    implicitWidth: 516
    implicitHeight: 440
    readonly property bool searching: searchBar.activeFocus

    NumberAnimation on opacity {
        from: 0
        to: 1
        duration: 200
    }

    onSearchingChanged: Island.pinned = searching
    Component.onDestruction: Island.pinned = false

    function focusSearch() {
        searchBar.forceActiveFocus();
    }

    FolderListModel {
        id: schemeModel
        folder: Qt.resolvedUrl(Quickshell.shellDir + "/schemes/")
        nameFilters: searchBar.text === "" ? [] : ["*" + searchBar.text + "*"]
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 15
        spacing: 10

        StyledText {
            Layout.leftMargin: 4
            text: "Themes"
            color: Colors.pillFg
            wght: Typography.wEmph
            textSize: Config.cfg.appearance.fontSize + 2
        }

        TextField {
            id: searchBar
            Layout.fillWidth: true
            placeholderText: "Search schemes…"
            placeholderTextColor: Colors.pillMuted
            leftPadding: 16
            rightPadding: 16
            font.family: Typography.family
            font.pixelSize: Typography.fs(Config.cfg.appearance.fontSize)
            font.weight: Typography.weightEnum(Typography.wBody)
            font.variableAxes: Typography.axes(Typography.fs(Config.cfg.appearance.fontSize), Typography.wBody, 0)
            color: Colors.pillFg
            selectionColor: Colors.accent
            selectedTextColor: Colors.pillBg
            verticalAlignment: TextInput.AlignVCenter
            Keys.onEscapePressed: {
                searchBar.focus = false;
                Island.page = "main";
            }
            background: Rectangle {
                color: Colors.pillCard
                implicitHeight: 40
                radius: height / 2
                border.width: 1
                border.color: searchBar.activeFocus ? Colors.alpha(Colors.accent, 0.7) : Colors.pillLine

                Behavior on border.color {
                    ColorAnimation {
                        duration: 120
                    }
                }
            }
        }

        ListView {
            id: schemeList
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 3
            clip: true
            model: schemeModel

            delegate: Rectangle {
                id: row
                required property var modelData
                readonly property bool current: modelData.fileName === Config.cfg.appearance.currentTheme

                FileView {
                    path: Qt.resolvedUrl(Quickshell.shellDir + "/schemes/" + row.modelData.fileName)
                    adapter: JsonAdapter {
                        id: swatch
                        property color base08
                        property color base09
                        property color base0B
                        property color base0D
                        property color base0E
                    }
                }

                width: schemeList.width
                height: 38
                radius: 19
                color: current ? Colors.alpha(Colors.accent, 0.16) : (rowMouse.containsMouse ? Colors.pillCard2 : "transparent")

                Behavior on color {
                    ColorAnimation {
                        duration: 120
                    }
                }

                RowLayout {
                    anchors.fill: parent
                    anchors.leftMargin: 16
                    anchors.rightMargin: 14
                    spacing: 8

                    StyledText {
                        Layout.fillWidth: true
                        text: row.modelData.fileBaseName.replace(/^base16-/, "")
                        color: row.current ? Colors.accent : Colors.pillFg
                        wght: row.current ? Typography.wEmph : Typography.wBody
                        elide: Text.ElideRight
                    }

                    Row {
                        spacing: 3
                        Repeater {
                            model: [swatch.base08, swatch.base09, swatch.base0B, swatch.base0D, swatch.base0E]
                            delegate: Rectangle {
                                required property var modelData
                                width: 10
                                height: 10
                                radius: 5
                                color: modelData
                                opacity: row.current ? 1 : 0.75
                            }
                        }
                    }
                }

                MouseArea {
                    id: rowMouse
                    anchors.fill: parent
                    acceptedButtons: Qt.LeftButton
                    cursorShape: Qt.PointingHandCursor
                    hoverEnabled: true
                    onClicked: {
                        setTheme.themeName = row.modelData.fileBaseName;
                        setTheme.running = true;
                        Config.cfg.appearance.currentTheme = row.modelData.fileName;
                    }
                    Process {
                        id: setTheme
                        property string themeName
                        command: ["tinty", "apply", themeName]
                    }
                }
            }
        }
    }
}
