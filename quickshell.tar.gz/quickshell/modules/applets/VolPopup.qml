pragma ComponentBehavior: Bound
import qs
import qs.settings
import Quickshell
import QtQuick
import qs.widgets
import qs.modules.Services
import QtQuick.Layouts

Panel {
    id: root
    implicitWidth: 340
    implicitHeight: audioLayout.implicitHeight + 32
    bgAlpha: 0.72
    dropShadow: false

    MouseArea {
        anchors.fill: parent
        acceptedButtons: Qt.AllButtons
    }

    ColumnLayout {
        id: audioLayout
        anchors.fill: parent
        anchors.margins: 16
        spacing: 10

        StyledText {
            Layout.leftMargin: 4
            text: "OUTPUT"
            color: Colors.muted
            wght: Typography.wEmph
            textSize: Config.cfg.appearance.fontSize - 3
            font.letterSpacing: 1
        }

        Repeater {
            model: Audio.sinks

            delegate: Rectangle {
                id: sink
                required property var modelData
                readonly property bool isDefault: modelData === Audio.defaultAudio
                readonly property bool isPreferred: modelData === Audio.preferredAudio

                Layout.fillWidth: true
                implicitHeight: sinkCol.implicitHeight + 24
                radius: 16
                color: isDefault ? Colors.alpha(Colors.accent, 0.12) : Colors.alpha(Colors.surface, 0.55)
                border.width: 1
                border.color: isDefault ? Colors.alpha(Colors.accent, 0.5) : Colors.hairline

                Behavior on color {
                    ColorAnimation {
                        duration: 120
                    }
                }
                Behavior on border.color {
                    ColorAnimation {
                        duration: 120
                    }
                }

                ColumnLayout {
                    id: sinkCol
                    anchors.fill: parent
                    anchors.margins: 12
                    spacing: 8

                    RowLayout {
                        Layout.fillWidth: true
                        spacing: 10

                        StyledIcon {
                            iconName: Audio.getVolumeIcon(sink.modelData)
                            tint: sink.modelData.audio.muted ? Colors.muted : (muteArea.containsMouse ? Colors.accent : Colors.font)
                            MouseArea {
                                id: muteArea
                                anchors.fill: parent
                                anchors.margins: -6
                                hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor
                                acceptedButtons: Qt.LeftButton
                                onClicked: sink.modelData.audio.muted = !sink.modelData.audio.muted
                            }
                        }

                        StyledText {
                            Layout.fillWidth: true
                            text: sink.modelData.nickname || sink.modelData.description
                            color: sink.isDefault ? Colors.font : Colors.subtle
                            wght: sink.isDefault ? Typography.wEmph : Typography.wBody
                            elide: Text.ElideRight
                            MouseArea {
                                anchors.fill: parent
                                cursorShape: Qt.PointingHandCursor
                                acceptedButtons: Qt.LeftButton
                                onClicked: Audio.setDefaultSink(sink.modelData)
                            }
                        }

                        StyledIcon {
                            iconName: "radio-button"
                            fill: sink.isDefault
                            tint: sink.isDefault ? Colors.accent : Colors.subtle
                            opacity: (sink.isPreferred && !sink.isDefault) ? 0.5 : 1.0
                            MouseArea {
                                anchors.fill: parent
                                anchors.margins: -6
                                cursorShape: Qt.PointingHandCursor
                                acceptedButtons: Qt.LeftButton
                                onClicked: Audio.setDefaultSink(sink.modelData)
                            }
                        }
                    }

                    RowLayout {
                        Layout.fillWidth: true
                        spacing: 12

                        StyledSlider {
                            Layout.fillWidth: true
                            focusPolicy: Qt.NoFocus
                            value: sink.modelData.audio.volume
                            from: 0
                            to: 1
                            onMoved: sink.modelData.audio.volume = value
                        }

                        StyledText {
                            Layout.preferredWidth: 36
                            horizontalAlignment: Text.AlignRight
                            text: Math.round(sink.modelData.audio.volume * 100) + "%"
                            color: Colors.subtle
                            textSize: Config.cfg.appearance.fontSize - 2
                            font.features: {
                            "tnum": 1,
                            "calt": 1,
                            "kern": 1
                        }
                        }
                    }
                }
            }
        }
    }
}
