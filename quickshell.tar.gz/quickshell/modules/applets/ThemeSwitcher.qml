pragma ComponentBehavior: Bound
import Quickshell
import Quickshell.Io
import QtQuick
import QtQuick.Layouts
import QtQuick.Controls.Basic
import Qt.labs.folderlistmodel 2.11

import qs
import qs.settings
import qs.widgets
import qs.modules.Services

Panel {
    id: root
    implicitWidth: 380
    bgAlpha: 0.72
    dropShadow: false
    implicitHeight: 560

    MouseArea {
        acceptedButtons: Qt.AllButtons
        anchors.fill: parent
    }

    function focusSearch() {
        searchBar.forceActiveFocus();
    }

    FolderListModel {
        id: schemeModel
        folder: Qt.resolvedUrl(Quickshell.shellDir + "/schemes/")
        nameFilters: searchBar.text === "" ? [] : ["*" + searchBar.text + "*"]
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 18
        spacing: 12

        StyledText {
            text: "Themes"
            wght: Typography.wEmph
            textSize: Config.cfg.appearance.fontSize + 4
        }

        TextField {
            id: searchBar
            Layout.fillWidth: true
            placeholderText: "Search schemes…"
            placeholderTextColor: Colors.muted
            leftPadding: 14
            rightPadding: 14
            font.family: Typography.family
            font.pixelSize: Typography.fs(Config.cfg.appearance.fontSize)
            font.italic: false
            font.strikeout: false
            font.weight: Typography.weightEnum(Typography.wBody)
            font.variableAxes: Typography.axes(Typography.fs(Config.cfg.appearance.fontSize), Typography.wBody, 0)
            color: Colors.font
            selectionColor: Colors.accent
            selectedTextColor: Colors.bg
            verticalAlignment: TextInput.AlignVCenter
            background: Rectangle {
                color: Colors.surface
                implicitHeight: 40
                radius: height / 2
                border.width: 1
                border.color: searchBar.activeFocus ? Colors.alpha(Colors.accent, 0.7) : Colors.overlay

                Behavior on border.color {
                    ColorAnimation { duration: 120 }
                }
            }
        }

        ListView {
            id: schemeList
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 3
            clip: true
            model: schemeModel

            delegate: Rectangle {
                id: row
                required property var modelData
                readonly property bool current: modelData.fileName === Config.cfg.appearance.currentTheme

                FileView {
                    id: swatchView
                    path: Qt.resolvedUrl(Quickshell.shellDir + "/schemes/" + row.modelData.fileName)
                    adapter: JsonAdapter {
                        id: swatchData
                        property color base08
                        property color base09
                        property color base0B
                        property color base0D
                        property color base0E
                    }
                }

                width: schemeList.width
                height: 38
                radius: Config.cfg.appearance.rounding - 6
                color: current ? Colors.alpha(Colors.accent, 0.16) : (rowMouse.containsMouse ? Colors.surface : "transparent")

                Behavior on color {
                    ColorAnimation { duration: 120 }
                }

                RowLayout {
                    anchors.fill: parent
                    anchors.leftMargin: 12
                    anchors.rightMargin: 10
                    spacing: 8

                    StyledText {
                        Layout.fillWidth: true
                        text: row.modelData.fileBaseName.replace(/^base16-/, "")
                        color: row.current ? Colors.accent : Colors.font
                        wght: row.current ? Typography.wEmph : Typography.wBody
                        elide: Text.ElideRight
                    }

                    Row {
                        spacing: 3
                        Repeater {
                            model: [swatchData.base08, swatchData.base09, swatchData.base0B,
                                    swatchData.base0D, swatchData.base0E]
                            delegate: Rectangle {
                                required property var modelData
                                width: 10
                                height: 10
                                radius: 5
                                color: modelData
                                opacity: row.current ? 1 : 0.75
                            }
                        }
                    }
                }

                MouseArea {
                    id: rowMouse
                    anchors.fill: parent
                    acceptedButtons: Qt.LeftButton
                    cursorShape: Qt.PointingHandCursor
                    hoverEnabled: true
                    onClicked: {
                        setTheme.themeName = row.modelData.fileBaseName;
                        setTheme.running = true;
                        Config.cfg.appearance.currentTheme = row.modelData.fileName;
                    }
                    Process {
                        id: setTheme
                        property string themeName
                        command: ["tinty", "apply", themeName]
                    }
                }
            }
        }
    }
}
