pragma ComponentBehavior: Bound
import Quickshell
import QtQuick
import QtQuick.Layouts

import qs
import qs.settings
import qs.widgets
import qs.modules.Services

Item {
    id: root
    implicitWidth: 516
    implicitHeight: 160
    focus: true

    property int selected: 0

    /* Edit the commands here. Logout is Hyprland-specific; if you start
     * Hyprland through uwsm use ["uwsm", "stop"] instead. */
    readonly property var actions: [
        {
            label: "Shutdown",
            icon: "power",
            cmd: ["loginctl", "poweroff"],
            danger: true
        },
        {
            label: "Reboot",
            icon: "arrow-clockwise",
            cmd: ["loginctl", "reboot"],
            danger: false
        },
        {
            label: "Sleep",
            icon: "moon",
            cmd: ["loginctl", "suspend"],
            danger: false
        },
        {
            label: "Logout",
            icon: "sign-out",
            cmd: ["hyprctl", "dispatch", "exit"],
            danger: false
        }
    ]

    NumberAnimation on opacity {
        from: 0
        to: 1
        duration: 200
    }

    /* Keep the island open while the menu is up, and let go when it goes. */
    Component.onCompleted: {
        Island.pinned = true;
        forceActiveFocus();
    }
    Component.onDestruction: Island.pinned = false

    function run(i) {
        const a = root.actions[i];
        Island.dismiss();
        Quickshell.execDetached(a.cmd);
    }

    function move(dir) {
        const n = root.actions.length;
        root.selected = (root.selected + dir + n) % n;
    }

    Keys.onEscapePressed: Island.dismiss()
    Keys.onLeftPressed: root.move(-1)
    Keys.onRightPressed: root.move(1)
    Keys.onTabPressed: root.move(1)
    Keys.onBacktabPressed: root.move(-1)
    Keys.onReturnPressed: root.run(root.selected)
    Keys.onEnterPressed: root.run(root.selected)
    Keys.onPressed: event => {
        const n = event.key - Qt.Key_1;
        if (n >= 0 && n < root.actions.length) {
            root.run(n);
            event.accepted = true;
        }
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 15
        spacing: 10

        StyledText {
            Layout.leftMargin: 4
            text: "Power"
            color: Colors.pillFg
            wght: Typography.wEmph
            textSize: Config.cfg.appearance.fontSize + 2
        }

        RowLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 10

            Repeater {
                model: root.actions

                delegate: Rectangle {
                    id: tile
                    required property var modelData
                    required property int index
                    readonly property bool sel: root.selected === index
                    readonly property color tone: modelData.danger ? Colors.urgent : Colors.accent

                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    Layout.preferredWidth: 1
                    radius: 18
                    color: sel ? Colors.alpha(tone, 0.16) : Colors.pillCard
                    border.width: sel ? 1 : 0
                    border.color: Colors.alpha(tone, 0.6)

                    Behavior on color {
                        ColorAnimation {
                            duration: 120
                        }
                    }

                    StyledText {
                        anchors.top: parent.top
                        anchors.left: parent.left
                        anchors.margins: 10
                        text: tile.index + 1
                        color: Colors.pillMuted
                        textSize: Config.cfg.appearance.fontSize - 3
                    }

                    ColumnLayout {
                        anchors.centerIn: parent
                        spacing: 10

                        StyledIcon {
                            Layout.alignment: Qt.AlignHCenter
                            Layout.preferredWidth: 28
                            Layout.preferredHeight: 28
                            width: 28
                            height: 28
                            iconName: tile.modelData.icon
                            tint: tile.sel ? tile.tone : Colors.pillFg
                        }
                        StyledText {
                            Layout.alignment: Qt.AlignHCenter
                            text: tile.modelData.label
                            color: tile.sel ? tile.tone : Colors.pillFg
                            wght: tile.sel ? Typography.wEmph : Typography.wBody
                        }
                    }

                    MouseArea {
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        acceptedButtons: Qt.LeftButton
                        onEntered: root.selected = tile.index
                        onClicked: root.run(tile.index)
                    }
                }
            }
        }
    }
}
