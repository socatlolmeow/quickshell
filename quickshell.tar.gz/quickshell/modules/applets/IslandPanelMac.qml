pragma ComponentBehavior: Bound
import Quickshell
import Quickshell.Widgets
import Quickshell.Services.Mpris
import Quickshell.Services.UPower
import QtQuick
import QtQuick.Layouts
import QtQuick.Effects

import qs
import qs.settings
import qs.widgets
import qs.modules.Services
import qs.modules.notifications

/* macOS Control Center, on liquid glass.
 *
 * Layout follows macOS (Big Sur -> Sequoia):
 *   [ Wi-Fi / Bluetooth / Airplane ] [ Focus            ]
 *                                    [ Awake ] [ Night  ]
 *   [ Display ........................................ ]
 *   [ Sound .......................................... ]
 *   [ Now Playing ..................................... ]
 *   [ small square tiles ]
 *   [ system rings ]  [ notifications ]  [ footer ]
 */
Panel {
    id: root
    property bool shown: false

    /* wallpaper in screen coordinates + the position of this panel on it (set by Bar.qml) */
    property Image backdrop: null
    property real bx: 0
    property real by: 0

    readonly property real glassRadius: 26
    readonly property real gap: 12

    /* ---- macOS palette ---- */
    readonly property bool dark: !Colors.light
    readonly property color fg: dark ? Qt.rgba(1, 1, 1, 0.96) : Qt.rgba(0, 0, 0, 0.85)
    readonly property color fgSub: dark ? Qt.rgba(1, 1, 1, 0.58) : Qt.rgba(0, 0, 0, 0.5)
    readonly property color blue: dark ? "#0A84FF" : "#007AFF"
    readonly property color red: dark ? "#FF453A" : "#FF3B30"
    readonly property color green: dark ? "#30D158" : "#34C759"
    /* module (tile) surface on top of the glass */
    readonly property color modFill: dark ? Qt.rgba(1, 1, 1, 0.11) : Qt.rgba(1, 1, 1, 0.5)
    readonly property color modLine: dark ? Qt.rgba(1, 1, 1, 0.08) : Qt.rgba(1, 1, 1, 0.65)
    readonly property color hoverFill: dark ? Qt.rgba(1, 1, 1, 0.07) : Qt.rgba(0, 0, 0, 0.045)
    /* round icon buttons that are switched off */
    readonly property color offFill: dark ? Qt.rgba(1, 1, 1, 0.20) : Qt.rgba(0.47, 0.47, 0.5, 0.22)
    readonly property color offIcon: dark ? Qt.rgba(1, 1, 1, 0.95) : Qt.rgba(0, 0, 0, 0.7)
    /* sliders */
    readonly property color trackFill: dark ? Qt.rgba(1, 1, 1, 0.20) : Qt.rgba(0, 0, 0, 0.12)
    readonly property color sliderFill: "#FFFFFF"
    readonly property color sliderIcon: Qt.rgba(0, 0, 0, 0.55)

    property real dragRatio: -1

    readonly property MprisPlayer player: {
        const list = Mpris.players.values;
        let first = null;
        for (const p of list) {
            if (p.isPlaying)
                return p;
            if (!first)
                first = p;
        }
        return first;
    }
    readonly property bool playing: player?.isPlaying ?? false
    readonly property string artUrl: player?.trackArtUrl ?? ""

    readonly property var battery: UPower.displayDevice
    readonly property bool hasBattery: battery.isLaptopBattery
    readonly property bool charging: battery.state === UPowerDeviceState.Charging

    function uptimeText(seconds) {
        const total = Math.max(0, Math.floor(seconds / 60));
        const m = total % 60;
        const h = Math.floor(total / 60) % 24;
        const d = Math.floor(total / 1440);
        if (d > 0)
            return "Up " + d + "d " + h + "h";
        if (h > 0)
            return "Up " + h + "h " + m + "m";
        return "Up " + m + "m";
    }

    SystemClock {
        id: clock
        precision: SystemClock.Minutes
    }

    /* ------------------------------------------------------------------ */
    /*  building blocks                                                    */
    /* ------------------------------------------------------------------ */

    /* the translucent rounded rectangle every control sits on */
    component Module: Rectangle {
        radius: 18
        color: root.modFill
        border.width: 1
        border.color: root.modLine
    }

    /* round icon: blue when on, translucent gray when off */
    component Orb: Rectangle {
        id: orb
        property string iconName
        property bool active: false
        property real size: 32
        property color activeColor: root.blue

        width: size
        height: size
        radius: size / 2
        color: active ? activeColor : root.offFill

        Behavior on color {
            ColorAnimation {
                duration: 140
            }
        }

        StyledIcon {
            anchors.centerIn: parent
            width: Math.round(orb.size * 0.5)
            height: width
            iconName: orb.iconName
            fill: orb.active
            tint: orb.active ? "#FFFFFF" : root.offIcon
        }
    }

    /* one row of the Wi-Fi / Bluetooth / Airplane module */
    component ConnRow: Item {
        id: cr
        property string iconName
        property string title
        property string subtitle
        property bool active: false
        signal clicked

        Layout.fillWidth: true
        implicitHeight: 44

        Rectangle {
            anchors.fill: parent
            anchors.margins: 2
            radius: 14
            color: root.hoverFill
            opacity: crArea.containsMouse ? 1 : 0
            Behavior on opacity {
                NumberAnimation {
                    duration: 100
                }
            }
        }

        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 10
            anchors.rightMargin: 8
            spacing: 9

            Orb {
                Layout.alignment: Qt.AlignVCenter
                size: 32
                iconName: cr.iconName
                active: cr.active
            }

            ColumnLayout {
                Layout.fillWidth: true
                Layout.preferredWidth: 0
                Layout.alignment: Qt.AlignVCenter
                spacing: 0

                StyledText {
                    Layout.fillWidth: true
                    text: cr.title
                    textSize: 13
                    wght: Typography.wStrong
                    color: root.fg
                    elide: Text.ElideRight
                }
                StyledText {
                    Layout.fillWidth: true
                    text: cr.subtitle
                    textSize: 11
                    color: root.fgSub
                    elide: Text.ElideRight
                }
            }
        }

        MouseArea {
            id: crArea
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: cr.clicked()
        }
    }

    /* wide tile: round icon + two lines (Focus) */
    component WideTile: Module {
        id: wt
        property string iconName
        property string title
        property string subtitle
        property bool active: false
        signal clicked

        Layout.fillWidth: true
        implicitHeight: 64
        scale: wtArea.pressed ? 0.97 : 1

        Behavior on scale {
            NumberAnimation {
                duration: 100
                easing.type: Easing.BezierSpline
                easing.bezierCurve: Motion.smooth
            }
        }

        Rectangle {
            anchors.fill: parent
            radius: parent.radius
            color: root.hoverFill
            opacity: wtArea.containsMouse ? 1 : 0
            Behavior on opacity {
                NumberAnimation {
                    duration: 100
                }
            }
        }

        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 10
            anchors.rightMargin: 8
            spacing: 9

            Orb {
                Layout.alignment: Qt.AlignVCenter
                size: 32
                iconName: wt.iconName
                active: wt.active
            }
            ColumnLayout {
                Layout.fillWidth: true
                Layout.preferredWidth: 0
                Layout.alignment: Qt.AlignVCenter
                spacing: 0

                StyledText {
                    Layout.fillWidth: true
                    text: wt.title
                    textSize: 13
                    wght: Typography.wStrong
                    color: root.fg
                    elide: Text.ElideRight
                }
                StyledText {
                    Layout.fillWidth: true
                    visible: text !== ""
                    text: wt.subtitle
                    textSize: 11
                    color: root.fgSub
                    elide: Text.ElideRight
                }
            }
        }

        MouseArea {
            id: wtArea
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: wt.clicked()
        }
    }

    /* small square tile: round icon over a label (Stage Manager / Screen Mirroring style) */
    component SquareTile: Module {
        id: sq
        property string iconName
        property string label
        property bool active: false
        property color activeColor: root.blue
        signal clicked

        Layout.fillWidth: true
        Layout.preferredWidth: 0
        implicitHeight: 64
        scale: sqArea.pressed ? 0.95 : 1

        Behavior on scale {
            NumberAnimation {
                duration: 100
                easing.type: Easing.BezierSpline
                easing.bezierCurve: Motion.smooth
            }
        }

        Rectangle {
            anchors.fill: parent
            radius: parent.radius
            color: root.hoverFill
            opacity: sqArea.containsMouse ? 1 : 0
            Behavior on opacity {
                NumberAnimation {
                    duration: 100
                }
            }
        }

        Orb {
            anchors.horizontalCenter: parent.horizontalCenter
            y: 9
            size: 30
            iconName: sq.iconName
            active: sq.active
            activeColor: sq.activeColor
        }
        StyledText {
            anchors.horizontalCenter: parent.horizontalCenter
            y: 9 + 30 + 4
            width: parent.width - 8
            horizontalAlignment: Text.AlignHCenter
            text: sq.label
            textSize: 11
            color: root.fg
            elide: Text.ElideRight
        }

        MouseArea {
            id: sqArea
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: sq.clicked()
        }
    }

    /* "Display" / "Sound": title on top, white slider underneath. The white fill is never
     * narrower than the round end that holds the icon (so the icon always sits on white). */
    component SliderModule: Module {
        id: sm
        property string title
        property string iconName
        property real value: 0
        property real dragValue: 0
        readonly property real shown: Math.max(0, Math.min(1, slArea.pressed ? dragValue : value))
        signal moved(real ratio)
        signal iconClicked

        Layout.fillWidth: true
        implicitHeight: 66

        StyledText {
            x: 14
            y: 9
            text: sm.title
            textSize: 13
            wght: Typography.wStrong
            color: root.fg
        }

        Item {
            id: sl
            x: 12
            y: 33
            width: sm.width - 24
            height: 24
            readonly property real travel: Math.max(1, width - height)

            Rectangle {
                anchors.fill: parent
                radius: height / 2
                color: root.trackFill
            }

            Rectangle {
                id: fillRect
                width: sl.height + sl.travel * sm.shown
                height: sl.height
                radius: height / 2
                color: root.sliderFill
                layer.enabled: true
                layer.effect: MultiEffect {
                    shadowEnabled: true
                    shadowColor: "black"
                    shadowOpacity: 0.22
                    shadowBlur: 0.5
                    shadowVerticalOffset: 1
                }

                /* no easing while dragging, so the fill never lags behind the pointer */
                Behavior on width {
                    enabled: !slArea.pressed
                    NumberAnimation {
                        duration: 110
                        easing.type: Easing.BezierSpline
                        easing.bezierCurve: Motion.smooth
                    }
                }

                StyledIcon {
                    x: (sl.height - width) / 2
                    anchors.verticalCenter: parent.verticalCenter
                    width: 14
                    height: 14
                    iconName: sm.iconName
                    tint: root.sliderIcon
                }
            }

            MouseArea {
                id: slArea
                anchors.fill: parent
                cursorShape: Qt.PointingHandCursor
                preventStealing: true
                function ratioAt(x) {
                    return Math.max(0, Math.min(1, (x - sl.height) / sl.travel));
                }
                onPressed: mouse => {
                    sm.dragValue = ratioAt(mouse.x);
                    sm.moved(sm.dragValue);
                }
                onPositionChanged: mouse => {
                    if (pressed) {
                        sm.dragValue = ratioAt(mouse.x);
                        sm.moved(sm.dragValue);
                    }
                }
                onWheel: wheel => {
                    const step = wheel.angleDelta.y > 0 ? 0.02 : -0.02;
                    sm.moved(Math.max(0, Math.min(1, sm.value + step)));
                }
            }
            MouseArea {
                width: sl.height
                height: sl.height
                cursorShape: Qt.PointingHandCursor
                onClicked: sm.iconClicked()
            }
        }
    }

    /* plain glyph button for the Now Playing tile */
    component Glyph: Item {
        id: gl
        property string iconName
        property real glyphSize: 18
        signal clicked

        implicitWidth: 32
        implicitHeight: 32
        opacity: enabled ? 1 : 0.3
        scale: glArea.pressed ? 0.88 : 1

        Behavior on scale {
            NumberAnimation {
                duration: 90
                easing.type: Easing.BezierSpline
                easing.bezierCurve: Motion.smooth
            }
        }

        Rectangle {
            anchors.fill: parent
            radius: width / 2
            color: root.hoverFill
            opacity: glArea.containsMouse ? 1 : 0
        }
        StyledIcon {
            anchors.centerIn: parent
            width: gl.glyphSize
            height: gl.glyphSize
            iconName: gl.iconName
            tint: root.fg
        }
        MouseArea {
            id: glArea
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: gl.clicked()
        }
    }

    /* round action button in the footer */
    component FootButton: Rectangle {
        id: fb
        property string iconName
        signal clicked

        implicitWidth: 30
        implicitHeight: 30
        radius: width / 2
        color: fbArea.containsMouse ? Qt.lighter(root.offFill, 1.35) : root.offFill
        scale: fbArea.pressed ? 0.92 : 1

        Behavior on color {
            ColorAnimation {
                duration: 120
            }
        }
        Behavior on scale {
            NumberAnimation {
                duration: 90
                easing.type: Easing.BezierSpline
                easing.bezierCurve: Motion.smooth
            }
        }

        StyledIcon {
            anchors.centerIn: parent
            width: 15
            height: 15
            iconName: fb.iconName
            tint: root.offIcon
        }
        MouseArea {
            id: fbArea
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: fb.clicked()
        }
    }

    /* thin progress ring with a value inside and a label (+ small second line) underneath */
    component StatRing: Item {
        id: ring
        property real value: 0
        property string valueText
        property string label
        property string sub
        property color arc: root.blue

        Layout.fillWidth: true
        Layout.preferredWidth: 0
        implicitHeight: 40 + 4 + ringLabel.implicitHeight + (ringSub.visible ? ringSub.implicitHeight : 0)

        Item {
            anchors.top: parent.top
            anchors.horizontalCenter: parent.horizontalCenter
            width: 40
            height: 40

            Canvas {
                id: canvas
                anchors.fill: parent
                readonly property color arcColor: ring.arc
                readonly property color trackColor: root.offFill
                readonly property real shownValue: Math.max(0, Math.min(1, ring.value))
                onArcColorChanged: requestPaint()
                onTrackColorChanged: requestPaint()
                onShownValueChanged: requestPaint()
                onPaint: {
                    const ctx = getContext("2d");
                    ctx.reset();
                    const c = width / 2;
                    const r = c - 3;
                    ctx.lineWidth = 4;
                    ctx.lineCap = "round";
                    ctx.strokeStyle = trackColor;
                    ctx.beginPath();
                    ctx.arc(c, c, r, 0, Math.PI * 2);
                    ctx.stroke();
                    if (shownValue > 0.005) {
                        ctx.strokeStyle = arcColor;
                        ctx.beginPath();
                        ctx.arc(c, c, r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * shownValue);
                        ctx.stroke();
                    }
                }
            }

            StyledText {
                anchors.centerIn: parent
                text: ring.valueText
                textSize: 12
                wght: Typography.wStrong
                color: root.fg
                tabular: true
            }
        }

        StyledText {
            id: ringLabel
            anchors.top: parent.top
            anchors.topMargin: 40 + 4
            anchors.horizontalCenter: parent.horizontalCenter
            text: ring.label
            textSize: 11
            wght: Typography.wStrong
            color: root.fg
        }
        StyledText {
            id: ringSub
            visible: text.trim() !== ""
            anchors.top: ringLabel.bottom
            anchors.horizontalCenter: parent.horizontalCenter
            text: ring.sub
            textSize: 10
            color: root.fgSub
        }
    }

    /* ------------------------------------------------------------------ */
    /*  panel                                                              */
    /* ------------------------------------------------------------------ */

    implicitWidth: 348
    bgAlpha: 0.98
    implicitHeight: content.implicitHeight + 2 * root.gap
    radius: 0
    dropShadow: false
    color: "transparent"
    border.width: 0

    onShownChanged: {
        if (shown) {
            NotiServer.unread = 0;
            Brightness.refresh();
        }
    }

    Timer {
        running: root.shown && root.playing
        interval: 1000
        repeat: true
        onTriggered: root.player.positionChanged()
    }

    Timer {
        running: root.shown
        interval: 2000
        repeat: true
        triggeredOnStart: true
        onTriggered: SysInfo.refresh()
    }

    /* solid fallback while the wallpaper is still loading (or the shader failed) */
    Rectangle {
        anchors.fill: parent
        radius: root.glassRadius
        visible: !glass.visible || glass.failed
        color: root.dark ? Qt.rgba(0.14, 0.14, 0.16, 0.92) : Qt.rgba(0.96, 0.96, 0.97, 0.92)
        border.width: 1
        border.color: root.dark ? Qt.rgba(1, 1, 1, 0.14) : Qt.rgba(0, 0, 0, 0.08)
    }

    LiquidGlass {
        id: glass
        anchors.fill: parent
        visible: root.backdrop !== null && root.backdrop.status === Image.Ready
        backdrop: root.backdrop
        bx: root.bx
        by: root.by
        radius: root.glassRadius
        dark: root.dark
        tint: root.dark ? 0.62 : 0.55
        blur: 16
        thickness: 14
        shadowAmt: 0
        magnify: 0
        ringW: -1.2
    }

    ColumnLayout {
        id: content
        anchors.fill: parent
        anchors.margins: root.gap
        spacing: root.gap

        /* top row: title + switch to the classic design */
        RowLayout {
            Layout.fillWidth: true
            Layout.leftMargin: 6
            Layout.rightMargin: 2

            StyledText {
                text: "Control Center"
                textSize: 13
                wght: Typography.wStrong
                color: root.fg
            }
            Item {
                Layout.fillWidth: true
            }
            FootButton {
                iconName: "squares-four"
                onClicked: Config.cfg.appearance.controlStyle = "classic"
            }
        }

        /* top block: connectivity on the left, Focus + two squares on the right */
        RowLayout {
            Layout.fillWidth: true
            spacing: root.gap

            Module {
                Layout.fillWidth: true
                Layout.preferredWidth: 0
                Layout.alignment: Qt.AlignTop
                implicitHeight: connCol.implicitHeight + 8

                ColumnLayout {
                    id: connCol
                    anchors.fill: parent
                    anchors.margins: 4
                    spacing: 0

                    ConnRow {
                        iconName: Network.wifiEnabled ? "wifi-high" : "wifi-slash"
                        title: "Wi-Fi"
                        subtitle: Network.connectedNet?.name ?? (Network.wifiEnabled ? "Not Connected" : "Off")
                        active: Network.wifiEnabled
                        onClicked: Network.toggleWifi()
                    }
                    ConnRow {
                        iconName: !Bt.enabled ? "bluetooth-slash" : (Bt.device ? "bluetooth-connected" : "bluetooth")
                        title: "Bluetooth"
                        subtitle: Bt.enabled ? (Bt.device?.name ?? "On") : "Off"
                        active: Bt.enabled
                        onClicked: Bt.toggle()
                    }
                    ConnRow {
                        iconName: "airplane-tilt"
                        title: "Airplane"
                        subtitle: Toggles.airplane ? "On" : "Off"
                        active: Toggles.airplane
                        onClicked: Toggles.toggleAirplane()
                    }
                }
            }

            ColumnLayout {
                Layout.fillWidth: true
                Layout.preferredWidth: 0
                Layout.alignment: Qt.AlignTop
                spacing: root.gap

                WideTile {
                    iconName: "moon"
                    title: "Focus"
                    subtitle: NotiServer.dnd ? "Do Not Disturb" : "Off"
                    active: NotiServer.dnd
                    onClicked: NotiServer.dnd = !NotiServer.dnd
                }

                RowLayout {
                    Layout.fillWidth: true
                    spacing: root.gap

                    SquareTile {
                        iconName: "coffee"
                        label: "Awake"
                        active: Toggles.caffeine
                        onClicked: Toggles.caffeine = !Toggles.caffeine
                    }
                    SquareTile {
                        iconName: "sun-horizon"
                        label: "Night"
                        active: Toggles.nightLight
                        onClicked: Toggles.nightLight = !Toggles.nightLight
                    }
                }
            }
        }

        SliderModule {
            visible: Brightness.available
            title: "Display"
            iconName: "sun-dim"
            value: Brightness.value
            onMoved: v => Brightness.set(v)
        }

        SliderModule {
            visible: Audio.defaultAudio !== null
            title: "Sound"
            iconName: Audio.defaultAudio ? Audio.getVolumeIcon(Audio.defaultAudio) : "speaker-none"
            value: Audio.defaultAudio?.audio.volume ?? 0
            onMoved: v => Audio.defaultAudio.audio.volume = v
            onIconClicked: Audio.defaultAudio.audio.muted = !Audio.defaultAudio.audio.muted
        }

        /* Now Playing */
        Module {
            Layout.fillWidth: true
            visible: root.player !== null
            implicitHeight: 64

            RowLayout {
                anchors.fill: parent
                anchors.leftMargin: 10
                anchors.rightMargin: 8
                spacing: 10

                ClippingRectangle {
                    Layout.preferredWidth: 44
                    Layout.preferredHeight: 44
                    Layout.alignment: Qt.AlignVCenter
                    radius: 8
                    color: root.offFill

                    Image {
                        anchors.fill: parent
                        source: root.artUrl
                        fillMode: Image.PreserveAspectCrop
                        asynchronous: true
                        opacity: status === Image.Ready ? 1 : 0
                        Behavior on opacity {
                            NumberAnimation {
                                duration: 250
                            }
                        }
                    }
                    StyledIcon {
                        anchors.centerIn: parent
                        width: 20
                        height: 20
                        visible: root.artUrl === ""
                        iconName: "music-notes"
                        tint: root.fgSub
                    }
                }

                ColumnLayout {
                    Layout.fillWidth: true
                    Layout.preferredWidth: 0
                    Layout.alignment: Qt.AlignVCenter
                    spacing: 0

                    StyledText {
                        Layout.fillWidth: true
                        text: root.player?.trackTitle || "Not Playing"
                        textSize: 13
                        wght: Typography.wStrong
                        color: root.fg
                        elide: Text.ElideRight
                    }
                    StyledText {
                        Layout.fillWidth: true
                        visible: text !== ""
                        text: root.player?.trackArtists ?? ""
                        textSize: 12
                        color: root.fgSub
                        elide: Text.ElideRight
                    }
                }

                RowLayout {
                    Layout.alignment: Qt.AlignVCenter
                    spacing: 0

                    Glyph {
                        iconName: "skip-back"
                        glyphSize: 16
                        enabled: root.player?.canGoPrevious ?? false
                        onClicked: root.player.previous()
                    }
                    Glyph {
                        iconName: root.playing ? "pause" : "play"
                        glyphSize: 22
                        enabled: root.player?.canTogglePlaying ?? false
                        onClicked: root.player.togglePlaying()
                    }
                    Glyph {
                        iconName: "skip-forward"
                        glyphSize: 16
                        enabled: root.player?.canGoNext ?? false
                        onClicked: root.player.next()
                    }
                }
            }
        }

        /* the rest of the quick actions as small square modules */
        GridLayout {
            Layout.fillWidth: true
            columns: 4
            rowSpacing: root.gap
            columnSpacing: root.gap
            uniformCellWidths: true

            SquareTile {
                iconName: Audio.micMuted ? "microphone-slash" : "microphone"
                label: "Mic"
                active: Audio.micMuted
                activeColor: root.red
                onClicked: Audio.toggleMic()
            }
            SquareTile {
                iconName: "selection-plus"
                label: "Capture"
                onClicked: {
                    Island.dismiss();
                    Toggles.capture();
                }
            }
            SquareTile {
                iconName: Toggles.recording ? "stop-circle" : "record"
                label: Toggles.recording ? "Stop" : "Record"
                active: Toggles.recording
                activeColor: root.red
                onClicked: {
                    Island.dismiss();
                    Toggles.toggleRecording();
                }
            }
            SquareTile {
                iconName: "eyedropper"
                label: "Picker"
                onClicked: {
                    Island.dismiss();
                    Quickshell.execDetached(["hyprpicker", "-a"]);
                }
            }

            SquareTile {
                iconName: "keyboard"
                label: "Keyboard"
                onClicked: Quickshell.execDetached(["hyprctl", "switchxkblayout", "all", "next"])
            }
            SquareTile {
                iconName: "timer"
                label: Toggles.timerLeft > 0 ? Toggles.timerText : "Timer"
                active: Toggles.timerLeft > 0
                onClicked: Toggles.toggleTimer()
            }
            SquareTile {
                iconName: "folder-open"
                label: "Files"
                onClicked: {
                    Island.dismiss();
                    Quickshell.execDetached(["xdg-open", Quickshell.env("HOME")]);
                }
            }
            SquareTile {
                iconName: "game-controller"
                label: "Game"
                active: Toggles.gameMode
                onClicked: Toggles.gameMode = !Toggles.gameMode
            }
        }

        /* system rings */
        Module {
            Layout.fillWidth: true
            implicitHeight: statRow.implicitHeight + 24

            RowLayout {
                id: statRow
                anchors.fill: parent
                anchors.topMargin: 12
                anchors.bottomMargin: 12
                anchors.leftMargin: 6
                anchors.rightMargin: 6
                spacing: 0

                StatRing {
                    value: SysInfo.cpu
                    valueText: Math.round(SysInfo.cpu * 100)
                    label: "CPU"
                    sub: SysInfo.temp >= 0 ? Math.round(SysInfo.temp) + " °C" : ""
                }
                StatRing {
                    value: SysInfo.ram
                    valueText: Math.round(SysInfo.ram * 100)
                    label: "Memory"
                    sub: SysInfo.ramUsed.toFixed(1) + " GB"
                }
                StatRing {
                    value: SysInfo.disk
                    valueText: Math.round(SysInfo.disk * 100)
                    label: "Disk"
                    sub: Math.round(SysInfo.diskFree) + " GB free"
                }
                StatRing {
                    visible: root.hasBattery
                    value: root.battery.percentage
                    valueText: Math.round(root.battery.percentage * 100)
                    label: "Battery"
                    sub: root.charging ? "Charging" : ""
                    arc: root.charging ? root.green : root.blue
                }
            }
        }

        /* notifications, as individual banners like Notification Center */
        ColumnLayout {
            id: notiCol
            Layout.fillWidth: true
            spacing: 8

            RowLayout {
                Layout.fillWidth: true
                Layout.leftMargin: 6
                Layout.rightMargin: 6

                StyledText {
                    text: "Notifications"
                    textSize: 13
                    wght: Typography.wStrong
                    color: root.fg
                }
                Item {
                    Layout.fillWidth: true
                }
                StyledText {
                    visible: NotiServer.history.length > 0
                    text: "Clear All"
                    textSize: 12
                    color: clearArea.containsMouse ? Qt.lighter(root.blue, 1.2) : root.blue
                    MouseArea {
                        id: clearArea
                        anchors.fill: parent
                        anchors.margins: -4
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: NotiServer.history = []
                    }
                }
            }

            Repeater {
                model: NotiServer.history.slice(0, 2)

                delegate: Module {
                    id: entry
                    required property int index
                    required property var modelData
                    readonly property string iconSource: modelData.image ? modelData.image : (modelData.appIcon ? Quickshell.iconPath(modelData.appIcon, true) : "")

                    Layout.fillWidth: true
                    Layout.preferredHeight: 62
                    radius: 16

                    HoverHandler {
                        id: entryHover
                    }

                    ClippingRectangle {
                        id: avatar
                        x: 11
                        anchors.verticalCenter: parent.verticalCenter
                        width: 36
                        height: 36
                        radius: 9
                        color: Colors.alpha(root.blue, 0.22)

                        IconImage {
                            anchors.centerIn: parent
                            visible: entry.iconSource !== ""
                            implicitSize: 28
                            source: entry.iconSource
                        }
                        StyledText {
                            anchors.centerIn: parent
                            visible: entry.iconSource === ""
                            text: (entry.modelData.appName || "?").charAt(0).toUpperCase()
                            color: root.blue
                            wght: Typography.wStrong
                            textSize: 14
                        }
                    }

                    ColumnLayout {
                        anchors.left: avatar.right
                        anchors.leftMargin: 10
                        anchors.right: closeBtn.left
                        anchors.rightMargin: 6
                        anchors.verticalCenter: parent.verticalCenter
                        spacing: 0

                        StyledText {
                            Layout.fillWidth: true
                            text: entry.modelData.summary
                            textSize: 13
                            wght: Typography.wStrong
                            color: root.fg
                            elide: Text.ElideRight
                        }
                        StyledText {
                            Layout.fillWidth: true
                            text: entry.modelData.body
                            visible: text !== ""
                            textSize: 12
                            color: root.fgSub
                            elide: Text.ElideRight
                            maximumLineCount: 1
                        }
                        StyledText {
                            Layout.fillWidth: true
                            text: entry.modelData.appName
                            textSize: 10
                            color: root.fgSub
                            opacity: 0.8
                            elide: Text.ElideRight
                        }
                    }

                    Rectangle {
                        id: closeBtn
                        anchors.right: parent.right
                        anchors.rightMargin: 10
                        anchors.verticalCenter: parent.verticalCenter
                        width: 20
                        height: 20
                        radius: 10
                        color: root.offFill
                        opacity: entryHover.hovered ? 1 : 0

                        Behavior on opacity {
                            NumberAnimation {
                                duration: 120
                            }
                        }

                        StyledIcon {
                            anchors.centerIn: parent
                            width: 10
                            height: 10
                            iconName: "x"
                            fill: false
                            tint: root.offIcon
                        }
                        MouseArea {
                            anchors.fill: parent
                            cursorShape: Qt.PointingHandCursor
                            onClicked: NotiServer.history = NotiServer.history.filter((_, i) => i !== entry.index)
                        }
                    }
                }
            }

            StyledText {
                Layout.alignment: Qt.AlignHCenter
                Layout.topMargin: 4
                Layout.bottomMargin: 4
                visible: NotiServer.history.length === 0
                text: "No Notifications"
                textSize: 13
                color: root.fgSub
            }
        }

        /* footer: date + uptime on the left, shortcuts on the right */
        RowLayout {
            Layout.fillWidth: true
            Layout.leftMargin: 6
            Layout.rightMargin: 2
            spacing: 6

            ColumnLayout {
                spacing: 0

                StyledText {
                    text: Qt.formatDate(clock.date, "dddd, d MMMM")
                    textSize: 12
                    wght: Typography.wStrong
                    color: root.fg
                }
                StyledText {
                    text: root.uptimeText(SysInfo.uptime)
                    textSize: 11
                    color: root.fgSub
                }
            }
            Item {
                Layout.fillWidth: true
            }

            FootButton {
                iconName: "palette"
                onClicked: Island.page = "themes"
            }
            FootButton {
                iconName: "image-square"
                onClicked: Island.page = "walls"
            }
            FootButton {
                iconName: "lock"
                onClicked: Toggles.lock()
            }
            FootButton {
                iconName: "power"
                onClicked: Island.page = "power"
            }
        }
    }
}
