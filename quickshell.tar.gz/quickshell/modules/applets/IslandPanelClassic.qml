pragma ComponentBehavior: Bound
import Quickshell
import Quickshell.Widgets
import Quickshell.Services.Mpris
import Quickshell.Services.UPower
import QtQuick
import QtQuick.Layouts
import QtQuick.Effects

import qs
import qs.settings
import qs.widgets
import qs.modules.Services
import qs.modules.notifications

Panel {
    id: root
    property bool shown: false
    property real dragRatio: -1

    readonly property MprisPlayer player: {
        const list = Mpris.players.values;
        let first = null;
        for (const p of list) {
            if (p.isPlaying)
                return p;
            if (!first)
                first = p;
        }
        return first;
    }
    readonly property bool playing: player?.isPlaying ?? false
    readonly property string artUrl: player?.trackArtUrl ?? ""
    readonly property bool hasLength: player !== null && player.lengthSupported && player.length > 0
    readonly property bool canSeek: hasLength && player.canSeek && player.positionSupported
    readonly property real progress: hasLength ? Math.min(Math.max(player.position / player.length, 0), 1) : 0
    readonly property real shownProgress: dragRatio >= 0 ? dragRatio : progress
    readonly property int smallFont: Config.cfg.appearance.fontSize - 2

    readonly property var battery: UPower.displayDevice
    readonly property bool hasBattery: battery.isLaptopBattery
    readonly property bool charging: battery.state === UPowerDeviceState.Charging

    function uptimeText(seconds) {
        const total = Math.max(0, Math.floor(seconds / 60));
        const m = total % 60;
        const h = Math.floor(total / 60) % 24;
        const d = Math.floor(total / 1440);
        if (d > 0)
            return "up " + d + "d " + h + "h";
        if (h > 0)
            return "up " + h + "h " + m + "m";
        return "up " + m + "m";
    }

    SystemClock {
        id: clock
        precision: SystemClock.Minutes
    }

    component MediaButton: Rectangle {
        id: button
        property string iconName
        property bool primary: false
        signal clicked

        implicitWidth: primary ? 44 : 34
        implicitHeight: implicitWidth
        radius: width / 2
        opacity: enabled ? 1 : 0.3
        scale: area.pressed ? 0.9 : 1
        color: primary ? (area.containsMouse ? Qt.lighter(Colors.accent, 1.12) : Colors.accent) : (area.containsMouse ? Colors.pillCircle : "transparent")

        Behavior on color {
            ColorAnimation {
                duration: 120
            }
        }
        Behavior on scale {
            NumberAnimation {
                duration: 100
                easing.type: Easing.OutCubic
            }
        }

        StyledIcon {
            anchors.centerIn: parent
            width: button.primary ? 20 : 18
            height: width
            iconName: button.iconName
            tint: button.primary ? Colors.pillBg : Colors.pillFg
        }
        MouseArea {
            id: area
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: button.clicked()
        }
    }

    /* small round icon button for the header row */
    component HeaderButton: Rectangle {
        id: hb
        property string iconName
        property bool active: false
        property bool highlighted: false
        signal clicked

        implicitWidth: 34
        implicitHeight: 34
        radius: width / 2
        scale: hbArea.pressed ? 0.92 : 1
        color: hb.active ? Colors.accent : (hbArea.containsMouse ? Colors.pillCircle : (hb.highlighted ? Colors.pillCard2 : "transparent"))

        Behavior on color {
            ColorAnimation {
                duration: 120
            }
        }
        Behavior on scale {
            NumberAnimation {
                duration: 100
                easing.type: Easing.OutCubic
            }
        }

        StyledIcon {
            anchors.centerIn: parent
            width: 17
            height: 17
            iconName: hb.iconName
            fill: hb.active
            tint: hb.active ? Colors.pillBg : Colors.pillFg
        }
        MouseArea {
            id: hbArea
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: hb.clicked()
        }
    }

    /* full-width pill slider with the icon inside the fill; the fill's right edge follows the pointer
     * from `height` (icon circle only) to `width` (see ratioAt for the inverse mapping) */
    component SliderPill: Item {
        id: pill
        property string iconName
        property real value: 0
        property real dragValue: 0
        readonly property real shown: Math.max(0, Math.min(1, pillArea.pressed ? dragValue : value))
        // distance the fill edge can travel
        readonly property real travel: Math.max(1, width - height)
        signal moved(real ratio)
        signal iconClicked

        Layout.fillWidth: true
        implicitHeight: 48

        Rectangle {
            id: trackRect
            anchors.fill: parent
            radius: height / 2
            color: Colors.pillCard2
            border.width: 1
            border.color: Colors.pillLine

            Rectangle {
                id: fillRect
                width: parent.height + pill.travel * pill.shown
                height: parent.height
                radius: height / 2
                color: Colors.accent

                /* no easing while dragging, so the fill never lags behind the pointer */
                Behavior on width {
                    enabled: !pillArea.pressed
                    NumberAnimation {
                        duration: 110
                        easing.type: Easing.OutCubic
                    }
                }

                StyledIcon {
                    x: (parent.height - width) / 2
                    anchors.verticalCenter: parent.verticalCenter
                    width: 18
                    height: 18
                    iconName: pill.iconName
                    tint: Colors.pillBg
                }
            }
        }

        MouseArea {
            id: pillArea
            anchors.fill: parent
            cursorShape: Qt.PointingHandCursor
            preventStealing: true
            function ratioAt(x) {
                return Math.max(0, Math.min(1, (x - pill.height) / pill.travel));
            }
            onPressed: mouse => {
                pill.dragValue = ratioAt(mouse.x);
                pill.moved(pill.dragValue);
            }
            onPositionChanged: mouse => {
                if (pressed) {
                    pill.dragValue = ratioAt(mouse.x);
                    pill.moved(pill.dragValue);
                }
            }
            onWheel: wheel => {
                const step = wheel.angleDelta.y > 0 ? 0.02 : -0.02;
                pill.moved(Math.max(0, Math.min(1, pill.value + step)));
            }
        }
        MouseArea {
            width: parent.height
            height: parent.height
            cursorShape: Qt.PointingHandCursor
            onClicked: pill.iconClicked()
        }
    }

    component Tile: Rectangle {
        id: tile
        property string iconName
        property string title
        property string subtitle
        property bool active: false
        signal clicked

        Layout.fillWidth: true
        Layout.preferredWidth: 0
        implicitHeight: 64
        radius: height / 2
        color: tile.active ? (tileArea.containsMouse ? Qt.lighter(Colors.accent, 1.08) : Colors.accent) : (tileArea.containsMouse ? Colors.pillCircle : Colors.pillCard2)
        border.width: tile.active ? 0 : 1
        border.color: Colors.pillLine

        Behavior on color {
            ColorAnimation {
                duration: 120
            }
        }

        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 10
            anchors.rightMargin: 16
            spacing: 10

            Rectangle {
                Layout.preferredWidth: 46
                Layout.preferredHeight: 46
                radius: 23
                color: tile.active ? Colors.alpha(Colors.pillBg, 0.14) : Colors.pillCircle

                StyledIcon {
                    anchors.centerIn: parent
                    iconName: tile.iconName
                    fill: tile.active
                    tint: tile.active ? Colors.pillBg : Colors.pillFg
                }
            }

            ColumnLayout {
                Layout.fillWidth: true
                Layout.preferredWidth: 0
                spacing: 0

                StyledText {
                    Layout.fillWidth: true
                    text: tile.title
                    typeRole: "titleSmall"
                    color: tile.active ? Colors.pillBg : Colors.pillFg
                    elide: Text.ElideRight
                }
                StyledText {
                    Layout.fillWidth: true
                    text: tile.subtitle
                    color: tile.active ? Colors.alpha(Colors.pillBg, 0.72) : Colors.pillSubtle
                    typeRole: "bodySmall"
                    elide: Text.ElideRight
                }
            }

            StyledIcon {
                width: 14
                height: 14
                iconName: "caret-right"
                tint: tile.active ? Colors.pillBg : Colors.pillSubtle
            }
        }

        MouseArea {
            id: tileArea
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: tile.clicked()
        }
    }

    /* round toggle with a label underneath */
    component Toggle: Item {
        id: tg
        property string iconName
        property string label
        property bool active: false
        signal clicked

        Layout.fillWidth: true
        Layout.preferredWidth: 0
        implicitHeight: 56 + 6 + tgLabel.implicitHeight

        Rectangle {
            anchors.top: parent.top
            anchors.horizontalCenter: parent.horizontalCenter
            width: 56
            height: 56
            radius: 28
            scale: tgArea.pressed ? 0.92 : 1
            color: tg.active ? (tgArea.containsMouse ? Qt.lighter(Colors.accent, 1.08) : Colors.accent) : (tgArea.containsMouse ? Qt.lighter(Colors.pillCircle, 1.3) : Colors.pillCircle)

            Behavior on color {
                ColorAnimation {
                    duration: 120
                }
            }
            Behavior on scale {
                NumberAnimation {
                    duration: 100
                    easing.type: Easing.OutCubic
                }
            }

            StyledIcon {
                anchors.centerIn: parent
                iconName: tg.iconName
                fill: tg.active
                tint: tg.active ? Colors.pillBg : Colors.pillFg
            }
            MouseArea {
                id: tgArea
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: tg.clicked()
            }
        }
        StyledText {
            id: tgLabel
            anchors.top: parent.top
            anchors.topMargin: 56 + 6
            anchors.horizontalCenter: parent.horizontalCenter
            text: tg.label
            color: Colors.pillFg
            typeRole: "labelMedium"
        }
    }

    /* progress ring with a value inside and two lines of text underneath */
    component StatRing: Item {
        id: ring
        property real value: 0
        property string valueText
        property string label
        property string sub
        property bool bolt: false

        Layout.fillWidth: true
        Layout.preferredWidth: 0
        implicitHeight: 60 + 6 + ringLabel.implicitHeight + ringSub.implicitHeight

        Item {
            anchors.top: parent.top
            anchors.horizontalCenter: parent.horizontalCenter
            width: 60
            height: 60

            Canvas {
                id: canvas
                anchors.fill: parent
                readonly property color arcColor: Colors.accent
                readonly property color trackColor: Colors.pillTrack
                readonly property real shownValue: Math.max(0, Math.min(1, ring.value))
                onArcColorChanged: requestPaint()
                onTrackColorChanged: requestPaint()
                onShownValueChanged: requestPaint()
                onPaint: {
                    const ctx = getContext("2d");
                    ctx.reset();
                    const c = width / 2;
                    const r = c - 4;
                    ctx.lineWidth = 5;
                    ctx.lineCap = "round";
                    ctx.strokeStyle = trackColor;
                    ctx.beginPath();
                    ctx.arc(c, c, r, 0, Math.PI * 2);
                    ctx.stroke();
                    if (shownValue > 0.005) {
                        ctx.strokeStyle = arcColor;
                        ctx.beginPath();
                        ctx.arc(c, c, r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * shownValue);
                        ctx.stroke();
                    }
                }
            }

            Row {
                anchors.centerIn: parent
                spacing: 1

                StyledIcon {
                    visible: ring.bolt
                    anchors.verticalCenter: parent.verticalCenter
                    width: 11
                    height: 11
                    iconName: "lightning"
                    tint: Colors.pillFg
                }
                StyledText {
                    text: ring.valueText
                    wght: Typography.wEmph
                    textSize: Config.cfg.appearance.fontSize
                    color: Colors.pillFg
                    tabular: true
                }
            }
        }

        StyledText {
            id: ringLabel
            anchors.top: parent.top
            anchors.topMargin: 60 + 6
            anchors.horizontalCenter: parent.horizontalCenter
            text: ring.label
            wght: Typography.wEmph
            color: Colors.pillFg
        }
        StyledText {
            id: ringSub
            anchors.top: ringLabel.bottom
            anchors.horizontalCenter: parent.horizontalCenter
            text: ring.sub
            color: Colors.pillSubtle
            textSize: root.smallFont - 1
        }
    }

    implicitWidth: 516
    bgAlpha: 0.98
    implicitHeight: content.implicitHeight + 30
    radius: 0
    dropShadow: false
    color: "transparent"
    border.width: 0

    onShownChanged: {
        if (shown) {
            NotiServer.unread = 0;
            Brightness.refresh();
        }
    }

    Timer {
        running: root.shown && root.playing
        interval: 1000
        repeat: true
        onTriggered: root.player.positionChanged()
    }

    Timer {
        running: root.shown
        interval: 2000
        repeat: true
        triggeredOnStart: true
        onTriggered: SysInfo.refresh()
    }

    ColumnLayout {
        id: content
        anchors.fill: parent
        anchors.margins: 15
        spacing: 12

        /* header: date + uptime, quick actions */
        RowLayout {
            Layout.fillWidth: true
            Layout.leftMargin: 6
            spacing: 2

            ColumnLayout {
                spacing: 0

                StyledText {
                    text: Qt.formatDate(clock.date, "dddd, d MMMM")
                    wght: Typography.wEmph
                    textSize: Config.cfg.appearance.fontSize + 2
                    color: Colors.pillFg
                }
                StyledText {
                    text: root.uptimeText(SysInfo.uptime)
                    color: Colors.pillSubtle
                    textSize: root.smallFont
                }
            }
            Item {
                Layout.fillWidth: true
            }

            HeaderButton {
                iconName: "apple-logo"
                onClicked: Config.cfg.appearance.controlStyle = "macos"
            }
            HeaderButton {
                iconName: "palette"
                onClicked: Island.page = "themes"
            }
            HeaderButton {
                iconName: "image-square"
                onClicked: Island.page = "walls"
            }
            HeaderButton {
                iconName: "game-controller"
                active: Toggles.gameMode
                onClicked: Toggles.gameMode = !Toggles.gameMode
            }
            HeaderButton {
                iconName: "lock"
                onClicked: Toggles.lock()
            }
            HeaderButton {
                iconName: "power"
                highlighted: true
                onClicked: Island.page = "power"
            }
        }

        SliderPill {
            visible: Brightness.available
            iconName: "sun-dim"
            value: Brightness.value
            onMoved: v => Brightness.set(v)
        }

        SliderPill {
            visible: Audio.defaultAudio !== null
            iconName: Audio.defaultAudio ? Audio.getVolumeIcon(Audio.defaultAudio) : "speaker-none"
            value: Audio.defaultAudio?.audio.volume ?? 0
            onMoved: v => Audio.defaultAudio.audio.volume = v
            onIconClicked: Audio.defaultAudio.audio.muted = !Audio.defaultAudio.audio.muted
        }

        RowLayout {
            Layout.fillWidth: true
            spacing: 12

            Tile {
                iconName: Network.wifiEnabled ? "wifi-high" : "wifi-slash"
                title: "Wi-Fi"
                subtitle: Network.connectedNet?.name ?? (Network.wifiEnabled ? "Not connected" : "Off")
                active: Network.wifiEnabled
                onClicked: Network.toggleWifi()
            }
            Tile {
                iconName: !Bt.enabled ? "bluetooth-slash" : (Bt.device ? "bluetooth-connected" : "bluetooth")
                title: "Bluetooth"
                subtitle: Bt.enabled ? (Bt.device?.name ?? "On") : "Off"
                active: Bt.enabled
                onClicked: Bt.toggle()
            }
        }

        Rectangle {
            Layout.fillWidth: true
            implicitHeight: toggleGrid.implicitHeight + 28
            radius: 22
            color: Colors.pillCard
            border.width: 1
            border.color: Colors.pillLine

            GridLayout {
                id: toggleGrid
                anchors.fill: parent
                anchors.margins: 14
                columns: 6
                rowSpacing: 14
                columnSpacing: 0
                uniformCellWidths: true

                Toggle {
                    iconName: "minus-circle"
                    label: "Silence"
                    active: NotiServer.dnd
                    onClicked: NotiServer.dnd = !NotiServer.dnd
                }
                Toggle {
                    iconName: "coffee"
                    label: "Awake"
                    active: Toggles.caffeine
                    onClicked: Toggles.caffeine = !Toggles.caffeine
                }
                Toggle {
                    iconName: "moon"
                    label: "Night"
                    active: Toggles.nightLight
                    onClicked: Toggles.nightLight = !Toggles.nightLight
                }
                Toggle {
                    iconName: "airplane-tilt"
                    label: "Airplane"
                    active: Toggles.airplane
                    onClicked: Toggles.toggleAirplane()
                }
                Toggle {
                    iconName: "folder-open"
                    label: "Files"
                    onClicked: {
                        Island.dismiss();
                        Quickshell.execDetached(["xdg-open", Quickshell.env("HOME")]);
                    }
                }
                Toggle {
                    iconName: Audio.micMuted ? "microphone-slash" : "microphone"
                    label: "Mic"
                    active: Audio.micMuted
                    onClicked: Audio.toggleMic()
                }

                Toggle {
                    iconName: "selection-plus"
                    label: "Capture"
                    onClicked: {
                        Island.dismiss();
                        Toggles.capture();
                    }
                }
                Toggle {
                    iconName: Toggles.recording ? "stop-circle" : "record"
                    label: Toggles.recording ? "Stop" : "Record"
                    active: Toggles.recording
                    onClicked: {
                        Island.dismiss();
                        Toggles.toggleRecording();
                    }
                }
                Toggle {
                    iconName: "eyedropper"
                    label: "Picker"
                    onClicked: {
                        Island.dismiss();
                        Quickshell.execDetached(["hyprpicker", "-a"]);
                    }
                }
                Toggle {
                    iconName: "keyboard"
                    label: "Keyboard"
                    onClicked: Quickshell.execDetached(["hyprctl", "switchxkblayout", "all", "next"])
                }
                Toggle {
                    iconName: "timer"
                    label: Toggles.timerLeft > 0 ? Toggles.timerText : "Timer"
                    active: Toggles.timerLeft > 0
                    onClicked: Toggles.toggleTimer()
                }
                Toggle {
                    iconName: "power"
                    label: "Session"
                    onClicked: Island.page = "power"
                }
            }
        }

        ClippingRectangle {
            id: media
            Layout.fillWidth: true
            visible: root.player !== null
            implicitHeight: mediaCol.implicitHeight + 28
            radius: 22
            color: Colors.pillCard2
            border.width: 1
            border.color: Colors.pillLine

            Image {
                anchors.fill: parent
                visible: root.artUrl !== ""
                source: root.artUrl
                fillMode: Image.PreserveAspectCrop
                asynchronous: true
                opacity: status === Image.Ready ? 0.28 : 0
                layer.enabled: root.artUrl !== ""
                layer.effect: MultiEffect {
                    blurEnabled: true
                    blur: 1.0
                    blurMax: 48
                    saturation: 0.3
                }
                Behavior on opacity {
                    NumberAnimation {
                        duration: 300
                    }
                }
            }

            ColumnLayout {
                id: mediaCol
                anchors.fill: parent
                anchors.margins: 14
                spacing: 12

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 12

                    ClippingRectangle {
                        Layout.preferredWidth: 64
                        Layout.preferredHeight: 64
                        Layout.alignment: Qt.AlignVCenter
                        radius: 14
                        color: Colors.pillCircle
                        border.width: 1
                        border.color: Colors.alpha(Colors.pillFg, 0.08)

                        Image {
                            anchors.fill: parent
                            source: root.artUrl
                            fillMode: Image.PreserveAspectCrop
                            asynchronous: true
                            opacity: status === Image.Ready ? 1 : 0
                            Behavior on opacity {
                                NumberAnimation {
                                    duration: 250
                                }
                            }
                        }
                        StyledIcon {
                            anchors.centerIn: parent
                            width: 26
                            height: 26
                            visible: root.artUrl === ""
                            iconName: "music-notes"
                            tint: Colors.pillMuted
                        }
                    }

                    ColumnLayout {
                        Layout.fillWidth: true
                        Layout.preferredWidth: 0
                        Layout.alignment: Qt.AlignVCenter
                        spacing: 1

                        StyledText {
                            Layout.fillWidth: true
                            text: root.player?.trackTitle || "Nothing playing"
                            wght: Typography.wEmph
                            textSize: Config.cfg.appearance.fontSize + 1
                            elide: Text.ElideRight
                        }
                        StyledText {
                            Layout.fillWidth: true
                            visible: text !== ""
                            text: root.player?.trackArtists ?? ""
                            color: Colors.pillSubtle
                            textSize: Config.cfg.appearance.fontSize - 1
                            elide: Text.ElideRight
                        }
                    }

                    RowLayout {
                        Layout.alignment: Qt.AlignVCenter
                        spacing: 6

                        MediaButton {
                            iconName: "skip-back"
                            enabled: root.player?.canGoPrevious ?? false
                            onClicked: root.player.previous()
                        }
                        MediaButton {
                            primary: true
                            iconName: root.playing ? "pause" : "play"
                            enabled: root.player?.canTogglePlaying ?? false
                            onClicked: root.player.togglePlaying()
                        }
                        MediaButton {
                            iconName: "skip-forward"
                            enabled: root.player?.canGoNext ?? false
                            onClicked: root.player.next()
                        }
                    }
                }

                Item {
                    id: seek
                    Layout.fillWidth: true
                    visible: root.hasLength
                    implicitHeight: 16

                    Rectangle {
                        id: track
                        anchors.verticalCenter: parent.verticalCenter
                        width: parent.width
                        height: seekArea.containsMouse || seekArea.pressed ? 6 : 4
                        radius: height / 2
                        color: Colors.pillTrack
                        Behavior on height {
                            NumberAnimation {
                                duration: 100
                            }
                        }

                        Rectangle {
                            width: parent.width * root.shownProgress
                            height: parent.height
                            radius: parent.radius
                            color: Colors.accent
                        }
                        Rectangle {
                            x: parent.width * root.shownProgress - width / 2
                            anchors.verticalCenter: parent.verticalCenter
                            width: 12
                            height: 12
                            radius: 6
                            color: Colors.pillFg
                            visible: root.canSeek
                            opacity: seekArea.containsMouse || seekArea.pressed ? 1 : 0
                            Behavior on opacity {
                                NumberAnimation {
                                    duration: 120
                                }
                            }
                        }
                    }

                    MouseArea {
                        id: seekArea
                        anchors.fill: parent
                        enabled: root.canSeek
                        hoverEnabled: true
                        cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
                        function ratioAt(x) {
                            return Math.max(0, Math.min(1, x / width));
                        }
                        onPressed: mouse => root.dragRatio = ratioAt(mouse.x)
                        onPositionChanged: mouse => {
                            if (pressed)
                                root.dragRatio = ratioAt(mouse.x);
                        }
                        onReleased: mouse => {
                            if (root.canSeek)
                                root.player.position = ratioAt(mouse.x) * root.player.length;
                            root.dragRatio = -1;
                        }
                        onCanceled: root.dragRatio = -1
                    }
                }
            }
        }

        /* system stats */
        Rectangle {
            Layout.fillWidth: true
            implicitHeight: statRow.implicitHeight + 32
            radius: 22
            color: Colors.pillCard2
            border.width: 1
            border.color: Colors.pillLine

            RowLayout {
                id: statRow
                anchors.fill: parent
                anchors.margins: 16
                anchors.leftMargin: 10
                anchors.rightMargin: 10
                spacing: 0

                StatRing {
                    value: SysInfo.cpu
                    valueText: Math.round(SysInfo.cpu * 100)
                    label: "CPU"
                    sub: SysInfo.temp >= 0 ? Math.round(SysInfo.temp) + " °C" : " "
                }
                StatRing {
                    value: SysInfo.ram
                    valueText: Math.round(SysInfo.ram * 100)
                    label: "Memory"
                    sub: SysInfo.ramUsed.toFixed(1) + " GB"
                }
                StatRing {
                    value: SysInfo.disk
                    valueText: Math.round(SysInfo.disk * 100)
                    label: "Disk"
                    sub: Math.round(SysInfo.diskFree) + " GB free"
                }
                StatRing {
                    visible: root.hasBattery
                    value: root.battery.percentage
                    valueText: Math.round(root.battery.percentage * 100)
                    label: root.charging ? "Charging" : "Battery"
                    sub: root.charging ? "charging" : "on battery"
                    bolt: root.charging
                }
            }
        }

        Rectangle {
            Layout.fillWidth: true
            implicitHeight: notiCol.implicitHeight + 34
            radius: 22
            color: Colors.pillCard2
            border.width: 1
            border.color: Colors.pillLine

            ColumnLayout {
                id: notiCol
                anchors.fill: parent
                anchors.leftMargin: 11
                anchors.rightMargin: 11
                anchors.topMargin: 10
                anchors.bottomMargin: 24
                spacing: 8

                RowLayout {
                    Layout.fillWidth: true
                    Layout.leftMargin: 3
                    Layout.rightMargin: 3

                    StyledText {
                        text: "Notifications"
                        color: Colors.pillSubtle
                        textSize: root.smallFont - 1
                    }
                    Item {
                        Layout.fillWidth: true
                    }
                    StyledText {
                        visible: NotiServer.history.length > 0
                        text: "Clear all"
                        color: clearArea.containsMouse ? Colors.accent : Colors.pillSubtle
                        textSize: root.smallFont - 1
                        MouseArea {
                            id: clearArea
                            anchors.fill: parent
                            anchors.margins: -4
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: NotiServer.history = []
                        }
                    }
                }

                Repeater {
                    model: NotiServer.history.slice(0, 3)

                    delegate: Rectangle {
                        id: entry
                        required property int index
                        required property var modelData
                        readonly property string iconSource: modelData.image ? modelData.image : (modelData.appIcon ? Quickshell.iconPath(modelData.appIcon, true) : "")

                        Layout.fillWidth: true
                        Layout.preferredHeight: 67
                        radius: 14
                        color: Colors.pillCard
                        border.width: 1
                        border.color: Colors.pillLine

                        Rectangle {
                            id: avatar
                            x: 11
                            anchors.verticalCenter: parent.verticalCenter
                            width: 32
                            height: 32
                            radius: 16
                            color: Colors.alpha(Colors.accent, 0.2)

                            IconImage {
                                anchors.centerIn: parent
                                visible: entry.iconSource !== ""
                                implicitSize: 22
                                source: entry.iconSource
                            }
                            StyledText {
                                anchors.centerIn: parent
                                visible: entry.iconSource === ""
                                text: (entry.modelData.appName || "?").charAt(0).toUpperCase()
                                color: Colors.accent
                                wght: Typography.wEmph
                                textSize: root.smallFont
                            }
                        }

                        ColumnLayout {
                            anchors.left: avatar.right
                            anchors.leftMargin: 9
                            anchors.right: closeBtn.left
                            anchors.rightMargin: 6
                            anchors.verticalCenter: parent.verticalCenter
                            spacing: 0

                            StyledText {
                                Layout.fillWidth: true
                                text: entry.modelData.appName
                                color: Colors.pillSubtle
                                textSize: root.smallFont - 1
                                elide: Text.ElideRight
                            }
                            StyledText {
                                Layout.fillWidth: true
                                text: entry.modelData.summary
                                wght: Typography.wEmph
                                color: Colors.pillFg
                                elide: Text.ElideRight
                            }
                            StyledText {
                                Layout.fillWidth: true
                                text: entry.modelData.body
                                visible: text !== ""
                                color: Colors.pillSubtle
                                textSize: root.smallFont - 1
                                elide: Text.ElideRight
                                maximumLineCount: 1
                            }
                        }

                        Item {
                            id: closeBtn
                            anchors.right: parent.right
                            anchors.rightMargin: 12
                            y: 10
                            width: 20
                            height: 20

                            StyledIcon {
                                anchors.centerIn: parent
                                width: 12
                                height: 12
                                iconName: "x"
                                fill: false
                                tint: closeArea.containsMouse ? Colors.pillFg : Colors.pillMuted
                            }
                            MouseArea {
                                id: closeArea
                                anchors.fill: parent
                                hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor
                                onClicked: NotiServer.history = NotiServer.history.filter((_, i) => i !== entry.index)
                            }
                        }
                    }
                }

                RowLayout {
                    Layout.alignment: Qt.AlignHCenter
                    Layout.topMargin: 6
                    Layout.bottomMargin: -8
                    visible: NotiServer.history.length === 0
                    spacing: 8

                    StyledIcon {
                        iconName: "bell-simple-slash"
                        fill: false
                        tint: Colors.pillMuted
                    }
                    StyledText {
                        text: "You're all caught up"
                        color: Colors.pillMuted
                    }
                }
            }
        }
    }
}
