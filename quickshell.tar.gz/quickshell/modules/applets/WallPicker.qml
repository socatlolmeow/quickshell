pragma ComponentBehavior: Bound
import Quickshell.Widgets
import QtQuick
import QtQuick.Effects

import qs
import qs.settings
import qs.widgets
import qs.modules.Services

// Android / Material You stijl wallpaper kiezer
Item {
    id: root

    // wordt door WallpaperWindow gezet
    property bool open: false
    property alias sheetOpacity: sheet.opacity
    readonly property int columns: 3
    readonly property int pad: 24
    readonly property int gap: 12
    property bool creating: false

    onOpenChanged: {
        if (!open)
            creating = false;
    }
    onCreatingChanged: {
        if (creating) {
            nameInput.text = "";
            nameInput.forceActiveFocus();
        } else {
            nameInput.focus = false;
        }
    }

    WallFolders {
        id: folders
    }

    Connections {
        target: folders
        function onDirChanged() {
            grid.contentY = 0;
        }
    }

    component RoundButton: Rectangle {
        id: btn
        property string iconName
        property bool active: false
        signal clicked

        width: 44
        height: 44
        radius: 22
        color: active ? Colors.accent : (btnMouse.containsMouse ? Colors.overlay : Colors.alpha(Colors.overlay, 0.6))

        Behavior on color {
            ColorAnimation { duration: 120 }
        }

        StyledIcon {
            anchors.centerIn: parent
            iconName: btn.iconName
            fill: false
            width: 20
            height: 20
            tint: btn.active ? Colors.bg : Colors.font
        }

        MouseArea {
            id: btnMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: btn.clicked()
        }
    }

    Rectangle {
        id: sheet
        anchors.fill: parent
        transformOrigin: Item.Bottom
        opacity: root.open ? 1 : 0
        scale: root.open ? 1 : 0.86

        Behavior on opacity {
            NumberAnimation {
                duration: root.open ? 200 : 140
                easing.type: Easing.OutCubic
            }
        }
        Behavior on scale {
            NumberAnimation {
                duration: root.open ? 380 : 140
                easing.type: root.open ? Easing.OutBack : Easing.OutCubic
                easing.overshoot: 0.8
            }
        }

        radius: 36                                   // grote Android-hoeken
        color: Colors.alpha(Colors.surface, 0.96)    // tonal surface
        border.width: 1
        border.color: Colors.alpha(Colors.overlay, 0.5)
        layer.enabled: true
        layer.effect: MultiEffect {
            shadowEnabled: true
            shadowColor: "black"
            shadowOpacity: 0.35
            shadowBlur: 1
            shadowVerticalOffset: 10
        }

        // vang kliks op zodat ze niet doorvallen
        MouseArea {
            anchors.fill: parent
            acceptedButtons: Qt.AllButtons
        }

        // drag handle (zoals een Android bottom sheet)
        Rectangle {
            id: handle
            anchors.top: parent.top
            anchors.topMargin: 10
            anchors.horizontalCenter: parent.horizontalCenter
            width: 36
            height: 4
            radius: 2
            color: Colors.alpha(Colors.subtle, 0.5)
        }

        // header
        Item {
            id: header
            anchors.top: handle.bottom
            anchors.topMargin: 14
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.leftMargin: root.pad + 4
            anchors.rightMargin: root.pad
            height: 56

            Row {
                anchors.verticalCenter: parent.verticalCenter
                spacing: 12

                RoundButton {
                    visible: !folders.atRoot
                    anchors.verticalCenter: parent.verticalCenter
                    iconName: "arrow-left"
                    onClicked: folders.up()
                }

                Column {
                    visible: !root.creating
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: 2

                    StyledText {
                        text: folders.atRoot ? "Achtergrond" : folders.title
                        textSize: 26
                        wght: Typography.wMedium
                        color: Colors.font
                    }
                    StyledText {
                        text: folders.model.count + " items"
                        textSize: Config.cfg.appearance.fontSize - 1
                        color: Colors.subtle
                    }
                }

                Rectangle {
                    visible: root.creating
                    anchors.verticalCenter: parent.verticalCenter
                    width: 340
                    height: 44
                    radius: 22
                    color: Colors.alpha(Colors.overlay, 0.6)
                    border.width: 1
                    border.color: Colors.alpha(Colors.accent, 0.7)

                    TextInput {
                        id: nameInput
                        anchors.fill: parent
                        anchors.leftMargin: 18
                        anchors.rightMargin: 18
                        verticalAlignment: TextInput.AlignVCenter
                        clip: true
                        color: Colors.font
                        selectionColor: Colors.accent
                        selectedTextColor: Colors.bg
                        font.family: Typography.family
                        font.pixelSize: Typography.fs(Config.cfg.appearance.fontSize + 2)
                        onAccepted: {
                            folders.createFolder(text);
                            root.creating = false;
                        }
                        Keys.onEscapePressed: root.creating = false
                    }
                    StyledText {
                        visible: nameInput.text === ""
                        anchors.left: parent.left
                        anchors.leftMargin: 18
                        anchors.verticalCenter: parent.verticalCenter
                        text: "Mapnaam…"
                        color: Colors.subtle
                    }
                }
            }

            Row {
                anchors.right: parent.right
                anchors.verticalCenter: parent.verticalCenter
                spacing: 8

                RoundButton {
                    iconName: "folder-plus"
                    active: root.creating
                    onClicked: root.creating = !root.creating
                }
                RoundButton {
                    iconName: "x"
                    onClicked: WidgetTracker.close()
                }
            }
        }

        GridView {
            id: grid
            anchors.top: header.bottom
            anchors.topMargin: 12
            anchors.bottom: parent.bottom
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.leftMargin: root.pad - root.gap / 2
            anchors.rightMargin: root.pad - root.gap / 2
            anchors.bottomMargin: root.pad - root.gap / 2
            clip: true
            boundsBehavior: Flickable.StopAtBounds
            model: folders.model
            cellWidth: Math.floor(width / root.columns)
            cellHeight: Math.round(cellWidth * 10 / 16)

            delegate: Item {
                id: cell
                required property var modelData
                readonly property bool isDir: modelData.fileIsDir
                readonly property bool current: !isDir && modelData.filePath === Config.cfg.wallpaper.wallpaper

                width: grid.cellWidth
                height: grid.cellHeight

                ClippingRectangle {
                    id: tile
                    anchors.fill: parent
                    anchors.margins: root.gap / 2
                    radius: cell.current ? 22 : 26
                    color: Colors.overlay
                    border.width: cell.current ? 3 : 0
                    border.color: Colors.accent

                    Behavior on radius {
                        NumberAnimation { duration: 180; easing.type: Easing.OutCubic }
                    }

                    Image {
                        visible: !cell.isDir
                        anchors.fill: parent
                        anchors.margins: cell.current ? 4 : 0
                        source: cell.isDir ? "" : cell.modelData.filePath
                        sourceSize.width: 640
                        sourceSize.height: 400
                        fillMode: Image.PreserveAspectCrop
                        asynchronous: true
                        cache: true
                        scale: tileMouse.containsMouse ? 1.05 : 1.0

                        Behavior on scale {
                            NumberAnimation { duration: 220; easing.type: Easing.OutCubic }
                        }
                    }

                    Column {
                        visible: cell.isDir
                        anchors.centerIn: parent
                        width: parent.width - 24
                        spacing: 8

                        StyledIcon {
                            anchors.horizontalCenter: parent.horizontalCenter
                            iconName: "folder"
                            width: 56
                            height: 56
                            tint: Colors.accent
                        }
                        StyledText {
                            width: parent.width
                            text: cell.modelData.fileName
                            color: Colors.font
                            horizontalAlignment: Text.AlignHCenter
                            elide: Text.ElideRight
                        }
                    }

                    // state layer bij hover (Material ripple-achtig)
                    Rectangle {
                        anchors.fill: parent
                        color: Colors.alpha(Colors.font, tileMouse.pressed ? 0.16 : tileMouse.containsMouse ? 0.08 : 0)
                        Behavior on color {
                            ColorAnimation { duration: 120 }
                        }
                    }

                    // check badge rechtsboven
                    Rectangle {
                        visible: cell.current
                        anchors.top: parent.top
                        anchors.right: parent.right
                        anchors.margins: 12
                        width: 28
                        height: 28
                        radius: 14
                        color: Colors.accent

                        StyledIcon {
                            anchors.centerIn: parent
                            iconName: "check"
                            fill: false
                            width: 18
                            height: 18
                            tint: Colors.bg
                        }
                    }

                    MouseArea {
                        id: tileMouse
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        acceptedButtons: Qt.LeftButton
                        hoverEnabled: true
                        onClicked: {
                            if (cell.isDir) {
                                folders.dir = cell.modelData.filePath;
                            } else {
                                Config.cfg.wallpaper.wallpaper = cell.modelData.filePath;
                                Config.save();
                            }
                        }
                    }
                }
            }
        }
    }
}
