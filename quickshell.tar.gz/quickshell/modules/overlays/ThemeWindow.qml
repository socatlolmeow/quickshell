import Quickshell
import Quickshell.Wayland
import QtQuick
import qs.modules.Services
import qs.modules.applets

Variants {
    model: Quickshell.screens
    delegate: PanelWindow {
        id: win
        required property ShellScreen modelData
        readonly property bool open: WidgetTracker.current === "colors" && WidgetTracker.screen === modelData

        screen: modelData
        visible: open
        implicitWidth: themes.implicitWidth
        implicitHeight: themes.implicitHeight
        exclusionMode: ExclusionMode.Ignore
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.namespace: "qs-themes"
        WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

        onOpenChanged: {
            if (open)
                Qt.callLater(themes.focusSearch);
        }

        Shortcut {
            sequence: "Escape"
            enabled: win.open
            onActivated: WidgetTracker.close()
        }

        ThemeSwitcher {
            id: themes
        }
    }
}
