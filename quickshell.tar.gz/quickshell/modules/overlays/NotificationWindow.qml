import Quickshell
import Quickshell.Wayland
import QtQuick
import qs.settings
import qs.modules.Services
import qs.modules.notifications

Variants {
    id: root
    model: Config.cfg.island.banners ? [] : NotiServer.notifications

    function slotOf(n, list) {
        for (let i = 0; i < list.length; i++) {
            if (list[i] === n)
                return i;
        }
        return -1;
    }

    delegate: PanelWindow {
        id: win
        required property var modelData
        readonly property int maxShown: 5
        readonly property int cardGap: 6
        readonly property int barMargin: Config.cfg.bar.floating ? Config.cfg.bar.margin : 0
        readonly property int slot: root.slotOf(modelData, NotiServer.notifications)

        screen: Compositor.focusedScreen ?? Quickshell.screens[0]
        visible: slot >= 0 && slot < maxShown
        anchors {
            top: true
            right: true
        }
        margins.top: barMargin + slot * (card.implicitHeight + cardGap)
        margins.right: Math.max(barMargin, 8)
        implicitWidth: card.implicitWidth
        implicitHeight: card.implicitHeight
        exclusionMode: ExclusionMode.Ignore
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.namespace: "qs-notifications"
        WlrLayershell.keyboardFocus: WlrKeyboardFocus.None

        NotiCard {
            id: card
            anchors.fill: parent
            notification: win.modelData
            nScreen: win.screen
        }
    }
}
