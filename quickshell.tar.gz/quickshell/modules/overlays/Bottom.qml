import Quickshell.Wayland
import Quickshell
import QtQuick
import qs.settings

Variants {
    model: Quickshell.screens
    delegate: WlrLayershell {
        id: root
        layer: WlrLayer.Background
        namespace: "qs-wallpaper"
        required property ShellScreen modelData
        screen: modelData
        exclusionMode: ExclusionMode.Ignore

        anchors {
            top: true
            bottom: true
            left: true
            right: true
        }
        Image {
            cache: false
            asynchronous: true
            anchors.fill: parent
            fillMode: Image.PreserveAspectCrop
            sourceSize: Qt.size(root.modelData.width * root.modelData.devicePixelRatio, root.modelData.height * root.modelData.devicePixelRatio)
            source: Config.cfg.wallpaper.wallpaper !== "" ? Qt.resolvedUrl(Config.cfg.wallpaper.wallpaper) : ""
        }
    }
}
