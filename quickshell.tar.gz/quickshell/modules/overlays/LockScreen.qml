import Quickshell
import Quickshell.Io
import Quickshell.Widgets
import Quickshell.Wayland
import Quickshell.Services.Pam
import Quickshell.Services.UPower
import QtQuick
import QtQuick.Effects

import qs
import qs.settings
import qs.widgets
import qs.modules.Services

// macOS-style lock screen (Sonoma / Sequoia / Tahoe layout):
//   date + big clock at the top, user picture + name + password field at the bottom,
//   wifi / battery status top-right, sharp wallpaper that blurs once you start typing.
//
//   qs ipc call lock lock      -> lock
//   qs ipc call lock unlock    -> EMERGENCY EXIT (see note below)
Scope {
    id: root

    // PAM service name. "login" always exists on NixOS.
    readonly property string pamService: "login"

    // macOS has no media controls on the lock screen. Flip to true to get the old media card back.
    readonly property bool showMedia: false

    property string buffer: ""
    property bool failed: false
    property int failCount: 0
    readonly property string userName: Quickshell.env("USER")
    readonly property string facePath: Quickshell.env("HOME") + "/.face"
    readonly property bool typing: buffer.length > 0 || pam.active || failed

    readonly property real length: Media.player?.lengthSupported ? Media.player.length : 0
    readonly property real progress: length > 0 ? Math.min(Math.max(Media.player.position / length, 0), 1) : 0

    function fmt(seconds) {
        const s = Math.max(0, Math.floor(seconds));
        const r = s % 60;
        return Math.floor(s / 60) + ":" + (r < 10 ? "0" : "") + r;
    }

    function submit() {
        if (buffer.length === 0 || pam.active)
            return;
        failed = false;
        pam.start();
    }

    function wifiIcon() {
        if (!Network.wifiEnabled || !(Network.wifiDev?.connected ?? false))
            return "wifi-slash";
        const s = Network.connectedNet?.signalStrength ?? 1;
        return s <= 0.25 ? "wifi-none" : s <= 0.5 ? "wifi-low" : s <= 0.75 ? "wifi-medium" : "wifi-high";
    }

    function batteryIcon() {
        const p = UPower.displayDevice.percentage * 100;
        if (UPower.displayDevice.state === UPowerDeviceState.Charging)
            return "battery-charging";
        if (p <= 15)
            return "battery-warning";
        if (p <= 40)
            return "battery-low";
        if (p <= 65)
            return "battery-medium";
        if (p <= 85)
            return "battery-high";
        return "battery-full";
    }

    SystemClock {
        id: clock
        precision: SystemClock.Minutes
    }

    Timer {
        running: sessionLock.locked && root.showMedia && Media.playing
        interval: 1000
        repeat: true
        onTriggered: Media.player.positionChanged()
    }

    /* text with the bundled variable font wired up */
    component LText: Text {
        id: lt
        property int px: 14
        property int wght: Typography.wBody
        property int rond: 0
        // soft shadow so light text stays readable on bright wallpapers
        property bool lift: false
        color: Qt.rgba(1, 1, 1, 0.9)
        layer.enabled: lift
        layer.effect: MultiEffect {
            shadowEnabled: true
            shadowColor: "black"
            shadowOpacity: 0.28
            shadowBlur: 0.9
            shadowVerticalOffset: 2
        }
        font.family: Typography.family
        font.pixelSize: px
        font.weight: Typography.weightEnum(wght)
        font.variableAxes: Typography.axes(px, wght, rond)
        renderType: Text.NativeRendering
    }

    /* Liquid-glass surface: the wallpaper behind it is refracted through a curved glass bezel by assets/shaders/liquidglass.frag
     * (blur, dispersion, specular rim, drop shadow all happen in the shader).
     * Must be a DIRECT child of the lock scene so its x/y line up with the wallpaper. */
    component Glass: Item {
        id: g
        property Item backdrop
        property real bleed: 0
        property real radius: height / 2
        property real tint: 0.10
        property real thickness: 12
        property real blur: 7
        default property alias content: slot.data

        readonly property real pad: 10
        readonly property real reach: 72

        Rectangle {
            anchors.fill: parent
            radius: g.radius
            visible: fx.status === ShaderEffect.Error
            color: Qt.rgba(1, 1, 1, 0.14)
            border.width: 1
            border.color: Qt.rgba(1, 1, 1, 0.28)
        }

        ShaderEffectSource {
            id: backdropTex
            sourceItem: g.backdrop
            visible: false
            mipmap: true
            sourceRect: Qt.rect(g.x + g.bleed - g.pad - g.reach, g.y + g.bleed - g.pad - g.reach,
                                g.width + 2 * (g.pad + g.reach), g.height + 2 * (g.pad + g.reach))
            textureSize: Qt.size(sourceRect.width, sourceRect.height)
        }

        ShaderEffect {
            id: fx
            x: -g.pad
            y: -g.pad
            width: g.width + 2 * g.pad
            height: g.height + 2 * g.pad
            fragmentShader: Qt.resolvedUrl("../../assets/shaders/liquidglass.frag.qsb")

            property variant src: backdropTex
            property vector2d itemSize: Qt.vector2d(width, height)
            property vector2d glassSize: Qt.vector2d(g.width, g.height)
            property vector2d srcSize: Qt.vector2d(backdropTex.sourceRect.width, backdropTex.sourceRect.height)
            property vector2d srcOffset: Qt.vector2d(g.reach, g.reach)
            property real pad: g.pad
            property real radius: g.radius
            property real bezel: Math.min(g.height * 0.36, 26)
            property real thickness: g.thickness * 1.6
            property real dispersion: 0.04
            property real blurPx: g.blur
            property real tintMix: g.tint
            property real saturation: 1.25
            property real dark: 0
            property real debug: 0
            property real rim: 0.45
            property real grain: 0.006
            property real magnify: 0.03
            property real shadowAmt: 0.9
            property real rimTint: 0
            property real ringW: 0
            property real flatInner: 1
        }

        Item {
            id: slot
            anchors.fill: parent
        }
    }

    component MediaButton: Rectangle {
        id: button
        property string iconName
        property bool primary: false
        signal clicked

        width: primary ? 76 : 48
        height: 48
        radius: 24
        opacity: enabled ? 1 : 0.35
        scale: area.pressed ? 0.94 : 1
        color: primary ? Qt.rgba(1, 1, 1, 0.92) : (area.containsMouse ? Qt.rgba(1, 1, 1, 0.22) : Qt.rgba(1, 1, 1, 0.12))

        Behavior on scale {
            NumberAnimation { duration: 90 }
        }
        Behavior on color {
            ColorAnimation { duration: 120 }
        }

        StyledIcon {
            anchors.centerIn: parent
            width: button.primary ? 24 : 20
            height: width
            iconName: button.iconName
            tint: button.primary ? Qt.rgba(0, 0, 0, 0.8) : Qt.rgba(1, 1, 1, 0.95)
        }

        MouseArea {
            id: area
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: button.clicked()
        }
    }

    Process {
        id: power
        property string action: "suspend"
        command: ["loginctl", action]
    }

    function powerAction(name) {
        power.action = name;
        power.running = true;
    }

    IpcHandler {
        target: "lock"
        function lock() {
            WidgetTracker.close();
            root.buffer = "";
            root.failed = false;
            sessionLock.locked = true;
        }
        // Handy while testing from a TTY or over ssh. Remove this function once
        // everything works, otherwise any process of yours can unlock the screen.
        function unlock() {
            sessionLock.locked = false;
        }
    }

    Connections {
        target: Toggles
        function onLockRequested() {
            WidgetTracker.close();
            root.buffer = "";
            root.failed = false;
            sessionLock.locked = true;
        }
    }

    PamContext {
        id: pam
        config: root.pamService
        onPamMessage: {
            if (responseRequired)
                respond(root.buffer);
        }
        onCompleted: result => {
            if (result === PamResult.Success) {
                sessionLock.locked = false;
            } else {
                root.failed = true;
                root.failCount++;
            }
            root.buffer = "";
        }
    }

    WlSessionLock {
        id: sessionLock
        locked: false

        WlSessionLockSurface {
            id: surface
            color: "black"

            Item {
                id: scene
                anchors.fill: parent
                clip: true

                // fade in when the screen locks
                opacity: 0
                NumberAnimation on opacity {
                    from: 0
                    to: 1
                    duration: 450
                    easing.type: Easing.OutCubic
                }

                // click anywhere: focus the password field (like "press any key")
                MouseArea {
                    anchors.fill: parent
                    onPressed: input.forceActiveFocus()
                }

                /* the wallpaper is oversized by `bleed` so the blur never darkens the screen edges */
                Image {
                    id: wall
                    readonly property int bleed: 64
                    anchors.fill: parent
                    anchors.margins: -bleed
                    source: Config.cfg.wallpaper.wallpaper
                    fillMode: Image.PreserveAspectCrop
                    sourceSize: Qt.size(surface.width + bleed * 2, surface.height + bleed * 2)
                    visible: false
                }

                MultiEffect {
                    anchors.fill: wall
                    source: wall
                    autoPaddingEnabled: false
                    blurEnabled: true
                    blurMax: 64
                    // sharp until you start typing, then it melts into a frosted backdrop
                    blur: root.typing ? 0.6 : 0.0
                    saturation: root.typing ? 0.12 : 0.0
                    brightness: root.typing ? -0.04 : 0.0

                    Behavior on blur {
                        NumberAnimation { duration: 400; easing.type: Easing.OutCubic }
                    }
                    Behavior on saturation {
                        NumberAnimation { duration: 400; easing.type: Easing.OutCubic }
                    }
                    Behavior on brightness {
                        NumberAnimation { duration: 400; easing.type: Easing.OutCubic }
                    }
                }

                // soft vignettes keep the clock and the login stack readable on bright wallpapers
                Rectangle {
                    anchors.fill: parent
                    gradient: Gradient {
                        GradientStop { position: 0.0; color: "#38000000" }
                        GradientStop { position: 0.3; color: "#00000000" }
                        GradientStop { position: 0.62; color: "#00000000" }
                        GradientStop { position: 1.0; color: "#4d000000" }
                    }
                }

                Rectangle {
                    anchors.fill: parent
                    color: "black"
                    opacity: root.typing ? 0.16 : 0.0
                    Behavior on opacity {
                        NumberAnimation { duration: 400; easing.type: Easing.OutCubic }
                    }
                }

                /* ---- top: date + big clock ---- */
                Column {
                    anchors.top: parent.top
                    anchors.topMargin: Math.round(scene.height * 0.07)
                    anchors.horizontalCenter: parent.horizontalCenter
                    spacing: -Math.round(scene.height * 0.012)

                    LText {
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: Qt.formatDateTime(clock.date, "dddd d MMMM")
                        color: Qt.rgba(1, 1, 1, 0.88)
                        lift: true
                        px: Math.round(scene.height * 0.027)
                        wght: Typography.wStrong
                    }

                    LText {
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: Qt.formatDateTime(clock.date, "HH:mm")
                        color: Qt.rgba(1, 1, 1, 0.9)
                        lift: true
                        px: Math.round(scene.height * 0.15)
                        wght: Typography.wStrong
                        font.features: {
                            "tnum": 1,
                            "calt": 1,
                            "kern": 1
                        }
                    }
                }

                /* ---- top right: wifi + battery ---- */
                Row {
                    anchors.top: parent.top
                    anchors.topMargin: Math.round(scene.height * 0.022)
                    anchors.right: parent.right
                    anchors.rightMargin: 28
                    spacing: 14

                    StyledIcon {
                        width: 18
                        height: 18
                        iconName: root.wifiIcon()
                        tint: Qt.rgba(1, 1, 1, 0.92)
                    }
                    LText {
                        visible: UPower.displayDevice.isLaptopBattery
                        anchors.verticalCenter: parent.verticalCenter
                        text: Math.round(UPower.displayDevice.percentage * 100) + "%"
                        color: Qt.rgba(1, 1, 1, 0.92)
                        lift: true
                        px: 13
                        wght: Typography.wStrong
                    }
                    StyledIcon {
                        visible: UPower.displayDevice.isLaptopBattery
                        width: 20
                        height: 20
                        iconName: root.batteryIcon()
                        tint: Qt.rgba(1, 1, 1, 0.92)
                    }
                }

                /* ---- optional media card (off by default, macOS has none) ---- */
                Glass {
                    id: mediaCard
                    visible: root.showMedia && Media.player !== null
                    backdrop: wall
                    bleed: wall.bleed
                    radius: 28
                    anchors.horizontalCenter: parent.horizontalCenter
                    anchors.bottom: avatar.top
                    anchors.bottomMargin: 28
                    width: 400
                    height: mediaCol.implicitHeight + 40

                    Column {
                        id: mediaCol
                        anchors.centerIn: parent
                        width: parent.width - 40
                        spacing: 14

                        Row {
                            spacing: 14

                            ClippingRectangle {
                                width: 64
                                height: 64
                                radius: 14
                                color: Qt.rgba(1, 1, 1, 0.16)

                                Image {
                                    anchors.fill: parent
                                    source: Media.artUrl
                                    fillMode: Image.PreserveAspectCrop
                                    asynchronous: true
                                    visible: status === Image.Ready
                                }

                                StyledIcon {
                                    anchors.centerIn: parent
                                    width: 26
                                    height: 26
                                    visible: Media.artUrl === ""
                                    iconName: "music-notes"
                                    tint: Qt.rgba(1, 1, 1, 0.6)
                                }
                            }

                            Column {
                                width: parent.width - 78
                                anchors.verticalCenter: parent.verticalCenter
                                spacing: 2

                                LText {
                                    width: parent.width
                                    text: Media.title || "Nothing playing"
                                    color: Qt.rgba(1, 1, 1, 0.96)
                                    px: 16
                                    wght: Typography.wEmph
                                    elide: Text.ElideRight
                                }

                                LText {
                                    width: parent.width
                                    visible: text !== ""
                                    text: Media.player?.trackArtists ?? ""
                                    color: Qt.rgba(1, 1, 1, 0.68)
                                    px: 13
                                    elide: Text.ElideRight
                                }
                            }
                        }

                        Column {
                            width: parent.width
                            visible: root.length > 0
                            spacing: 4

                            Rectangle {
                                width: parent.width
                                height: 5
                                radius: 2.5
                                color: Qt.rgba(1, 1, 1, 0.2)

                                Rectangle {
                                    width: Math.max(parent.height, parent.width * root.progress)
                                    height: parent.height
                                    radius: parent.radius
                                    color: Qt.rgba(1, 1, 1, 0.9)
                                }
                            }

                            Item {
                                width: parent.width
                                height: elapsed.implicitHeight

                                LText {
                                    id: elapsed
                                    text: root.fmt(root.progress * root.length)
                                    color: Qt.rgba(1, 1, 1, 0.68)
                                    px: 12
                                }

                                LText {
                                    anchors.right: parent.right
                                    text: root.fmt(root.length)
                                    color: Qt.rgba(1, 1, 1, 0.68)
                                    px: 12
                                }
                            }
                        }

                        Row {
                            anchors.horizontalCenter: parent.horizontalCenter
                            spacing: 10

                            MediaButton {
                                iconName: "skip-back"
                                enabled: Media.player?.canGoPrevious ?? false
                                onClicked: Media.player.previous()
                            }

                            MediaButton {
                                primary: true
                                iconName: Media.playing ? "pause" : "play"
                                enabled: Media.player?.canTogglePlaying ?? false
                                onClicked: Media.toggle()
                            }

                            MediaButton {
                                iconName: "skip-forward"
                                enabled: Media.player?.canGoNext ?? false
                                onClicked: Media.player.next()
                            }
                        }
                    }
                }

                /* ---- bottom: sleep / restart / shut down, like the macOS login screen ---- */
                Row {
                    id: powerRow
                    anchors.horizontalCenter: parent.horizontalCenter
                    anchors.bottom: parent.bottom
                    anchors.bottomMargin: Math.round(scene.height * 0.045)
                    spacing: 28

                    Repeater {
                        model: [
                            {
                                icon: "moon",
                                label: "Sleep",
                                action: "suspend"
                            },
                            {
                                icon: "arrow-clockwise",
                                label: "Restart",
                                action: "reboot"
                            },
                            {
                                icon: "power",
                                label: "Shut Down",
                                action: "poweroff"
                            }
                        ]

                        delegate: Item {
                            id: btn
                            required property var modelData
                            width: 72
                            height: 60

                            MouseArea {
                                id: press
                                anchors.fill: parent
                                cursorShape: Qt.PointingHandCursor
                                onClicked: root.powerAction(btn.modelData.action)
                            }

                            Rectangle {
                                id: disc
                                anchors.horizontalCenter: parent.horizontalCenter
                                width: 36
                                height: 36
                                radius: 18
                                color: Qt.rgba(1, 1, 1, press.pressed ? 0.34 : 0.2)
                                border.width: 1
                                border.color: Qt.rgba(1, 1, 1, 0.22)

                                StyledIcon {
                                    anchors.centerIn: parent
                                    width: 17
                                    height: 17
                                    iconName: btn.modelData.icon
                                    tint: Qt.rgba(1, 1, 1, 0.95)
                                }
                            }

                            LText {
                                anchors.horizontalCenter: parent.horizontalCenter
                                anchors.bottom: parent.bottom
                                text: btn.modelData.label
                                color: Qt.rgba(1, 1, 1, 0.85)
                                lift: true
                                px: 12
                                wght: Typography.wMedium
                            }
                        }
                    }
                }

                /* ---- bottom: picture, name, password field ----
                 * Stacked with sibling anchors (not a Column) so every item is a direct child of the scene. */
                // reserved line so nothing jumps when the message appears
                LText {
                    id: errorLine
                    anchors.horizontalCenter: parent.horizontalCenter
                    anchors.bottom: powerRow.top
                    anchors.bottomMargin: Math.round(scene.height * 0.05)
                    height: 18
                    text: root.failed ? "Incorrect password" : ""
                    color: Qt.rgba(1, 1, 1, 0.85)
                    px: 13
                    wght: Typography.wMedium
                }

                Glass {
                    id: field
                    backdrop: wall
                    bleed: wall.bleed
                    anchors.horizontalCenter: parent.horizontalCenter
                    anchors.bottom: errorLine.top
                    anchors.bottomMargin: 10
                    width: 232
                    height: 36
                    tint: root.typing ? 0.2 : 0.14
                    scale: root.typing ? 1.02 : 1.0

                    Behavior on tint {
                        NumberAnimation { duration: 220 }
                    }
                    Behavior on scale {
                        NumberAnimation { duration: 300; easing.type: Easing.OutBack; easing.overshoot: 1.4 }
                    }

                    transform: Translate { id: shiftX }

                    SequentialAnimation {
                        id: shake
                        NumberAnimation { target: shiftX; property: "x"; to: -14; duration: 50 }
                        NumberAnimation { target: shiftX; property: "x"; to: 14; duration: 90 }
                        NumberAnimation { target: shiftX; property: "x"; to: -9; duration: 80 }
                        NumberAnimation { target: shiftX; property: "x"; to: 5; duration: 70 }
                        NumberAnimation { target: shiftX; property: "x"; to: 0; duration: 60 }
                    }

                    Connections {
                        target: root
                        function onFailCountChanged() {
                            shake.restart();
                        }
                    }

                    LText {
                        anchors.left: parent.left
                        anchors.leftMargin: 18
                        anchors.verticalCenter: parent.verticalCenter
                        visible: input.text.length === 0
                        text: pam.active ? "Checking…" : "Enter Password"
                        color: Qt.rgba(1, 1, 1, 0.66)
                        px: 14
                        wght: Typography.wMedium
                    }

                    TextInput {
                        id: input
                        anchors.fill: parent
                        anchors.leftMargin: 18
                        anchors.rightMargin: 44
                        verticalAlignment: TextInput.AlignVCenter
                        echoMode: TextInput.Password
                        passwordCharacter: "●"
                        color: Qt.rgba(1, 1, 1, 0.96)
                        selectionColor: Qt.rgba(1, 1, 1, 0.35)
                        font.family: Typography.family
                        font.pixelSize: 14
                        font.weight: Typography.weightEnum(Typography.wMedium)
                        font.variableAxes: Typography.axes(14, Typography.wMedium, 0)
                        clip: true
                        focus: true
                        text: root.buffer
                        onTextEdited: {
                            root.buffer = text;
                            root.failed = false;
                        }
                        onAccepted: root.submit()
                        Keys.onEscapePressed: root.buffer = ""
                        Component.onCompleted: forceActiveFocus()
                    }

                    // submit arrow, appears once there is something to submit
                    Rectangle {
                        anchors.right: parent.right
                        anchors.rightMargin: 6
                        anchors.verticalCenter: parent.verticalCenter
                        width: 26
                        height: 26
                        radius: 13
                        color: Qt.rgba(1, 1, 1, 0.92)
                        opacity: root.buffer.length > 0 && !pam.active ? 1 : 0
                        scale: opacity > 0 ? 1 : 0.7
                        visible: opacity > 0

                        Behavior on opacity {
                            NumberAnimation { duration: 140 }
                        }
                        Behavior on scale {
                            NumberAnimation { duration: 140; easing.type: Easing.OutBack }
                        }

                        StyledIcon {
                            anchors.centerIn: parent
                            iconName: "arrow-right"
                            fill: false
                            width: 15
                            height: 15
                            tint: Qt.rgba(0, 0, 0, 0.8)
                        }

                        MouseArea {
                            anchors.fill: parent
                            cursorShape: Qt.PointingHandCursor
                            onClicked: root.submit()
                        }
                    }
                }

                LText {
                    id: nameText
                    anchors.horizontalCenter: parent.horizontalCenter
                    anchors.bottom: field.top
                    anchors.bottomMargin: 14
                    text: root.userName
                    color: Qt.rgba(1, 1, 1, 0.95)
                    lift: true
                    px: 18
                    wght: Typography.wStrong
                }

                ClippingRectangle {
                    id: avatar
                    anchors.horizontalCenter: parent.horizontalCenter
                    anchors.bottom: nameText.top
                    anchors.bottomMargin: 10
                    width: 78
                    height: 78
                    radius: 39
                    color: Qt.rgba(1, 1, 1, 0.26)

                    Image {
                        id: face
                        anchors.fill: parent
                        source: "file://" + root.facePath
                        fillMode: Image.PreserveAspectCrop
                        asynchronous: true
                        visible: status === Image.Ready
                    }

                    LText {
                        anchors.centerIn: parent
                        visible: face.status !== Image.Ready
                        text: root.userName.length > 0 ? root.userName.charAt(0).toUpperCase() : "?"
                        color: Qt.rgba(1, 1, 1, 0.95)
                        px: 36
                        wght: Typography.wMedium
                    }
                }
            }
        }
    }
}
