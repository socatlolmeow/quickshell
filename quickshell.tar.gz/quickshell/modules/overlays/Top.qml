import QtQuick
import Quickshell
import Quickshell.Wayland
import qs.modules.Services

Variants {
    model: Quickshell.screens
    delegate: PanelWindow {
        id: root
        required property ShellScreen modelData

        screen: modelData
        visible: WidgetTracker.current !== "" && WidgetTracker.screen === modelData
        anchors {
            top: true
            left: true
            bottom: true
            right: true
        }
        exclusionMode: ExclusionMode.Ignore
        color: "transparent"
        aboveWindows: true
        WlrLayershell.namespace: "qs-overlay"
        WlrLayershell.keyboardFocus: WlrKeyboardFocus.None

        MouseArea {
            anchors.fill: parent
            acceptedButtons: Qt.AllButtons
            onClicked: WidgetTracker.close()
        }
    }
}
