import Quickshell
import Quickshell.Wayland
import QtQuick
import qs.modules.Services
import qs.modules.applets

Variants {
    model: Quickshell.screens
    delegate: PanelWindow {
        id: win
        required property ShellScreen modelData
        readonly property bool open: WidgetTracker.current === "wallpapers" && WidgetTracker.screen === modelData

        screen: modelData
        visible: open || picker.sheetOpacity > 0
        anchors.bottom: true
        margins.bottom: 30
        implicitWidth: Math.min(980, modelData.width - 60)
        implicitHeight: Math.min(640, modelData.height - 120)
        exclusionMode: ExclusionMode.Ignore
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.namespace: "qs-wallpapers"
        WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

        Shortcut {
            sequence: "Escape"
            enabled: win.open
            onActivated: WidgetTracker.close()
        }

        WallPicker {
            id: picker
            anchors.fill: parent
            open: win.open
        }
    }
}
