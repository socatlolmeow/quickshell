import Quickshell
import Quickshell.Wayland
import QtQuick
import qs.settings
import qs.modules.Services
import qs.modules.applets

Variants {
    model: Quickshell.screens
    delegate: PanelWindow {
        id: win
        required property ShellScreen modelData
        readonly property bool open: WidgetTracker.current === "volume" && WidgetTracker.screen === modelData
        readonly property int barMargin: Config.cfg.bar.floating ? Config.cfg.bar.margin : 0

        screen: modelData
        visible: open
        anchors {
            top: true
            right: true
        }
        margins.top: barMargin + Config.cfg.bar.height + 8
        margins.right: Math.max(barMargin, 8)
        implicitWidth: popup.implicitWidth
        implicitHeight: popup.implicitHeight
        exclusionMode: ExclusionMode.Ignore
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.namespace: "qs-volume"
        WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

        Shortcut {
            sequence: "Escape"
            enabled: win.open
            onActivated: WidgetTracker.close()
        }

        VolPopup {
            id: popup
        }
    }
}
