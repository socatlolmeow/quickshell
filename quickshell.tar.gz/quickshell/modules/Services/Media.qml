pragma Singleton
import Quickshell
import Quickshell.Services.Mpris
import QtQuick

Singleton {
    id: root

    readonly property MprisPlayer player: {
        let first = null;
        for (const p of Mpris.players.values) {
            if (p.isPlaying)
                return p;
            if (!first)
                first = p;
        }
        return first;
    }
    readonly property bool playing: player?.isPlaying ?? false
    readonly property string artUrl: player?.trackArtUrl ?? ""
    readonly property string title: player?.trackTitle ?? ""
    readonly property string artist: player?.trackArtists ?? ""

    function toggle() {
        if (player?.canTogglePlaying)
            player.togglePlaying();
    }
    function next() {
        if (player?.canGoNext)
            player.next();
    }
    function previous() {
        if (player?.canGoPrevious)
            player.previous();
    }
}
