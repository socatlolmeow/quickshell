pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick

Singleton {
    id: root
    property real cpu: 0
    property real ramUsed: 0
    property real ramTotal: 0
    property real temp: -1
    property real uptime: 0
    property real diskTotal: 0
    property real diskFree: 0
    property string tempPath: ""
    readonly property real ram: ramTotal > 0 ? ramUsed / ramTotal : 0
    readonly property real disk: diskTotal > 0 ? 1 - diskFree / diskTotal : 0

    property real lastTotal: 0
    property real lastIdle: 0

    function refresh() {
        stat.reload();
        meminfo.reload();
        uptimeFile.reload();
        tempFile.reload();
        if (!diskProc.running)
            diskProc.running = true;

        const cpuLine = stat.text().split("\n")[0].trim().split(/\s+/).slice(1).map(Number);
        if (cpuLine.length >= 8) {
            const total = cpuLine.slice(0, 8).reduce((a, b) => a + b, 0);
            const idle = cpuLine[3] + cpuLine[4];
            if (lastTotal > 0 && total > lastTotal)
                cpu = 1 - (idle - lastIdle) / (total - lastTotal);
            lastTotal = total;
            lastIdle = idle;
        }

        const mem = meminfo.text();
        const total = mem.match(/MemTotal:\s+(\d+)/);
        const available = mem.match(/MemAvailable:\s+(\d+)/);
        if (total && available) {
            ramTotal = total[1] / 1048576;
            ramUsed = (total[1] - available[1]) / 1048576;
        }

        uptime = parseFloat(uptimeFile.text()) || 0;
        const raw = parseInt(tempFile.text());
        temp = isNaN(raw) ? -1 : raw / 1000;
    }

    FileView {
        id: stat
        path: "/proc/stat"
    }

    FileView {
        id: meminfo
        path: "/proc/meminfo"
    }

    FileView {
        id: uptimeFile
        path: "/proc/uptime"
    }

    FileView {
        id: tempFile
        path: root.tempPath
    }

    Process {
        running: true
        command: ["sh", "-c", "for d in /sys/class/hwmon/hwmon*; do case $(cat $d/name) in coretemp|k10temp|zenpower|cpu_thermal|acpitz) echo $d/temp1_input; break;; esac; done"]
        stdout: SplitParser {
            onRead: line => root.tempPath = line
        }
    }

    Process {
        id: diskProc
        command: ["df", "-B1", "--output=size,avail", "/"]
        stdout: SplitParser {
            onRead: line => {
                const f = line.trim().split(/\s+/);
                if (f.length === 2 && /^\d+$/.test(f[0])) {
                    root.diskTotal = Number(f[0]) / 1073741824;
                    root.diskFree = Number(f[1]) / 1073741824;
                }
            }
        }
    }
}
