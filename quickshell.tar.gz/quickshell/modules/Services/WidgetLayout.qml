pragma Singleton
import Quickshell
import QtQuick
import qs.settings

Singleton {
    id: root

    readonly property var sizes: ({
            clock: Qt.size(168, 168),
            calendar: Qt.size(358, 168),
            music: Qt.size(358, 168),
            weather: Qt.size(168, 168),
            system: Qt.size(358, 168),
            discord: Qt.size(358, 196)
        })
    readonly property real gap: 16
    readonly property real edge: 20
    readonly property real top: 60

    property string dragKey: ""
    property real dragX: 0
    property real dragY: 0

    readonly property var home: Quickshell.screens[Math.min(Config.cfg.widgets.monitor, Quickshell.screens.length - 1)] ?? null

    function clamp(v, lo, hi) {
        return Math.max(lo, Math.min(v, Math.max(lo, hi)));
    }

    function screenNamed(name) {
        for (const s of Quickshell.screens) {
            if (s.name === name)
                return s;
        }
        return null;
    }

    function screenAt(x, y) {
        let best = null;
        let bestDist = Infinity;
        for (const s of Quickshell.screens) {
            const dx = Math.max(s.x - x, 0, x - (s.x + s.width));
            const dy = Math.max(s.y - y, 0, y - (s.y + s.height));
            const dist = dx * dx + dy * dy;
            if (dist < bestDist) {
                best = s;
                bestDist = dist;
            }
        }
        return best;
    }

    function fallback(key, scr) {
        const colX = scr.width - edge - sizes.music.width;
        const rowY = top + (sizes.music.height + gap) * 2;
        switch (key) {
        case "music":
            return Qt.point(colX, top);
        case "calendar":
            return Qt.point(colX, top + sizes.music.height + gap);
        case "clock":
            return Qt.point(colX, rowY);
        case "discord":
            return Qt.point(colX - sizes.discord.width - gap, top);
        case "system":
            return Qt.point(colX, rowY + sizes.clock.height + gap);
        default:
            return Qt.point(colX + sizes.music.width - sizes.weather.width, rowY);
        }
    }

    // top-left of a widget in the combined coordinate space of all screens
    function place(key) {
        if (dragKey === key)
            return Qt.point(dragX, dragY);
        const layout = Config.cfg.widgets.layout;
        const size = sizes[key];
        const x = layout[key + "X"];
        const y = layout[key + "Y"];
        const scr = screenNamed(layout[key + "Screen"]) ?? home;
        if (!scr)
            return Qt.point(0, 0);
        if (x < 0 || y < 0) {
            const d = fallback(key, scr);
            return Qt.point(scr.x + d.x, scr.y + d.y);
        }
        return Qt.point(scr.x + clamp(x, 0, scr.width - size.width), scr.y + clamp(y, 0, scr.height - size.height));
    }

    function begin(key, x, y) {
        dragX = x;
        dragY = y;
        dragKey = key;
    }

    function move(x, y) {
        dragX = x;
        dragY = y;
    }

    function finish() {
        if (dragKey === "")
            return;
        const key = dragKey;
        const size = sizes[key];
        const scr = screenAt(dragX + size.width / 2, dragY + size.height / 2);
        if (scr) {
            const layout = Config.cfg.widgets.layout;
            layout[key + "Screen"] = scr.name;
            layout[key + "X"] = Math.round(clamp(dragX - scr.x, 0, scr.width - size.width));
            layout[key + "Y"] = Math.round(clamp(dragY - scr.y, 0, scr.height - size.height));
        }
        dragKey = "";
    }
}
