pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick

Singleton {
    id: root
    property bool nightLight: false
    property bool caffeine: false
    property bool gameMode: false
    property int timerLeft: 0
    readonly property bool recording: recorder.running
    readonly property bool airplane: !Network.wifiEnabled && !Bt.enabled
    readonly property string timerText: Math.floor(timerLeft / 60) + ":" + String(timerLeft % 60).padStart(2, "0")

    onGameModeChanged: {
        game.command = ["hyprctl", "--batch", gameMode ? "keyword animations:enabled 0 ; keyword decoration:blur:enabled 0 ; keyword decoration:shadow:enabled 0 ; keyword general:gaps_in 0 ; keyword general:gaps_out 0" : "reload"];
        game.running = true;
    }

    signal lockRequested

    function lock() {
        lockRequested();
    }

    function toggleAirplane() {
        const radiosOn = airplane;
        if (Network.wifiEnabled !== radiosOn)
            Network.toggleWifi();
        if (Bt.enabled !== radiosOn)
            Bt.toggle();
    }

    function capture() {
        Quickshell.execDetached(["sh", "-c", "sleep 0.4; mkdir -p ~/Pictures/Screenshots; f=~/Pictures/Screenshots/$(date +%F_%H-%M-%S).png; g=$(slurp) && grim -g \"$g\" \"$f\" && wl-copy < \"$f\""]);
    }

    function toggleRecording() {
        if (recorder.running)
            recorder.signal(2);
        else
            recorder.running = true;
    }

    function toggleTimer() {
        timerLeft = timerLeft > 0 ? 0 : 300;
    }

    Process {
        id: game
    }

    Process {
        running: root.nightLight
        command: ["gammastep", "-O", "4000"]
    }

    Process {
        running: root.caffeine
        command: ["sh", "-c", "for i in systemd-inhibit elogind-inhibit; do command -v $i >/dev/null && exec $i --what=idle:sleep --who=quickshell --why=\"Awake toggle\" sleep infinity; done; exec sleep infinity"]
    }

    Process {
        id: recorder
        command: ["sh", "-c", "mkdir -p ~/Videos && exec wf-recorder -f ~/Videos/rec-$(date +%F_%H-%M-%S).mp4"]
    }

    Timer {
        running: root.timerLeft > 0
        interval: 1000
        repeat: true
        onTriggered: {
            root.timerLeft--;
            if (root.timerLeft === 0)
                Quickshell.execDetached(["notify-send", "Timer", "Time's up"]);
        }
    }
}
