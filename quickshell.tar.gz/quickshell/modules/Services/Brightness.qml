pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick

Singleton {
    id: root
    property bool available: false
    property real value: 0

    function refresh() {
        reader.running = true;
    }

    function set(v) {
        value = v;
        apply.restart();
    }

    Component.onCompleted: refresh()

    Process {
        id: reader
        command: ["brightnessctl", "-c", "backlight", "-m"]
        stdout: SplitParser {
            onRead: line => {
                const parts = line.split(",");
                if (parts.length >= 5) {
                    root.available = true;
                    root.value = parseInt(parts[3]) / 100;
                }
            }
        }
    }

    Process {
        id: writer
    }

    Timer {
        id: apply
        interval: 80
        onTriggered: {
            if (writer.running) {
                apply.restart();
                return;
            }
            writer.command = ["brightnessctl", "-c", "backlight", "-q", "set", Math.max(1, Math.round(root.value * 100)) + "%"];
            writer.running = true;
        }
    }
}
