pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick

/* Freedesktop trash state for the dock: is there anything in it, open it, empty it. */
Singleton {
    id: root

    property bool full: false

    function open() {
        Quickshell.execDetached(["xdg-open", "trash:///"]);
    }

    function empty() {
        Quickshell.execDetached(["gio", "trash", "--empty"]);
        recheck.restart();
    }

    function check() {
        if (!probe.running)
            probe.running = true;
    }

    Process {
        id: probe
        command: ["sh", "-c", "d=\"${XDG_DATA_HOME:-$HOME/.local/share}/Trash/files\"; [ -n \"$(ls -A \"$d\" 2>/dev/null)\" ] && echo 1 || echo 0"]
        stdout: StdioCollector {
            onStreamFinished: root.full = text.trim() === "1"
        }
    }

    Timer {
        interval: 4000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: root.check()
    }

    Timer {
        id: recheck
        interval: 800
        onTriggered: root.check()
    }
}
