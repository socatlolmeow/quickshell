pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick

Singleton {
    id: root

    readonly property string tokenPath: Quickshell.shellDir + "/settings/discord.token"
    readonly property string script: Quickshell.shellDir + "/scripts/discord.sh"

    property bool hasToken: false
    property bool seenReady: false
    property bool loading: false
    property string error: ""
    property var me: null
    property int guilds: 0
    property var feed: []
    property int unread: 0
    property double lastRun: 0

    property var dms: []
    property var mentions: []
    property var previews: ({})

    readonly property string name: me ? (me.global_name || me.username) : ""
    readonly property string handle: me ? "@" + me.username : ""
    readonly property string avatar: me && me.avatar ? "https://cdn.discordapp.com/avatars/" + me.id + "/" + me.avatar + ".png?size=128" : ""

    function newer(a, b) {
        if (!a)
            return false;
        if (!b)
            return true;
        return a.length !== b.length ? a.length > b.length : a > b;
    }

    function refresh() {
        const now = Date.now();
        if (!hasToken || !seenReady || fetchAll.running || previewProc.running || now - lastRun < 20000)
            return;
        lastRun = now;
        loading = true;
        fetchAll.running = true;
    }

    function parseLine(line) {
        const sp = line.indexOf(" ");
        if (sp < 0)
            return null;
        try {
            return {
                tag: line.slice(0, sp),
                data: line.slice(sp + 1)
            };
        } catch (e) {
            return null;
        }
    }

    function onAll(text) {
        let ok = false;
        for (const line of text.split("\n")) {
            const l = parseLine(line);
            if (!l)
                continue;
            let o;
            try {
                o = JSON.parse(l.data);
            } catch (e) {
                continue;
            }
            if (l.tag === "ME") {
                if (o && o.id) {
                    me = o;
                    error = "";
                    ok = true;
                } else {
                    error = (o && o.message) ? o.message : "Request failed";
                }
            } else if (l.tag === "DM" && Array.isArray(o)) {
                dms = o.filter(c => c.last_message_id).sort((a, b) => newer(a.last_message_id, b.last_message_id) ? -1 : 1).slice(0, 5);
            } else if (l.tag === "MN" && Array.isArray(o)) {
                mentions = o;
            } else if (l.tag === "GD" && Array.isArray(o)) {
                guilds = o.length;
            }
        }
        if (!ok) {
            loading = false;
            if (error === "")
                error = "No response";
            return;
        }
        const ids = dms.slice(0, 4).map(c => c.id);
        if (ids.length === 0) {
            rebuild();
            return;
        }
        previewProc.command = ["sh", root.script, root.tokenPath, "msgs"].concat(ids);
        previewProc.running = true;
    }

    function onPreviews(text) {
        const p = {};
        for (const line of text.split("\n")) {
            if (!line.startsWith("M "))
                continue;
            const rest = line.slice(2);
            const sp = rest.indexOf(" ");
            if (sp < 0)
                continue;
            try {
                const o = JSON.parse(rest.slice(sp + 1));
                if (Array.isArray(o) && o.length > 0)
                    p[rest.slice(0, sp)] = o[0];
            } catch (e) {}
        }
        previews = p;
        rebuild();
    }

    function chanName(c) {
        if (c.name)
            return c.name;
        const r = (c.recipients || []).map(u => u.global_name || u.username);
        return r.length ? r.join(", ") : "Direct message";
    }

    function snippet(m) {
        const t = (m.content || "").replace(/\s+/g, " ").trim();
        if (t !== "")
            return t;
        if (m.attachments && m.attachments.length > 0)
            return "Attachment";
        if (m.sticker_items && m.sticker_items.length > 0)
            return "Sticker";
        return "Message";
    }

    function rebuild() {
        const seen = Object.assign({}, store.seen || {});
        const items = [];
        let first = !seen.init;

        for (const c of dms) {
            const m = previews[c.id];
            if (!m)
                continue;
            const mine = me && m.author && m.author.id === me.id;
            if (first)
                seen[c.id] = c.last_message_id;
            items.push({
                kind: "dm",
                id: c.id,
                msgId: c.last_message_id,
                title: chanName(c),
                text: (mine ? "You: " : "") + snippet(m),
                unread: !mine && newer(c.last_message_id, seen[c.id])
            });
        }
        for (const m of mentions) {
            if (!m || !m.id || !m.author)
                continue;
            items.push({
                kind: "mention",
                id: m.channel_id,
                guild: m.guild_id || "@me",
                msgId: m.id,
                title: (m.author.global_name || m.author.username) + " mentioned you",
                text: snippet(m),
                unread: newer(m.id, seen.mention)
            });
        }
        if (first) {
            seen.init = true;
            if (mentions.length > 0 && mentions[0].id)
                seen.mention = mentions[0].id;
            for (const it of items)
                if (it.kind === "mention")
                    it.unread = false;
            store.seen = seen;
            seenView.writeAdapter();
        }
        items.sort((a, b) => newer(a.msgId, b.msgId) ? -1 : 1);
        unread = items.filter(i => i.unread).length;
        feed = items.slice(0, 3);
        loading = false;
    }

    function open(item) {
        const url = item.kind === "dm" ? "discord://-/channels/@me/" + item.id : "discord://-/channels/" + item.guild + "/" + item.id + "/" + item.msgId;
        Quickshell.execDetached(["xdg-open", url]);
        const seen = Object.assign({}, store.seen || {});
        if (item.kind === "dm")
            seen[item.id] = item.msgId;
        else if (newer(item.msgId, seen.mention))
            seen.mention = item.msgId;
        store.seen = seen;
        seenView.writeAdapter();
        rebuild();
    }

    function markAllRead() {
        const seen = Object.assign({}, store.seen || {});
        for (const c of dms)
            seen[c.id] = c.last_message_id;
        if (mentions.length > 0 && mentions[0].id)
            seen.mention = mentions[0].id;
        seen.init = true;
        store.seen = seen;
        seenView.writeAdapter();
        rebuild();
    }

    FileView {
        id: tokenFile
        path: root.tokenPath
        watchChanges: true
        onFileChanged: reload()
        onLoaded: {
            root.hasToken = text().replace(/\s/g, "").length > 20;
            root.lastRun = 0;
            root.error = "";
        }
        onLoadFailed: root.hasToken = false
    }

    FileView {
        id: seenView
        path: Qt.resolvedUrl(Quickshell.shellDir + "/settings/discord-seen.json")
        onLoaded: root.seenReady = true
        onLoadFailed: error => {
            if (error === FileViewError.FileNotFound)
                writeAdapter();
            root.seenReady = true;
        }
        adapter: JsonAdapter {
            id: store
            property var seen: ({})
        }
    }

    Process {
        id: fetchAll
        command: ["sh", root.script, root.tokenPath, "all"]
        stdout: StdioCollector {
            onStreamFinished: root.onAll(text)
        }
        onExited: code => {
            if (code !== 0) {
                root.loading = false;
                root.error = "Network error";
            }
        }
    }

    Process {
        id: previewProc
        stdout: StdioCollector {
            onStreamFinished: root.onPreviews(text)
        }
    }
}
