pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick

Singleton {
    id: root
    property var levels: [0, 0, 0, 0, 0]
    property bool active: false

    Timer {
        id: hold
        interval: 1500
        onTriggered: root.active = false
    }

    Timer {
        id: respawn
        interval: 2000
        onTriggered: cava.running = true
    }

    Process {
        id: cava
        running: true
        command: ["cava", "-p", Quickshell.shellPath("settings/cava.conf")]
        onExited: respawn.start()
        stdout: SplitParser {
            onRead: line => {
                const parts = line.split(";");
                const values = [];
                for (let i = 0; i < 5; i++) {
                    const v = Number(parts[i]);
                    values.push(isFinite(v) ? Math.min(v / 100, 1) : 0);
                }
                root.levels = values;
                if (values.some(v => v > 0.02)) {
                    root.active = true;
                    hold.restart();
                }
            }
        }
    }
}
