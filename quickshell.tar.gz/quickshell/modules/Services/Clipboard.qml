pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick

Singleton {
    id: root
    property var items: []
    readonly property int limit: 40
    readonly property int maxLength: 20000

    function start() {
        try {
            const saved = JSON.parse(store.text());
            if (Array.isArray(saved))
                items = saved;
        } catch (e) {}
        watcher.running = true;
    }

    function add(text) {
        if (text.trim() === "" || text.length > maxLength)
            return;
        const old = items.find(i => i.text === text);
        const entry = {
            text: text,
            pinned: old?.pinned ?? false,
            time: Date.now()
        };
        const rest = items.filter(i => i.text !== text);
        const unpinned = rest.filter(i => !i.pinned);
        const drop = unpinned.slice(limit - 1);
        commit([entry].concat(rest.filter(i => !drop.includes(i))));
    }

    function copy(entry) {
        Quickshell.execDetached(["wl-copy", "--", entry.text]);
    }

    function togglePin(entry) {
        commit(items.map(i => i === entry ? Object.assign({}, i, {
                pinned: !i.pinned
            }) : i));
    }

    function remove(entry) {
        commit(items.filter(i => i !== entry));
    }

    function clear() {
        commit(items.filter(i => i.pinned));
    }

    function commit(next) {
        items = next;
        saveTimer.restart();
    }

    FileView {
        id: store
        path: Quickshell.env("XDG_RUNTIME_DIR") + "/quickshell-clipboard.json"
        blockLoading: true
    }

    Timer {
        id: saveTimer
        interval: 500
        onTriggered: store.setText(JSON.stringify(root.items))
    }

    Timer {
        id: respawn
        interval: 2000
        onTriggered: watcher.running = true
    }

    Process {
        id: watcher
        command: ["wl-paste", "--type", "text", "--watch", "sh", "-c", "if wl-paste -l 2>/dev/null | grep -qx x-kde-passwordManagerHint; then cat >/dev/null; echo; exit 0; fi; od -An -v -tx1 | tr -d ' \\n'; echo"]
        onExited: respawn.start()
        stdout: SplitParser {
            onRead: line => {
                if (line.length < 2 || line.length % 2 !== 0)
                    return;
                try {
                    root.add(decodeURIComponent(line.replace(/../g, "%$&")));
                } catch (e) {}
            }
        }
    }
}
