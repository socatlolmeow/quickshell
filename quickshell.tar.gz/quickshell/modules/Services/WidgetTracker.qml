pragma Singleton
import Quickshell

Singleton {
    id: root
    property string current: ""
    property ShellScreen screen: null
    function toggle(name, scr) {
        current = (current === name && screen === scr) ? "" : name;
        screen = scr;
    }
    function close() {
        current = "";
    }
}
