pragma Singleton
import Quickshell
import Quickshell.Hyprland
import Quickshell.Io
import QtQuick

Singleton {
    id: root

    property var list: []
    property bool again: false

    function refresh() {
        if (probe.running)
            again = true;
        else
            probe.running = true;
    }

    Process {
        id: probe
        command: ["hyprctl", "-j", "clients"]
        stdout: StdioCollector {
            onStreamFinished: {
                try {
                    root.list = JSON.parse(text);
                } catch (e) {}
            }
        }
        onExited: {
            if (root.again) {
                root.again = false;
                running = true;
            }
        }
    }

    Connections {
        target: Hyprland
        function onRawEvent() {
            debounce.restart();
        }
    }

    Timer {
        id: debounce
        interval: 30
        onTriggered: root.refresh()
    }

    Timer {
        interval: 350
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: root.refresh()
    }
}
