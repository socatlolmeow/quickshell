pragma Singleton
import Quickshell
import Quickshell.Bluetooth

Singleton {
    id: root
    readonly property bool enabled: Bluetooth.defaultAdapter?.enabled ?? false
    readonly property var device: Bluetooth.devices.values.find(d => d.connected) ?? null

    function toggle() {
        if (Bluetooth.defaultAdapter)
            Bluetooth.defaultAdapter.enabled = !Bluetooth.defaultAdapter.enabled;
    }
}
