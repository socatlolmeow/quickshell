pragma Singleton
import Quickshell
import QtQuick
import Quickshell.Services.Pipewire

Singleton {
    id: root
    property bool ready: Pipewire.ready
    property bool muted: ready ? (defaultAudio?.audio?.muted ?? true) : true
    property PwNode defaultAudio: Pipewire.defaultAudioSink
    property PwNode preferredAudio: Pipewire.preferredDefaultAudioSink
    property PwNode defaultSource: Pipewire.defaultAudioSource
    property bool micMuted: defaultSource?.audio?.muted ?? false
    property real percentage: Math.round((defaultAudio?.audio?.volume ?? 0) * 100)
    readonly property list<PwNode> sinks: Pipewire.nodes.values.filter(n => n.audio && n.isSink && !n.isStream)
    readonly property list<PwNode> sources: Pipewire.nodes.values.filter(n => n.audio && !n.isSink && !n.isStream)
    PwObjectTracker {
        objects: [...root.sinks, ...root.sources, root.defaultAudio, root.defaultSource].filter(n => n)
    }
    function getVolumeIcon(sink) {
        const a = root.ready ? sink?.audio : null;
        if (!a || a.muted)
            return "speaker-slash";
        if (a.volume <= 0.001)
            return "speaker-none";
        if (a.volume <= 0.5)
            return "speaker-low";
        return "speaker-high";
    }
    function setVolume(v) {
        const a = defaultAudio?.audio;
        if (!a)
            return;
        a.volume = Math.max(0, Math.min(1, v));
        if (a.muted && v > 0)
            a.muted = false;
    }
    function adjust(delta) {
        const a = defaultAudio?.audio;
        if (a)
            setVolume(a.volume + delta);
    }
    function toggleMute() {
        const a = defaultAudio?.audio;
        if (a)
            a.muted = !a.muted;
    }
    function toggleMic() {
        if (defaultSource?.audio)
            defaultSource.audio.muted = !defaultSource.audio.muted;
    }
    function setDefaultSink(node: PwNode): void {
        Pipewire.preferredDefaultAudioSink = node;
    }
}
