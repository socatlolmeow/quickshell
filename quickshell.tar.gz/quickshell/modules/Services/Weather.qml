pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick
import qs.settings

Singleton {
    id: root
    property bool ready: false
    property int temp: 0
    property string desc: ""
    property string icon: "cloud-sun"
    property string city: ""
    property int high: 0
    property int low: 0

    function iconFor(code) {
        const night = new Date().getHours() < 6 || new Date().getHours() >= 21;
        if (code === 113)
            return night ? "moon" : "sun";
        if (code === 116)
            return night ? "cloud-moon" : "cloud-sun";
        if ([119, 122].includes(code))
            return "cloud";
        if ([143, 248, 260].includes(code))
            return "cloud-fog";
        if ([200, 386, 389, 392, 395].includes(code))
            return "cloud-lightning";
        if ([179, 182, 185, 227, 230, 323, 326, 329, 332, 335, 338, 350, 368, 371, 374, 377].includes(code))
            return "cloud-snow";
        return "cloud-rain";
    }

    function parse(text) {
        try {
            const data = JSON.parse(text);
            const now = data.current_condition[0];
            city = data.nearest_area?.[0]?.areaName?.[0]?.value ?? "";
            high = Math.round(Number(data.weather[0].maxtempC));
            low = Math.round(Number(data.weather[0].mintempC));
            temp = Math.round(Number(now.temp_C));
            desc = now.weatherDesc[0].value;
            icon = iconFor(Number(now.weatherCode));
            ready = true;
        } catch (e) {
            retry.start();
        }
    }

    Timer {
        running: Config.cfg.widgets.weather
        interval: 1800000
        repeat: true
        triggeredOnStart: true
        onTriggered: fetch.running = true
    }

    Timer {
        id: retry
        interval: 120000
        onTriggered: fetch.running = true
    }

    Process {
        id: fetch
        command: ["curl", "-sf", "--max-time", "15", "https://wttr.in/" + encodeURIComponent(Config.cfg.widgets.location) + "?format=j1"]
        stdout: StdioCollector {
            onStreamFinished: root.parse(text)
        }
        onExited: code => {
            if (code !== 0)
                retry.start();
        }
    }
}
