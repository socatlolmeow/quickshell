pragma Singleton
import Quickshell
import Quickshell.Services.UPower
import Quickshell.Services.Notifications
import QtQuick
import qs.settings

Singleton {
    id: root
    property bool open: false
    property ShellScreen screen: null
    property bool barHover: false
    property bool pinned: false
    property string page: "main"
    readonly property bool hovered: barHover || pinned
    /* "click": tap to open (iOS), "hover": open on pointer contact (original) */
    readonly property bool clickMode: Config.cfg.island.openOn === "click"

    /* notification banners (iOS-style): one shows at a time, the rest wait their turn */
    property var bannerQueue: []
    property var bannerN: null
    property bool bannerUser: false
    property string bannerApp: ""
    property string bannerTitle: ""
    property string bannerBody: ""
    property string bannerIcon: ""
    property bool bannerUrgent: false

    property string osdKind: ""
    property bool osdOn: false
    property bool armed: false
    property bool popOn: false
    property string popKind: "track"
    property string eventIcon: ""
    property string eventTitle: ""
    property string eventSub: ""
    property bool eventUrgent: false
    readonly property var battery: UPower.displayDevice
    readonly property bool plugged: battery.state === UPowerDeviceState.Charging || battery.state === UPowerDeviceState.FullyCharged || battery.state === UPowerDeviceState.PendingCharge
    readonly property int batteryPercent: Math.floor(battery.percentage * 100)
    readonly property var btDevice: Bt.device
    property string btLast: ""
    property bool lowShown: false
    property bool critShown: false
    readonly property string trackKey: Media.title + "\n" + Media.artist

    function hoverBar(on, scr) {
        if (on)
            screen = scr;
        barHover = on;
    }

    /* Open the island straight onto a page (used by IPC). */
    function showPage(name, scr) {
        WidgetTracker.close();
        screen = scr ?? Quickshell.screens[0] ?? null;
        page = name;
        open = true;
    }

    function togglePage(name, scr) {
        if (open && page === name && (scr === null || screen === scr))
            dismiss();
        else
            showPage(name, scr);
    }

    /* Close now, skipping the hover timers. Closing resets page/pinned. */
    function dismiss() {
        openTimer.stop();
        closeTimer.stop();
        open = false;
    }

    /* ---- notification banners ---- */
    function pushBanner(n) {
        const clean = t => (t ?? "").replace(/<[^>]*>/g, "").replace(/\s*\n\s*/g, " ").trim();
        const app = clean(n.appName);
        const title = clean(n.summary);
        const body = clean(n.body);
        const q = bannerQueue.concat([
            {
                n: n,
                at: Date.now(),
                app: app,
                title: title !== "" ? title : app,
                body: body !== "" ? body : (title !== "" ? app : ""),
                icon: n.image ? n.image : (n.appIcon ? Quickshell.iconPath(n.appIcon, true) : ""),
                urgent: n.urgency === NotificationUrgency.Critical
            }
        ]);
        while (q.length > 4)
            retireNotification(q.shift().n, false);
        bannerQueue = q;
        drainBanners();
    }

    function drainBanners() {
        if (open || osdOn || (popOn && popKind === "notif"))
            return;
        while (bannerQueue.length > 0) {
            const b = bannerQueue[0];
            bannerQueue = bannerQueue.slice(1);
            if (Date.now() - b.at > 30000) {
                retireNotification(b.n, false);
                continue;
            }
            bannerN = b.n;
            bannerUser = false;
            bannerApp = b.app;
            bannerTitle = b.title;
            bannerBody = b.body;
            bannerIcon = b.icon;
            bannerUrgent = b.urgent;
            popKind = "notif";
            popOn = true;
            popTimer.interval = b.urgent ? 8000 : 5500;
            popTimer.restart();
            return;
        }
    }

    function retireNotification(n, user) {
        try {
            if (n && n.tracked) {
                if (user)
                    n.dismiss();
                else
                    n.expire();
            }
        } catch (e) {}
    }

    /* tap on a banner: run the notification's default action (focus the app), then close it */
    function activateBanner() {
        try {
            const acts = bannerN?.actions ?? [];
            for (const a of acts) {
                if (a.identifier === "default") {
                    a.invoke();
                    break;
                }
            }
        } catch (e) {}
        dismissBanner();
    }

    /* swipe up / right-click on a banner */
    function dismissBanner() {
        bannerUser = true;
        popTimer.stop();
        popOn = false;
    }

    /* iOS-style tap on the idle island */
    function clickOpen(scr) {
        if (!open)
            showPage("main", scr);
    }

    function showOsd(kind) {
        if (!armed || open)
            return;
        if (!(popOn && popKind === "notif"))
            popOn = false;
        osdKind = kind;
        osdOn = true;
        osdTimer.restart();
    }

    function showTrack() {
        if (!armed || open || osdOn || (popOn && popKind === "notif"))
            return;
        popKind = "track";
        popOn = true;
        popTimer.interval = 3800;
        popTimer.restart();
    }

    function showEvent(icon, title, sub, urgent) {
        if (!armed || open || osdOn || (popOn && popKind === "notif"))
            return;
        eventIcon = icon;
        eventTitle = title;
        eventSub = sub;
        eventUrgent = urgent ?? false;
        popKind = "event";
        popOn = true;
        popTimer.interval = 3800;
        popTimer.restart();
    }

    function showToggle(icon, title, on) {
        showEvent(icon, title, on ? "On" : "Off", false);
    }

    onPluggedChanged: {
        if (battery.isLaptopBattery)
            showEvent(plugged ? "plug-charging" : "battery-medium", plugged ? "Charging" : "Unplugged", batteryPercent + "%", false);
    }

    onBatteryPercentChanged: {
        if (!battery.isLaptopBattery || plugged)
            return;
        if (batteryPercent <= 15 && !lowShown) {
            lowShown = true;
            showEvent("battery-warning", "Low battery", batteryPercent + "% remaining", true);
        } else if (batteryPercent <= 5 && !critShown) {
            critShown = true;
            showEvent("battery-warning", "Battery critical", batteryPercent + "% remaining", true);
        } else if (batteryPercent > 20) {
            lowShown = false;
            critShown = false;
        }
    }

    onBtDeviceChanged: {
        if (btDevice) {
            btLast = btDevice.name;
            const lvl = btDevice.batteryAvailable === true ? Math.round(btDevice.battery * 100) : -1;
            showEvent("bluetooth-connected", btDevice.name, lvl >= 0 ? "Connected \u00b7 " + lvl + "% battery" : "Connected", false);
        } else if (btLast !== "") {
            showEvent("bluetooth-slash", btLast, "Disconnected", false);
            btLast = "";
        }
    }

    Connections {
        target: Network
        function onConnectedNetChanged() {
            if (Network.connectedNet)
                root.showEvent("wifi-high", Network.connectedNet.name, "Connected", false);
        }
    }

    Connections {
        target: Toggles
        function onCaffeineChanged() {
            root.showToggle("coffee", "Caffeine", Toggles.caffeine);
        }
        function onGameModeChanged() {
            root.showToggle("game-controller", "Game mode", Toggles.gameMode);
        }
        function onNightLightChanged() {
            root.showToggle("moon", "Night light", Toggles.nightLight);
        }
        function onAirplaneChanged() {
            root.showToggle("airplane", "Airplane mode", Toggles.airplane);
        }
        function onRecordingChanged() {
            root.showEvent("record", "Screen recording", Toggles.recording ? "Started" : "Saved to Videos", Toggles.recording);
        }
    }

    Connections {
        target: Audio
        function onMicMutedChanged() {
            root.showEvent(Audio.micMuted ? "microphone-slash" : "microphone", "Microphone", Audio.micMuted ? "Muted" : "On", false);
        }
    }

    onTrackKeyChanged: {
        if (Media.playing && Media.title !== "")
            trackDebounce.restart();
    }

    onOpenChanged: {
        if (open) {
            osdOn = false;
            popOn = false;
        } else {
            page = "main";
            pinned = false;
            drainBanners();
        }
    }

    onPopOnChanged: {
        if (popOn)
            return;
        if (bannerN !== null) {
            const n = bannerN;
            const user = bannerUser;
            bannerN = null;
            bannerUser = false;
            retireNotification(n, user);
        }
        drainBanners();
    }

    onOsdOnChanged: {
        if (!osdOn)
            drainBanners();
    }

    onHoveredChanged: {
        // hovering a banner holds it on screen, like pressing and holding one on iOS
        if (popOn && popKind === "notif") {
            if (hovered)
                popTimer.stop();
            else
                popTimer.restart();
        }
        if (hovered) {
            closeTimer.stop();
            if (!open && !clickMode)
                openTimer.restart();
        } else {
            openTimer.stop();
            closeTimer.restart();
        }
    }

    Connections {
        target: Audio.defaultAudio?.audio
        ignoreUnknownSignals: true
        function onVolumeChanged() {
            root.showOsd("volume");
        }
        function onMutedChanged() {
            root.showOsd("volume");
        }
    }

    Connections {
        target: Brightness
        function onValueChanged() {
            root.showOsd("brightness");
        }
    }

    Component.onCompleted: Clipboard.start()

    Timer {
        running: true
        interval: 3000
        onTriggered: root.armed = true
    }

    Timer {
        id: trackDebounce
        interval: 250
        onTriggered: root.showTrack()
    }

    Timer {
        id: popTimer
        interval: 3800
        onTriggered: root.popOn = false
    }

    Timer {
        id: osdTimer
        interval: 1800
        onTriggered: root.osdOn = false
    }

    Timer {
        id: openTimer
        interval: 110
        // a banner that's being read shouldn't be swallowed by the control center
        onTriggered: if (!(root.popOn && root.popKind === "notif")) root.open = true
    }

    Timer {
        id: closeTimer
        interval: 260
        onTriggered: root.open = false
    }
}
