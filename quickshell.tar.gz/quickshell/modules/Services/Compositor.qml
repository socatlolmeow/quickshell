pragma Singleton
import Quickshell
import Quickshell.Wayland

Singleton {
    id: root

    readonly property ShellScreen liveScreen: ToplevelManager.activeToplevel?.screens?.[0] ?? null

    property ShellScreen focusedScreen: Quickshell.screens[0] ?? null

    onLiveScreenChanged: {
        if (liveScreen)
            root.focusedScreen = liveScreen;
    }
}
