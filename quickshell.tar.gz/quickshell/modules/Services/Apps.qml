pragma Singleton
import Quickshell
import Quickshell.Io
import qs.settings

Singleton {
    id: root

    function uses(entry) {
        return (hist.counts && hist.counts[entry.id]) || 0;
    }

    function subsequence(hay, needle) {
        let j = 0;
        for (let i = 0; i < hay.length && j < needle.length; i++) {
            if (hay[i] === needle[j])
                j++;
        }
        return j === needle.length;
    }

    function score(entry, q) {
        const name = entry.name.toLowerCase();
        if (name === q)
            return 100;
        if (name.startsWith(q))
            return 80;
        if (name.includes(" " + q))
            return 60;
        if (name.includes(q))
            return 40;
        if ((entry.genericName || "").toLowerCase().includes(q))
            return 25;
        if ((entry.keywords || []).join(" ").toLowerCase().includes(q))
            return 20;
        if ((entry.comment || "").toLowerCase().includes(q))
            return 10;
        if (q.length >= 2 && root.subsequence(name, q))
            return 5;
        return 0;
    }

    function search(query) {
        const q = query.trim().toLowerCase();
        const apps = DesktopEntries.applications.values;
        const out = [];
        for (let i = 0; i < apps.length; i++) {
            const e = apps[i];
            if (e.noDisplay)
                continue;
            const s = q === "" ? 0 : root.score(e, q);
            if (q !== "" && s <= 0)
                continue;
            out.push({
                entry: e,
                score: s + Math.min(root.uses(e), 30) * 0.5
            });
        }
        out.sort((a, b) => (b.score - a.score) || a.entry.name.localeCompare(b.entry.name));
        return out.map(o => o.entry);
    }

    function launch(entry) {
        if (entry.runInTerminal) {
            const term = Config.cfg.launcher.terminal !== "" ? Config.cfg.launcher.terminal : (Quickshell.env("TERMINAL") || "foot");
            Quickshell.execDetached([term, "-e"].concat(Array.from(entry.command)));
        } else {
            entry.execute();
        }
        root.record(entry);
    }

    function record(entry) {
        const next = {};
        const old = hist.counts || {};
        for (const k in old)
            next[k] = old[k];
        next[entry.id] = (next[entry.id] || 0) + 1;
        hist.counts = next;
        histView.writeAdapter();
    }

    FileView {
        id: histView
        path: Qt.resolvedUrl(Quickshell.shellDir + "/settings/launcher-history.json")
        onLoadFailed: error => {
            if (error === FileViewError.FileNotFound)
                writeAdapter();
        }
        adapter: JsonAdapter {
            id: hist
            property var counts: ({})
        }
    }
}
