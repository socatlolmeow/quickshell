pragma Singleton
import Quickshell
import Quickshell.Networking
import QtQuick

Singleton {
    id: root
    property bool wifiEnabled: Networking.wifiEnabled
    readonly property list<NetworkDevice> devices: Networking.devices.values
    property WifiDevice wifiDev: devices.find(dev => dev.type === DeviceType.Wifi) ?? null
    property WiredDevice wiredDev: devices.find(dev => dev.type === DeviceType.Wired) ?? null
    property list<WifiNetwork> wifiNetworks: wifiDev?.networks.values ?? []
    property WifiNetwork connectedNet: wifiNetworks.find(net => net.connected) ?? null
    function toggleWifi() {
        Networking.wifiEnabled = !Networking.wifiEnabled;
    }
    function getWiredIcon() {
        if (wiredDev?.hasLink ?? false) {
            if (wiredDev.connected ?? false) {
                return "network";
            } else
                return "network-slash";
        } else
            return "network-x";
    }
    Timer {
        running: root.wifiEnabled
        interval: 30000
        repeat: true
        triggeredOnStart: true
        onTriggered: Networking.checkConnectivity()
    }
    function getWifiIcon() {
        let state = wifiDev?.state ?? ConnectionState.Unknown;
        if (state === ConnectionState.Disconnected || state === ConnectionState.Unknown)
            return "wifi-slash";
        if (wifiDev?.connected ?? false) {
            let strength = connectedNet?.signalStrength ?? 0.0;
            if (strength <= 0.25)
                return "wifi-none";
            if (strength <= 0.5)
                return "wifi-low";
            if (strength <= 0.75)
                return "wifi-medium";
            return "wifi-high";
        }
        return "wifi-slash";
    }
}
