#!/bin/sh
# discord.sh tokenfile all|msgs [channel-id ...]
tf=$1 cmd=$2
shift 2
t=$(tr -d ' \r\n"' <"$tf" 2>/dev/null)
[ -n "$t" ] || exit 1

api() {
	printf 'header = "Authorization: %s"\nheader = "User-Agent: Mozilla/5.0"\n' "$t" |
		curl -sS -m 15 -K - "https://discord.com/api/v9$1" | tr -d '\n'
}

case $cmd in
all)
	printf 'ME %s\n' "$(api /users/@me)"
	printf 'DM %s\n' "$(api /users/@me/channels)"
	printf 'MN %s\n' "$(api '/users/@me/mentions?limit=8')"
	printf 'GD %s\n' "$(api /users/@me/guilds)"
	;;
msgs)
	for id; do
		printf 'M %s %s\n' "$id" "$(api "/channels/$id/messages?limit=1")"
	done
	;;
esac
