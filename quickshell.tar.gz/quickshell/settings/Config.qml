pragma Singleton
import QtCore
import QtQuick
import Quickshell
import Quickshell.Io

Singleton {
    id: root
    property alias cfg: cfg
    function save() {
        if (cfgView.loaded)
            cfgView.writeAdapter();
    }
    FileView {
        id: cfgView
        path: Qt.resolvedUrl(Quickshell.shellDir + "/settings/settings.json")
        watchChanges: true
        onFileChanged: {
            this.reload();
        }
        onAdapterUpdated: {
            writeAdapter();
        }
        onLoadFailed: error => {
            if (error === FileViewError.FileNotFound)
                writeAdapter();
        }
        adapter: JsonAdapter {
            id: cfg
            property JsonObject appearance: JsonObject {
                property string accent: "base0D"
                property string font: "Google Sans Flex"
                property int fontSize: 14
                property real fontScale: 1
                property int iconSize: 16
                property int rounding: 28
                property string controlStyle: "macos"
                property string currentTheme: "base16-material-you-dark.json"
            }
            property JsonObject bar: JsonObject {
                property bool floating: true
                property bool hang: false
                property bool pureBlack: true
                property int eqOffset: 10
                property int height: 38
                property int margin: 8
                property real opacity: 1
            }
            property JsonObject widgets: JsonObject {
                property bool enabled: true
                property int monitor: 0
                property JsonObject layout: JsonObject {
                    property string clockScreen: ""
                    property real clockX: -1
                    property real clockY: -1
                    property string calendarScreen: ""
                    property real calendarX: -1
                    property real calendarY: -1
                    property string musicScreen: ""
                    property real musicX: -1
                    property real musicY: -1
                    property string weatherScreen: ""
                    property real weatherX: -1
                    property real weatherY: -1
                    property string discordScreen: ""
                    property real discordX: -1
                    property real discordY: -1
                    property string systemScreen: ""
                    property real systemX: -1
                    property real systemY: -1
                }
                property bool clock: true
                property bool calendar: true
                property bool music: true
                property bool weather: true
                property bool system: true
                property bool discord: true
                property string location: ""
            }
            property JsonObject island: JsonObject {
                /* "hover": the control center opens when the pointer touches the island (original behaviour)
                 * "click": iOS-style. Tap opens it; right-click toggles Do Not Disturb; scroll changes volume. */
                property string openOn: "hover"
                /* notifications drop out of the island like iOS banners instead of separate cards */
                property bool banners: true
                /* live activities in the idle pill: album art, timer, recording dot, Do Not Disturb */
                property bool activities: true
            }
            property JsonObject dock: JsonObject {
                property bool enabled: true
                property bool autoHide: true
                property int iconSize: 48
                property real magnification: 1.7
                property bool showLauncher: true
                property bool showTrash: true
                property var pinned: ["kitty", "firefox", "thunar"]
            }
            property JsonObject launcher: JsonObject {
                property int maxRows: 5
                property bool fixedHeight: true
                property string terminal: ""
            }
            property JsonObject workspaces: JsonObject {
                property bool hideEmpty: true
                property bool scroll: true
            }
            property JsonObject wallpaper: JsonObject {
                property string wallDir: Quickshell.env("HOME") + "/.walls/"
                property string wallpaper: ""
            }
        }
    }
}
