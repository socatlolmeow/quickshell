pragma Singleton
import QtQuick
import Quickshell
import qs.settings

// Typography, ported from lucid's Theme: bundled Google Sans Flex, an M3 type
// scale, and the variable-axis helper that drives wght / opsz / ROND.
Singleton {
    id: root

    // ---- family -----------------------------------------------------------
    // the bundled flex cut, once Qt has actually loaded it
    readonly property string brandFamily: flexLoader.status === FontLoader.Ready ? flexLoader.name : "Google Sans Flex"

    // "" and the two Google Sans names all mean "use the bundled font";
    // anything else in appearance.font is taken as an installed family
    readonly property string family: {
        const f = Config.cfg.appearance.font;
        return (f === "" || f === "Google Sans" || f === "Google Sans Flex") ? root.brandFamily : f;
    }
    // axes are only sent while the bundled flex font is the one in use
    readonly property bool flexActive: root.family === root.brandFamily && flexLoader.status === FontLoader.Ready

    // ---- scale ------------------------------------------------------------
    // user multiplier on every text size (appearance.fontScale)
    readonly property real scale: Config.cfg.appearance.fontScale > 0 ? Config.cfg.appearance.fontScale : 1

    function fs(px) {
        return Math.round(px * root.scale);
    }

    // ---- weights ----------------------------------------------------------
    // lucid's weights: body sits a hair above regular, emphasis is 560
    readonly property int wBody: 420
    readonly property int wMedium: 520
    readonly property int wEmph: 560
    readonly property int wStrong: 600

    // font.weight enum for a numeric wght, as lucid's LText maps it
    function weightEnum(w) {
        return w >= 650 ? Font.Bold : w >= 540 ? Font.DemiBold : w >= 470 ? Font.Medium : Font.Normal;
    }

    // ---- M3 type scale ----------------------------------------------------
    // role -> [px at 1.0x, wght, ROND]
    readonly property var typeRoles: ({
        "displayLarge": [52, 500, 100],
        "displayMedium": [42, 500, 100],
        "displaySmall": [32, 500, 60],
        "headlineLarge": [30, 500, 40],
        "headlineMedium": [26, 500, 30],
        "headlineSmall": [22, 500, 20],
        "titleLarge": [19, 500, 0],
        "titleMedium": [16, 560, 0],
        "titleSmall": [14, 560, 0],
        "bodyLarge": [15, 420, 0],
        "bodyMedium": [13, 420, 0],
        "bodySmall": [12, 420, 0],
        "labelLarge": [13, 560, 0],
        "labelMedium": [12, 560, 0],
        "labelSmall": [11, 560, 0]
    })

    function _role(role) {
        return root.typeRoles[role] || root.typeRoles.bodyMedium;
    }
    // unscaled design size of a role
    function typeBase(role) {
        return root._role(role)[0];
    }
    function typeSize(role) {
        return root.fs(root._role(role)[0]);
    }
    function typeWeight(role) {
        return root._role(role)[1];
    }
    function typeRound(role) {
        return root._role(role)[2];
    }
    function typeSpacing(role) {
        if (role.indexOf("label") === 0)
            return 0.2;
        if (role.indexOf("display") === 0)
            return -0.4;
        return 0;
    }

    // ---- variable axes ----------------------------------------------------
    // Qt builds a font engine per distinct axis tuple and mmaps the whole flex
    // file for each one, so a free-running opsz costs rss per pixel size in
    // use. opsz only picks the optical master, never the rendered size, so
    // snapping it to a ladder is invisible and collapses the engines.
    readonly property var _opszStops: [9, 13, 18, 28, 48, 96]

    function _snap(px) {
        const v = Math.max(6, Math.min(144, px));
        let best = root._opszStops[0];
        for (let i = 1; i < root._opszStops.length; i++) {
            if (Math.abs(root._opszStops[i] - v) < Math.abs(best - v))
                best = root._opszStops[i];
        }
        return best;
    }

    // the variable axes a flex text wants; empty for any other family, whose
    // weight then comes from font.weight as usual
    function axes(px, wght, rond) {
        if (!root.flexActive)
            return ({});
        return ({
            "wght": Math.round((wght || 400) / 25) * 25,
            "opsz": root._snap(px),
            "ROND": Math.round((rond || 0) / 10) * 10
        });
    }

    FontLoader {
        id: flexLoader
        source: Qt.resolvedUrl(Quickshell.shellDir + "/assets/fonts/GoogleSansFlex.ttf")
    }
}
