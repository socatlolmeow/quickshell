import QtQuick
import QtQuick.Effects
import QtQuick.Layouts
import qs
import qs.settings

Rectangle {
    id: root
    default property alias content: row.data
    property int padding: 5
    property alias hovered: hover.hovered
    visible: row.visibleChildren.length > 0
    color: Config.cfg.bar.floating ? Colors.alpha(Colors.bg, Config.cfg.bar.opacity) : "transparent"
    border.width: Config.cfg.bar.floating ? 1 : 0
    border.color: Colors.hairline
    implicitHeight: Config.cfg.bar.height
    implicitWidth: row.implicitWidth + padding * 2
    radius: Math.min(Config.cfg.appearance.rounding, height / 2)
    layer.enabled: Config.cfg.bar.floating
    layer.effect: MultiEffect {
        shadowEnabled: true
        shadowColor: "black"
        shadowOpacity: 0.28
        shadowBlur: 1
        shadowVerticalOffset: 6
    }

    HoverHandler {
        id: hover
    }

    RowLayout {
        id: row
        anchors.centerIn: parent
        spacing: 2
    }
}
