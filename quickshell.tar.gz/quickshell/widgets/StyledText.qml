import QtQuick
import qs
import qs.settings

// Text on the lucid type system.
//
// Size and weight are plain properties here instead of font.pixelSize /
// font.bold, because the opsz and wght variable axes have to be computed from
// them. Use `textSize: ...` and `wght: ...` rather than overriding font.*.
//
//   textSize  design size in px at fontScale 1 (defaults to appearance.fontSize)
//   wght      variable weight, 100-1000 (Typography.wBody / wEmph / ...)
//   rond      ROND axis, 0-100 (round terminals)
//   typeRole  optional M3 role (e.g. "titleSmall") that sets all three at once
//   tabular   fixed-width figures, for anything that counts
Text {
    id: t

    property string typeRole: ""
    property real textSize: t.typeRole === "" ? (Config.cfg.appearance.fontSize > 0 ? Config.cfg.appearance.fontSize : 14) : Typography.typeBase(t.typeRole)
    property real wght: t.typeRole === "" ? Typography.wBody : Typography.typeWeight(t.typeRole)
    property real rond: t.typeRole === "" ? 0 : Typography.typeRound(t.typeRole)
    property bool tabular: false

    // size actually rendered, after fontScale
    readonly property int renderedSize: Typography.fs(t.textSize)

    color: Colors.font

    font.family: Typography.family
    font.pixelSize: t.renderedSize
    font.weight: Typography.weightEnum(t.wght)
    font.variableAxes: Typography.axes(t.renderedSize, t.wght, t.rond)
    font.features: t.tabular ? ({
            "tnum": 1
        }) : ({})
    font.letterSpacing: Typography.typeSpacing(t.typeRole)
    font.italic: false
    font.strikeout: false
    font.kerning: true
    font.preferShaping: true
    font.hintingPreference: Font.PreferNoHinting

    renderType: Text.NativeRendering
    verticalAlignment: Text.AlignVCenter
}
