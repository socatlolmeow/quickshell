import QtQuick
import qs
import qs.settings

Rectangle {
    id: root
    property bool active: false
    property bool filled: false
    property color fillColor: Colors.surface
    property color hoverColor: Colors.highlight
    color: active ? hoverColor : (filled ? fillColor : Colors.alpha(hoverColor, 0))
    implicitHeight: Config.cfg.bar.height - 10
    radius: Math.min(Config.cfg.appearance.rounding - 2, height / 2)

    Behavior on color {
        ColorAnimation {
            duration: 180
        easing.type: Easing.OutCubic
        }
    }
}
