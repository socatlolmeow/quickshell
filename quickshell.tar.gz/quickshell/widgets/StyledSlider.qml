import QtQuick
import QtQuick.Controls.Basic
import qs.settings
import qs

Slider {
    id: control
    value: 0.5

    background: Rectangle {
        x: control.leftPadding
        y: control.topPadding + control.availableHeight / 2 - height / 2
        implicitWidth: 170
        implicitHeight: 8
        width: control.availableWidth
        height: implicitHeight
        radius: height / 2
        color: Colors.highlight
        clip: true

        Rectangle {
            width: control.visualPosition * parent.width
            height: parent.height
            radius: parent.radius
            color: Colors.accent

            Behavior on width {
                enabled: !control.pressed
                NumberAnimation {
                    duration: 160
                    easing.type: Easing.OutCubic
                }
            }
        }
    }

    handle: Item {
        x: control.leftPadding + control.visualPosition * (control.availableWidth - width)
        y: control.topPadding + control.availableHeight / 2 - height / 2
        implicitWidth: 8
        implicitHeight: 8
    }
}
