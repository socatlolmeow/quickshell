import QtQuick

Item {
    id: g
    required property Item backdrop
    property real bx: 0
    property real by: 0
    property real radius: 24
    property real tint: 0.5
    property bool dark: true
    property real thickness: 22
    property real blur: 6
    property real shadowAmt: 0.5
    property real magnify: 0.1
    property real ringW: 0
    property real rim: 0.45
    property real rimTint: 0
    property real flatInner: 1
    readonly property bool failed: fx.status === ShaderEffect.Error

    readonly property real pad: 10
    readonly property real reach: 72

    ShaderEffectSource {
        id: backdropTex
        sourceItem: g.backdrop
        visible: false
        mipmap: true
        sourceRect: Qt.rect(g.bx - g.pad - g.reach, g.by - g.pad - g.reach, g.width + 2 * (g.pad + g.reach), g.height + 2 * (g.pad + g.reach))
        textureSize: Qt.size(sourceRect.width, sourceRect.height)
    }

    ShaderEffect {
        id: fx
        x: -g.pad
        y: -g.pad
        width: g.width + 2 * g.pad
        height: g.height + 2 * g.pad
        fragmentShader: Qt.resolvedUrl("../assets/shaders/liquidglass.frag.qsb")

        property variant src: backdropTex
        property vector2d itemSize: Qt.vector2d(width, height)
        property vector2d glassSize: Qt.vector2d(g.width, g.height)
        property vector2d srcSize: Qt.vector2d(backdropTex.sourceRect.width, backdropTex.sourceRect.height)
        property vector2d srcOffset: Qt.vector2d(g.reach, g.reach)
        property real pad: g.pad
        property real radius: g.radius
        property real bezel: Math.min(g.height * 0.36, 26)
        property real thickness: g.thickness * 1.6
        property real dispersion: 0.1
        property real blurPx: g.blur
        property real tintMix: g.tint * 0.55
        property real saturation: 1.25
        property real dark: g.dark ? 1 : 0
        property real debug: 0
        property real rim: g.rim
        property real grain: 0.006
        property real magnify: g.magnify
        property real shadowAmt: g.shadowAmt
        property real rimTint: g.rimTint
        property real ringW: g.ringW
        property real flatInner: g.flatInner
    }
}
