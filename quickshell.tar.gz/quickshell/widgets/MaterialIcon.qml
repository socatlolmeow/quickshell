import qs
import qs.settings
import QtQuick

Text {
    font.family: "Material Symbols Outlined"
    color: Colors.c.base05
    font.pointSize: Config.cfg.appearance.iconSize > 0 ? Config.cfg.appearance.iconSize : 16
    property bool fill: false
    renderType: Text.NativeRendering
    font.variableAxes: {
        "FILL": fill ? 1 : 0,
        "opsz": 24,
        "wght": 400
    }
}
