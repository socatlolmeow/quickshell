import QtQuick
import Quickshell.Io
import Qt.labs.folderlistmodel 2.11
import qs.settings

Item {
    id: root

    readonly property string rootDir: Config.cfg.wallpaper.wallDir.replace(/\/+$/, "")
    property string dir: rootDir
    readonly property bool atRoot: dir === rootDir
    readonly property string title: atRoot ? "Wallpapers" : dir.substring(dir.lastIndexOf("/") + 1)
    property alias model: list
    property string pending: ""

    onRootDirChanged: dir = rootDir

    function up() {
        if (!atRoot)
            dir = dir.substring(0, dir.lastIndexOf("/"));
    }

    function createFolder(name) {
        const clean = name.replace(/[\/\\]/g, "").trim();
        if (clean === "" || clean === "." || clean === "..")
            return;
        pending = dir + "/" + clean;
        mkdir.command = ["mkdir", "-p", "--", pending];
        mkdir.running = true;
    }

    FolderListModel {
        id: list
        folder: Qt.resolvedUrl(root.dir)
        showDirs: true
        showDirsFirst: true
        showDotAndDotDot: false
        nameFilters: ["*.png", "*.PNG", "*.jpg", "*.JPG", "*.jpeg", "*.JPEG", "*.webp", "*.WEBP"]
    }

    Process {
        id: mkdir
        onExited: code => {
            if (code === 0)
                root.dir = root.pending;
        }
    }
}
