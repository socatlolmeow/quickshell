import Quickshell
import Quickshell.Widgets
import QtQuick
import QtQuick.Effects
import qs
import qs.settings

IconImage {
    id: root
    required property string iconName
    property bool fill: true
    property color tint: Colors.font
    source: Qt.resolvedUrl(fill ? Quickshell.shellDir + "/assets/phosphor-icons/fill/" + iconName + "-fill.svg" : Quickshell.shellDir + "/assets/phosphor-icons/regular/" + iconName + ".svg")
    width: Config.cfg.appearance.iconSize > 0 ? Config.cfg.appearance.iconSize : 16
    height: Config.cfg.appearance.iconSize > 0 ? Config.cfg.appearance.iconSize : 16
    layer.enabled: true
    layer.effect: MultiEffect {
        colorization: 1.0
        colorizationColor: root.tint
        brightness: 1.0
    }
}
