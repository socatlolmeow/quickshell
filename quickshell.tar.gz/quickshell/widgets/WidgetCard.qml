import QtQuick
import qs

Item {
    id: root
    required property var slot
    property real radius: 26
    default property alias content: body.data

    readonly property bool dark: !Colors.light
    readonly property color fg: dark ? Qt.rgba(1, 1, 1, 0.96) : Qt.rgba(0, 0, 0, 0.86)
    readonly property color fgSub: dark ? Qt.rgba(1, 1, 1, 0.58) : Qt.rgba(0, 0, 0, 0.5)
    readonly property color red: dark ? "#FF453A" : "#FF3B30"
    readonly property color orange: "#FF9F0A"

    visible: slot.onScreen
    scale: slot.dragging ? 1.04 : 1

    Behavior on scale {
        NumberAnimation {
            duration: 160
            easing.type: Easing.OutCubic
        }
    }

    Rectangle {
        anchors.fill: parent
        radius: root.radius
        visible: glass.failed || slot.wall.status !== Image.Ready
        color: root.dark ? Qt.rgba(0.16, 0.16, 0.18, 0.85) : Qt.rgba(1, 1, 1, 0.85)
        border.width: 1
        border.color: root.dark ? Qt.rgba(1, 1, 1, 0.14) : Qt.rgba(0, 0, 0, 0.08)
    }

    LiquidGlass {
        id: glass
        anchors.fill: parent
        visible: root.slot.wall.status === Image.Ready
        backdrop: root.slot.wall
        bx: root.slot.x
        by: root.slot.y
        radius: root.radius
        dark: root.dark
        tint: root.dark ? 0.4 : 0.6
        shadowAmt: root.slot.dragging ? 0.9 : 0.45
    }

    Item {
        id: body
        anchors.fill: parent
    }
}
