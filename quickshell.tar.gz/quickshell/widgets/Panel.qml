import QtQuick
import QtQuick.Effects
import qs
import qs.settings

Rectangle {
    property real bgAlpha: 0.84

    property bool dropShadow: true
    color: Colors.alpha(Colors.bg, bgAlpha)
    radius: Config.cfg.appearance.rounding
    border.width: 1
    border.color: Colors.hairline
    layer.enabled: dropShadow
    layer.effect: MultiEffect {
        shadowEnabled: true
        shadowColor: "black"
        shadowOpacity: 0.3
        shadowBlur: 1
        shadowVerticalOffset: 14
    }
}
