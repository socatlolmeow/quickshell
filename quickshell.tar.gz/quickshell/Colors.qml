pragma ComponentBehavior: Bound
pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io
import qs.settings

Singleton {
    id: root
    property alias c: colors

    property color accent: colors[Config.cfg.appearance.accent]
    property color bg: colors.base00
    property color surface: colors.base01
    property color overlay: colors.base02
    property color muted: colors.base03
    property color subtle: colors.base04
    property color font: colors.base05
    property color urgent: colors.base08
    property color warn: colors.base09
    property color ok: colors.base0B

    readonly property bool light: colors.base00.hslLightness > 0.5
    readonly property bool pureBlack: Config.cfg.bar.pureBlack
    property color pillBg: pureBlack ? "#000000" : (light ? Qt.darker(colors.base05, 1.6) : Qt.darker(colors.base00, 1.5))
    property color pillFg: light ? colors.base00 : colors.base05
    property color pillSurface: pureBlack ? Qt.tint(pillBg, alpha(pillFg, 0.08)) : (light ? Qt.lighter(pillBg, 1.3) : surface)
    property color pillOverlay: pureBlack ? Qt.tint(pillBg, alpha(pillFg, 0.14)) : (light ? Qt.lighter(pillBg, 1.8) : overlay)
    property color pillMuted: light ? alpha(pillFg, 0.45) : muted
    property color pillSubtle: light ? alpha(pillFg, 0.7) : subtle
    property color pillCard: Qt.tint(pillBg, alpha(pillFg, 0.06))
    property color pillCard2: Qt.tint(pillBg, alpha(pillFg, 0.10))
    property color pillCircle: Qt.tint(pillBg, alpha(pillFg, 0.16))
    property color pillTrack: pureBlack ? Qt.tint(pillBg, alpha(pillFg, 0.16)) : Qt.darker(pillBg, 1.5)
    property color pillLine: alpha(pillFg, 0.07)
    property color hairline: alpha(pillFg, 0.14)
    property color highlight: alpha(pillFg, 0.1)
    property color pillDim: Qt.tint(pillBg, alpha(accent, 0.25))

    function alpha(col, a) {
        return Qt.rgba(col.r, col.g, col.b, a);
    }

    FileView {
        id: colorView
        path: Qt.resolvedUrl(Quickshell.shellDir + "/schemes/" + Config.cfg.appearance.currentTheme)
        onFileChanged: {
            reload();
        }
        watchChanges: true
        adapter: JsonAdapter {
            id: colors
            property color base00
            property color base01
            property color base02
            property color base03
            property color base04
            property color base05
            property color base06
            property color base07
            property color base08
            property color base09
            property color base0A
            property color base0B
            property color base0C
            property color base0D
            property color base0E
            property color base0F
        }
    }
}
