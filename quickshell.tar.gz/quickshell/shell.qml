//@ pragma UseQApplication
//@ pragma IconTheme Papirus
import Quickshell
import qs.modules.bar
import qs.modules.overlays
import qs.modules.ipc
import qs.modules.desktop
import qs.modules.dock

ShellRoot {
    Ipc {}
    Bottom {}
    DesktopWidgets {}
    Bar {}
    Dock {}
    Top {}
    ThemeWindow {}
    WallpaperWindow {}
    VolumeWindow {}
    NotificationWindow {}
    LockScreen {}
}
