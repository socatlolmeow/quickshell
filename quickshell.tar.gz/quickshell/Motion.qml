pragma Singleton
import Quickshell

/* macOS-style motion curves, for NumberAnimation { easing.type: Easing.BezierSpline; easing.bezierCurve: Motion.x }
 * (control points x1 y1 x2 y2, then the end point). None of them overshoot: macOS settles, it doesn't bounce. */
Singleton {
    /* things arriving: fast out of the gate, long soft landing (like SwiftUI .smooth) */
    readonly property var smooth: [0.22, 1.0, 0.36, 1.0, 1.0, 1.0]
    /* gentle in-out for things that move between two resting places */
    readonly property var standard: [0.25, 0.1, 0.25, 1.0, 1.0, 1.0]
    /* things leaving: start slow, finish quickly so they get out of the way */
    readonly property var exit: [0.4, 0.0, 0.8, 0.4, 1.0, 1.0]
    /* fades */
    readonly property var fade: [0.0, 0.0, 0.2, 1.0, 1.0, 1.0]
}
